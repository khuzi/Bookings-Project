module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/dashboard/[review].js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/reviews/answer/answer.js":
/*!*********************************************!*\
  !*** ./components/reviews/answer/answer.js ***!
  \*********************************************/
/*! exports provided: Answer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Answer", function() { return Answer; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Accordion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Accordion */ "@material-ui/core/Accordion");
/* harmony import */ var _material_ui_core_Accordion__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Accordion__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_core_AccordionSummary__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/AccordionSummary */ "@material-ui/core/AccordionSummary");
/* harmony import */ var _material_ui_core_AccordionSummary__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_AccordionSummary__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core_AccordionDetails__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/AccordionDetails */ "@material-ui/core/AccordionDetails");
/* harmony import */ var _material_ui_core_AccordionDetails__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_AccordionDetails__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/Typography */ "@material-ui/core/Typography");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/icons/ExpandMore */ "@material-ui/icons/ExpandMore");
/* harmony import */ var _material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_9__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\reviews\\answer\\answer.js";









const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__["makeStyles"])(theme => ({
  root: {
    width: "100%"
  },
  accordion: {
    width: "100%",
    boxShadow: "none",
    boder: "none"
  },
  summary: {
    width: "18%",
    background: "var(--primary-color)",
    color: "#fff",
    borderRadius: "5px",
    marginLeft: "82%"
  },
  heading: {
    fontSize: "14px"
  },
  details: {
    borderRadius: "8px",
    marginTop: "0.5rem",
    boxShadow: "0px 3px 15px rgba(0,0,0,0.1)"
  },
  message: {
    display: "flex",
    flexFlow: "column",
    padding: "0.5rem 0",
    width: "100%",
    "& textarea": {
      height: "100px",
      borderRadius: "8px",
      padding: "0.5rem",
      border: "1px solid #bbb",
      resize: "none",
      outline: "none"
    }
  },
  btnSend: {
    marginTop: "0.5rem",
    background: "var(--primary-color)",
    color: "#fff",
    textTransform: "capitalize",
    "&:hover": {
      background: "var(--primary-color)"
    }
  }
}));
function Answer({
  answer,
  id
}) {
  const classes = useStyles();
  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_2__["useRouter"])();
  const [message, setMessage] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState("");

  const sendResult = () => {
    fetch("https://cors-anywhere.herokuapp.com/http://nappetito-stage.herokuapp.com/api/review", {
      method: "POST",
      body: JSON.stringify({
        reviewId: id,
        userId: "5ec503cc434dff29cf56633b",
        message: message
      }),
      headers: {
        "Content-Type": "application/json"
      }
    }).then(res => res.json()).then(response => {
      console.log("res send = ", response);
      router.reload();
    }).catch(err => {
      console.log("Error = ", err);
      router.reload();
    });
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: classes.root,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Accordion__WEBPACK_IMPORTED_MODULE_5___default.a, {
      className: classes.accordion,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_AccordionSummary__WEBPACK_IMPORTED_MODULE_6___default.a, {
        className: classes.summary,
        expandIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_9___default.a, {
          style: {
            color: "#fff"
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 96,
          columnNumber: 23
        }, this),
        "aria-controls": "panel1a-content",
        id: "panel1a-header",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8___default.a, {
          className: classes.heading,
          children: answer && answer[0] ? "See Answer" : "Answer"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_AccordionDetails__WEBPACK_IMPORTED_MODULE_7___default.a, {
        className: classes.details,
        children: answer && answer[0] ? answer.map((commit, i) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8___default.a, {
          children: commit
        }, i, false, {
          fileName: _jsxFileName,
          lineNumber: 106,
          columnNumber: 39
        }, this)) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: classes.message,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("textarea", {
            placeholder: "Enter Answer",
            value: message,
            onChange: e => setMessage(e.target.value)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 109,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Button"], {
            onClick: () => sendResult(),
            className: classes.btnSend,
            children: "Send"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 93,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 92,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/reviews/index.js":
/*!*************************************!*\
  !*** ./components/reviews/index.js ***!
  \*************************************/
/*! exports provided: ReviewBox, Answer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _reviewBox_reviewBox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reviewBox/reviewBox */ "./components/reviews/reviewBox/reviewBox.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ReviewBox", function() { return _reviewBox_reviewBox__WEBPACK_IMPORTED_MODULE_0__["ReviewBox"]; });

/* harmony import */ var _answer_answer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./answer/answer */ "./components/reviews/answer/answer.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Answer", function() { return _answer_answer__WEBPACK_IMPORTED_MODULE_1__["Answer"]; });




/***/ }),

/***/ "./components/reviews/reviewBox/reviewBox.js":
/*!***************************************************!*\
  !*** ./components/reviews/reviewBox/reviewBox.js ***!
  \***************************************************/
/*! exports provided: ReviewBox */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewBox", function() { return ReviewBox; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../ui */ "./components/ui/index.js");
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ */ "./components/reviews/index.js");
/* harmony import */ var _reviewBox_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./reviewBox.module.css */ "./components/reviews/reviewBox/reviewBox.module.css");
/* harmony import */ var _reviewBox_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_reviewBox_module_css__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\reviews\\reviewBox\\reviewBox.js";





function ReviewBox({
  name,
  date,
  review,
  ratText,
  revRat,
  comments,
  id
}) {
  const [answers, setAnswers] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState();
  react__WEBPACK_IMPORTED_MODULE_1___default.a.useEffect(() => {
    const text = comments.map(({
      text
    }) => text);
    setAnswers(text);
  }, [comments]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: _reviewBox_module_css__WEBPACK_IMPORTED_MODULE_5___default.a.reviewBox,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
      variant: "h5",
      children: name
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
      style: {
        color: "var(--primary-color)"
      },
      variant: "subtitle2",
      children: date
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: _reviewBox_module_css__WEBPACK_IMPORTED_MODULE_5___default.a.rat,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
        style: {
          fontWeight: "600"
        },
        variant: "subtitle1",
        children: ratText
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          marginTop: "0.15rem"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ui__WEBPACK_IMPORTED_MODULE_3__["CustomizedRatings"], {
          size: "small",
          max: 5,
          revRat: revRat
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
      style: {
        maxWidth: "90%"
      },
      variant: "subtitle2",
      children: review
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
      container: true,
      justify: "flex-end",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(___WEBPACK_IMPORTED_MODULE_4__["Answer"], {
        answer: answers,
        id: id
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/reviews/reviewBox/reviewBox.module.css":
/*!***********************************************************!*\
  !*** ./components/reviews/reviewBox/reviewBox.module.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"reviewBox": "reviewBox_reviewBox__1mhS7",
	"rat": "reviewBox_rat__3ANtW",
	"ans_btn": "reviewBox_ans_btn__14Rlo"
};


/***/ }),

/***/ "./components/ui/datePicker/datePicker.js":
/*!************************************************!*\
  !*** ./components/ui/datePicker/datePicker.js ***!
  \************************************************/
/*! exports provided: DatePicker */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DatePicker", function() { return DatePicker; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns */ "date-fns");
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Grid */ "@material-ui/core/Grid");
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @date-io/date-fns */ "@date-io/date-fns");
/* harmony import */ var _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_date_io_date_fns__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/pickers */ "@material-ui/pickers");
/* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_icons_CalendarTodayOutlined__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/icons/CalendarTodayOutlined */ "@material-ui/icons/CalendarTodayOutlined");
/* harmony import */ var _material_ui_icons_CalendarTodayOutlined__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_CalendarTodayOutlined__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _context_bookingFetch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../context/bookingFetch */ "./context/bookingFetch.js");

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\datePicker\\datePicker.js";








function DatePicker() {
  const value = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(_context_bookingFetch__WEBPACK_IMPORTED_MODULE_8__["BookingContext"]);
  const {
    date,
    setDate,
    setMonth,
    month
  } = value;
  react__WEBPACK_IMPORTED_MODULE_1___default.a.useEffect(() => {
    const dateText = month_name(new Date()) + " " + new Date().getDate();
    setMonth(dateText);
    console.log(month);
  }, []);

  const month_name = dt => {
    const mlist = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return mlist[dt.getMonth()];
  };

  const handleDateChange = dat => {
    setDate(dat);
    const dateText = month_name(new Date(dat)) + " " + dat.getDate();
    setMonth(dateText);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__["MuiPickersUtilsProvider"], {
    utils: _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4___default.a,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3___default.a, {
      item: true,
      xs: 6,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "date-picker",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__["KeyboardDatePicker"], {
          keyboardIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "40",
            height: "40",
            viewBox: "0 0 60 60",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
              id: "Group_14365",
              "data-name": "Group 14365",
              transform: "translate(-541.25 -144.75)",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
                id: "Path_14888",
                "data-name": "Path 14888",
                d: "M34.114,0H5.386A5.393,5.393,0,0,0,0,5.386V34.114A5.394,5.394,0,0,0,5.386,39.5H34.114A5.394,5.394,0,0,0,39.5,34.114V5.386A5.394,5.394,0,0,0,34.114,0ZM37.7,34.114A3.6,3.6,0,0,1,34.114,37.7H5.386A3.6,3.6,0,0,1,1.8,34.114V5.386A3.6,3.6,0,0,1,5.386,1.8H34.114A3.6,3.6,0,0,1,37.7,5.386Z",
                transform: "translate(541.5 145)",
                fill: "#e72311",
                stroke: "#e72311",
                "stroke-width": "0.5"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 67,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ellipse", {
                id: "Ellipse_3550",
                "data-name": "Ellipse 3550",
                cx: "1.524",
                cy: "1.524",
                rx: "1.524",
                ry: "1.524",
                transform: "translate(551.047 151.17)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ellipse", {
                id: "Ellipse_3551",
                "data-name": "Ellipse 3551",
                cx: "1.524",
                cy: "1.524",
                rx: "1.524",
                ry: "1.524",
                transform: "translate(559.727 151.17)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ellipse", {
                id: "Ellipse_3552",
                "data-name": "Ellipse 3552",
                cx: "1.524",
                cy: "1.524",
                rx: "1.524",
                ry: "1.524",
                transform: "translate(568.404 151.17)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 96,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2864",
                "data-name": "Rectangle 2864",
                width: "5.501",
                height: "4.893",
                transform: "translate(554.827 160.443)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 106,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2865",
                "data-name": "Rectangle 2865",
                width: "5.5",
                height: "4.893",
                transform: "translate(562.172 160.443)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 114,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2866",
                "data-name": "Rectangle 2866",
                width: "5.501",
                height: "4.893",
                transform: "translate(569.514 160.443)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 122,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2867",
                "data-name": "Rectangle 2867",
                width: "5.5",
                height: "4.891",
                transform: "translate(547.484 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 130,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2868",
                "data-name": "Rectangle 2868",
                width: "5.501",
                height: "4.891",
                transform: "translate(554.827 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 138,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2869",
                "data-name": "Rectangle 2869",
                width: "5.5",
                height: "4.891",
                transform: "translate(562.172 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 146,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2870",
                "data-name": "Rectangle 2870",
                width: "5.501",
                height: "4.891",
                transform: "translate(569.514 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 154,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2871",
                "data-name": "Rectangle 2871",
                width: "5.5",
                height: "4.891",
                transform: "translate(547.484 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 162,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2872",
                "data-name": "Rectangle 2872",
                width: "5.501",
                height: "4.891",
                transform: "translate(554.827 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 170,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2873",
                "data-name": "Rectangle 2873",
                width: "5.5",
                height: "4.891",
                transform: "translate(562.172 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 178,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2874",
                "data-name": "Rectangle 2874",
                width: "5.501",
                height: "4.891",
                transform: "translate(569.514 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 186,
                columnNumber: 19
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 62,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 56,
            columnNumber: 15
          }, this),
          margin: "normal",
          value: date,
          onChange: handleDateChange,
          format: "yyyy-MM-ddd",
          KeyboardButtonProps: {
            "aria-label": "change date"
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 51,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/dropDown/dropDown.js":
/*!********************************************!*\
  !*** ./components/ui/dropDown/dropDown.js ***!
  \********************************************/
/*! exports provided: CustomizedSelects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomizedSelects", function() { return CustomizedSelects; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/FormControl */ "@material-ui/core/FormControl");
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/NativeSelect */ "@material-ui/core/NativeSelect");
/* harmony import */ var _material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/InputBase */ "@material-ui/core/InputBase");
/* harmony import */ var _material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _context_dashboardFetch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../context/dashboardFetch */ "./context/dashboardFetch.js");

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\dropDown\\dropDown.js";






const BootstrapInput = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__["withStyles"])(theme => ({
  input: {
    minWidth: "8rem",
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.primary.main,
    border: "none",
    fontSize: 14,
    padding: "10px 26px 10px 5px",
    color: "#fff",
    "&:focus": {
      background: theme.palette.primary.main,
      borderRadius: "4px"
    }
  }
}))(_material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5___default.a);

const onStartEnd = (date, month, year) => {
  return `${year}-${month}-${date}`;
};

function CustomizedSelects() {
  const [date, setDate] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState("today");
  const {
    setStartDate,
    setEndDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(_context_dashboardFetch__WEBPACK_IMPORTED_MODULE_6__["DashBordContext"]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("Date = ", date);
  }, [date]);

  const dateHandler = event => {
    const newDate = new Date();
    const value = event.target.value;

    switch (value) {
      case "today":
        setStartDate(onStartEnd(newDate.getDate(), newDate.getMonth() + 1, newDate.getFullYear()));
        setEndDate(onStartEnd(newDate.getDate(), newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "current":
        setStartDate(onStartEnd("01", newDate.getMonth() + 1, newDate.getFullYear()));
        setEndDate(onStartEnd("30", newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "three":
        setStartDate(onStartEnd("01", newDate.getMonth() - 2, newDate.getFullYear()));
        setEndDate(onStartEnd("30", newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "six":
        setStartDate(onStartEnd("01", newDate.getMonth() - 5, newDate.getFullYear()));
        setEndDate(onStartEnd("30", newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "year":
        setStartDate(onStartEnd("01", "01", newDate.getFullYear() - 1));
        setEndDate(onStartEnd("30", "12", newDate.getFullYear() - 1));
        break;

      default:
        break;
    }

    setDate(event.target.value);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3___default.a, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4___default.a, {
        id: "demo-customized-select-native",
        value: date,
        onChange: dateHandler,
        input: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(BootstrapInput, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 18
        }, this),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "today",
          children: "Today"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 102,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "current",
          children: "Current Month"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "three",
          children: "Last Three Months"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "six",
          children: "Last 6 Months"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 111,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "year",
          children: "Last Year"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 114,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 94,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/index.js":
/*!********************************!*\
  !*** ./components/ui/index.js ***!
  \********************************/
/*! exports provided: Spinner, PageTitle, LgBtn, DatePicker, SimpleModal, CustomizedRatings, CustomizedSelects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _spinner_spinner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./spinner/spinner */ "./components/ui/spinner/spinner.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Spinner", function() { return _spinner_spinner__WEBPACK_IMPORTED_MODULE_0__["Spinner"]; });

/* harmony import */ var _pageTitle_pageTitle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pageTitle/pageTitle */ "./components/ui/pageTitle/pageTitle.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PageTitle", function() { return _pageTitle_pageTitle__WEBPACK_IMPORTED_MODULE_1__["PageTitle"]; });

/* harmony import */ var _lgBtn_lgBtn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lgBtn/lgBtn */ "./components/ui/lgBtn/lgBtn.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LgBtn", function() { return _lgBtn_lgBtn__WEBPACK_IMPORTED_MODULE_2__["LgBtn"]; });

/* harmony import */ var _datePicker_datePicker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./datePicker/datePicker */ "./components/ui/datePicker/datePicker.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DatePicker", function() { return _datePicker_datePicker__WEBPACK_IMPORTED_MODULE_3__["DatePicker"]; });

/* harmony import */ var _modal_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modal/modal */ "./components/ui/modal/modal.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SimpleModal", function() { return _modal_modal__WEBPACK_IMPORTED_MODULE_4__["SimpleModal"]; });

/* harmony import */ var _ratingStar_ratingStar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ratingStar/ratingStar */ "./components/ui/ratingStar/ratingStar.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CustomizedRatings", function() { return _ratingStar_ratingStar__WEBPACK_IMPORTED_MODULE_5__["CustomizedRatings"]; });

/* harmony import */ var _dropDown_dropDown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dropDown/dropDown */ "./components/ui/dropDown/dropDown.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CustomizedSelects", function() { return _dropDown_dropDown__WEBPACK_IMPORTED_MODULE_6__["CustomizedSelects"]; });









/***/ }),

/***/ "./components/ui/lgBtn/lgBtn.js":
/*!**************************************!*\
  !*** ./components/ui/lgBtn/lgBtn.js ***!
  \**************************************/
/*! exports provided: LgBtn */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LgBtn", function() { return LgBtn; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/styles */ "@material-ui/styles");
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ */ "./components/ui/index.js");

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\lgBtn\\lgBtn.js";




const useStyles = Object(_material_ui_styles__WEBPACK_IMPORTED_MODULE_2__["makeStyles"])(theme => ({
  root: {
    marginTop: "1rem"
  },
  btn: {
    width: "100%",
    padding: "0.5rem 0",
    textTransform: "capitalize",
    background: "#f6f6f6",
    borderTopLeftRadius: "0",
    borderBottomLeftRadius: "0",
    color: "#000",
    "&:hover": {
      background: "#f6f6f6"
    }
  },
  active: {
    width: "100%",
    color: "#fff",
    background: theme.palette.primary.main,
    width: "100%",
    padding: "0.5rem 0",
    textTransform: "capitalize",
    borderTopLeftRadius: "0",
    borderBottomLeftRadius: "0",
    "&:hover": {
      background: "var(--primary-color)"
    }
  }
}));
const LgBtn = ({
  setBookingType,
  bookingType,
  calender,
  management
}) => {
  const classes = useStyles();
  let local = "bookingLocals";
  let experience = "bookingExperiences";

  if (management) {
    local = "locals";
    experience = "experiences";
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
    container: true,
    item: true,
    xs: 6,
    className: classes.root,
    alignContent: "center",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
      item: true,
      xs: 2,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        onClick: () => setBookingType(local),
        className: bookingType === local ? classes.active : classes.btn,
        children: "Locals"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 57,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
      item: true,
      xs: 2,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        onClick: () => setBookingType(experience),
        className: bookingType === experience ? classes.active : classes.btn,
        children: "Experince"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
      item: true,
      xs: 2,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          margin: "0.5rem auto"
        },
        children: calender && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(___WEBPACK_IMPORTED_MODULE_4__["DatePicker"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 24
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 56,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/ui/modal/modal.js":
/*!**************************************!*\
  !*** ./components/ui/modal/modal.js ***!
  \**************************************/
/*! exports provided: SimpleModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimpleModal", function() { return SimpleModal; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Button */ "@material-ui/core/Button");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Dialog */ "@material-ui/core/Dialog");
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/DialogActions */ "@material-ui/core/DialogActions");
/* harmony import */ var _material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/DialogContent */ "@material-ui/core/DialogContent");
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/DialogContentText */ "@material-ui/core/DialogContentText");
/* harmony import */ var _material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Slide */ "@material-ui/core/Slide");
/* harmony import */ var _material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\modal\\modal.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






 // import DialogTitle from "@material-ui/core/DialogTitle";


const Transition = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.forwardRef(function Transition(props, ref) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7___default.a, _objectSpread({
    direction: "up",
    ref: ref
  }, props), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 10
  }, this);
});
function SimpleModal({
  open,
  handleClose,
  statusHandler
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3___default.a, {
      open: open,
      TransitionComponent: Transition,
      keepMounted: true,
      onClose: handleClose,
      "aria-labelledby": "alert-dialog-slide-title",
      "aria-describedby": "alert-dialog-slide-description",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5___default.a, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6___default.a, {
          id: "alert-dialog-slide-description",
          children: "Are You Sure..?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2___default.a, {
          onClick: handleClose,
          color: "primary",
          children: "Disagree"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2___default.a, {
          onClick: statusHandler,
          color: "primary",
          children: "Agree"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/pageTitle/pageTitle.js":
/*!**********************************************!*\
  !*** ./components/ui/pageTitle/pageTitle.js ***!
  \**********************************************/
/*! exports provided: PageTitle */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTitle", function() { return PageTitle; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/styles */ "@material-ui/styles");
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_3__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\pageTitle\\pageTitle.js";



const useStyles = Object(_material_ui_styles__WEBPACK_IMPORTED_MODULE_3__["makeStyles"])(theme => ({
  title: {
    textTransform: "uppercase"
  }
}));
const PageTitle = ({
  text
}) => {
  const classes = useStyles();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
      container: true,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
        item: true,
        xs: 12,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
          className: classes.title,
          variant: "h5",
          children: text
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/ui/ratingStar/ratingStar.js":
/*!************************************************!*\
  !*** ./components/ui/ratingStar/ratingStar.js ***!
  \************************************************/
/*! exports provided: CustomizedRatings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomizedRatings", function() { return CustomizedRatings; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/lab/Rating */ "@material-ui/lab/Rating");
/* harmony import */ var _material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/StarBorder */ "@material-ui/icons/StarBorder");
/* harmony import */ var _material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Box */ "@material-ui/core/Box");
/* harmony import */ var _material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\ratingStar\\ratingStar.js";




function CustomizedRatings({
  rating,
  size,
  max = 1,
  revRat
}) {
  let value = null;

  if (rating === 5 && !revRat) {
    value = 1;
  } else if (rating < 5 && !revRat) {
    value = 0.5;
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4___default.a, {
      component: "fieldset",
      mb: 3,
      borderColor: "transparent",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2___default.a, {
        style: {
          color: "var(--primary-color)"
        },
        name: "customized-empty",
        readOnly: true,
        max: max,
        precision: 0.5,
        value: value ? value : revRat,
        size: size,
        emptyIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3___default.a, {
          fontSize: "inherit"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 22
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/spinner/spinner.js":
/*!******************************************!*\
  !*** ./components/ui/spinner/spinner.js ***!
  \******************************************/
/*! exports provided: Spinner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Spinner", function() { return Spinner; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/CircularProgress */ "@material-ui/core/CircularProgress");
/* harmony import */ var _material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons */ "@material-ui/icons");
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\spinner\\spinner.js";




const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__["makeStyles"])(theme => ({
  root: {
    display: "flex",
    "& > * + *": {
      marginLeft: theme.spacing(2)
    },
    width: "100%",
    height: "100vh",
    justifyContent: "center",
    alignItems: "center"
  }
}));
function Spinner() {
  const classes = useStyles();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: classes.root,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3___default.a, {
      color: "secondary"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./context/bookingFetch.js":
/*!*********************************!*\
  !*** ./context/bookingFetch.js ***!
  \*********************************/
/*! exports provided: BookingContext, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingContext", function() { return BookingContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return BookingFetch; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "E:\\Next.js\\bookings\\context\\bookingFetch.js";

const BookingContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])();
function BookingFetch({
  children
}) {
  const {
    0: bookings,
    1: setBookings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: completed,
    1: setCompleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: pending,
    1: setPending
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: noShow,
    1: setNoShow
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: deleted,
    1: setDeleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: bookingType,
    1: setBookingType
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("bookingLocals");
  const {
    0: bookingData,
    1: setBookingData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: bookingHeader,
    1: setBookingHeader
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: date,
    1: setDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(new Date());
  const {
    0: month,
    1: setMonth
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");

  const filter = (array, status, setFunc) => {
    const FilterArray = array.filter(el => el.status === status);
    setFunc(FilterArray);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let bookingsKeys = [];
    let bookingsData = [];

    const fetcher = async () => {
      try {
        const newDate = new Date(date);
        const proxyUrl = "https://cors-anywhere.herokuapp.com/";
        const url = `http://nappetito-stage.herokuapp.com/api/${bookingType}/5ec503cc434dff29cf56633b/${newDate.getFullYear()}-${newDate.getMonth() + 1}-${newDate.getDate()}/all`;
        const res = await fetch(proxyUrl + url);
        const data = await res.json();
        setBookings(data);
        Object.values(data).forEach((el, i) => {
          if (i === 0) {
            Object.keys(el).forEach(key => {
              bookingsKeys.push({
                label: key,
                key: key
              });
            });
          }

          bookingsData.push(el);
        });
        setBookingData(bookingsData);
        setBookingHeader(bookingsKeys);
        filter(data, "deleted", setDeleted);
        filter(data, "pending", setPending);
        filter(data, "no-show", setNoShow);
        filter(data, "completed", setCompleted);
      } catch (error) {
        console.log(error);
      }
    };

    fetcher();
  }, [date, bookingType]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(BookingContext.Provider, {
    value: {
      bookings,
      date,
      setDate,
      deleted,
      pending,
      noShow,
      completed,
      bookingData,
      bookingHeader,
      month,
      setMonth,
      setBookingType,
      bookingType
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 58,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./context/dashboardFetch.js":
/*!***********************************!*\
  !*** ./context/dashboardFetch.js ***!
  \***********************************/
/*! exports provided: DashBordContext, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashBordContext", function() { return DashBordContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DashboardFetch; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "E:\\Next.js\\bookings\\context\\dashboardFetch.js";

const DashBordContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])();

const fetcher = (endpoint, startDate, endDate, setData) => {
  fetch(`https://cors-anywhere.herokuapp.com/http://nappetito-stage.herokuapp.com/api/${endpoint}`, {
    method: "POST",
    body: JSON.stringify({
      startDate: startDate,
      endDate: endDate,
      userId: "5ec503cc434dff29cf56633b"
    }),
    headers: {
      "Content-Type": "application/json"
    }
  }).then(res => res.json()).then(result => {
    setData(result);
  }).catch(err => console.log("Error = ", err));
};

const fetcherReviews = async (url, setData) => {
  try {
    const proxyUrl = "https://cors-anywhere.herokuapp.com/";
    const urll = url;
    const res = await fetch(proxyUrl + urll);
    const data = await res.json();
    setData(data);
  } catch (error) {
    console.log(error);
  }
};

function DashboardFetch({
  children
}) {
  const {
    0: startDate,
    1: setStartDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(new Date());
  const {
    0: endDate,
    1: setEndDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(new Date());
  const {
    0: reviews,
    1: setReviews
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: bookings,
    1: setBookings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: completed,
    1: setCompleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: deleted,
    1: setDeleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: noShow,
    1: setNoShow
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: expReviews,
    1: setExpReviews
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: expBookings,
    1: setExpBookings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: earnings,
    1: setEarnings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    fetcherReviews(`http://nappetito-stage.herokuapp.com/api/reviewLocalTotalCount/5ec503cc434dff29cf56633b`, setReviews);
    fetcherReviews("http://nappetito-stage.herokuapp.com/api/reviewExperienceTotalCount/5fa3eb9f9412c3fe0513ddc6", setExpReviews);
    fetcher("bookingLocalsTotalCount", startDate, endDate, setBookings);
    fetcher("bookingLocalsCompletedCount", startDate, endDate, setCompleted);
    fetcher("bookingLocalsDeletedCount", startDate, endDate, setDeleted);
    fetcher("bookingLocalsNoShowCount", startDate, endDate, setNoShow);
    fetcher("bookingExperiencesTotalCount", startDate, endDate, setExpBookings);
    fetcher("bookingExperiencesTotalGain", startDate, endDate, setEarnings);
  }, [bookings, reviews, completed, deleted, noShow, startDate, endDate, expReviews, expBookings, earnings]);
  const local = [{
    src: "/images/stars.svg",
    txt: "Reviews",
    total: reviews
  }, {
    src: "/images/bookings.svg",
    txt: "Bookings Total",
    total: bookings
  }, {
    src: "/images/book-comp.svg",
    txt: "Bookings Completed",
    total: completed
  }, {
    src: "/images/book-del.svg",
    txt: "Bookings Deleted",
    total: deleted
  }, {
    src: "/images/book-noShow.svg",
    txt: "Bookings No-Show",
    total: noShow
  }];
  const experience = [{
    src: "/images/stars.svg",
    txt: "Reviews",
    total: expReviews
  }, {
    src: "/images/bookings.svg",
    txt: "Bookings Total",
    total: expBookings
  }, {
    src: "/images/earning.svg",
    txt: "Earnings",
    total: earnings
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(DashBordContext.Provider, {
    value: {
      setStartDate,
      setEndDate,
      local,
      experience
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 113,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./pages/dashboard/[review].js":
/*!*************************************!*\
  !*** ./pages/dashboard/[review].js ***!
  \*************************************/
/*! exports provided: default, getStaticPaths, getStaticProps */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Review; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStaticPaths", function() { return getStaticPaths; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStaticProps", function() { return getStaticProps; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/ui */ "./components/ui/index.js");
/* harmony import */ var _components_reviews__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/reviews */ "./components/reviews/index.js");
/* harmony import */ var _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../styles/review.module.css */ "./styles/review.module.css");
/* harmony import */ var _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_review_module_css__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "E:\\Next.js\\bookings\\pages\\dashboard\\[review].js";








const RatDescp = ({
  reviewCount,
  title
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
    container: true,
    justify: "space-between",
    className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.ratDecp,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
      container: true,
      item: true,
      xs: 6,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
        item: true,
        xs: 3,
        children: reviewCount === 0 || reviewCount > 0 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Typography"], {
          variant: "h5",
          children: reviewCount
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 15
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
        item: true,
        xs: 6,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          style: {
            marginTop: "0.4rem"
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_ui__WEBPACK_IMPORTED_MODULE_5__["CustomizedRatings"], {
            max: 5,
            revRat: `${reviewCount}`,
            size: "small"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
      item: true,
      xs: 6,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Typography"], {
        style: {
          marginTop: "0.3rem"
        },
        variant: "subtitle1",
        align: "right",
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, undefined);
};

function Review({
  reviewLocal,
  reviewExperience
}) {
  var _reviewData, _ref;

  const router = Object(next_router__WEBPACK_IMPORTED_MODULE_3__["useRouter"])();
  const type = router.query.review;
  let reviewData = null;

  if (type === "local") {
    reviewData = reviewLocal;
  } else {
    reviewData = reviewExperience;
  }

  const {
    0: reviewsSimple,
    1: setReviewsSimple
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: reviewsBooking,
    1: setReviewsBooking
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: reviewsTotal,
    1: setReviewsTotal
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let id = "5ec503cc434dff29cf56633b";
    let typeFetch = "publicLocal";

    if (type === "experience") {
      id = "5fa3eb9f9412c3fe0513ddc6";
      typeFetch = "publicExperience";
    }

    fetch(`http://nappetito-stage.herokuapp.com/api/${typeFetch}Reviews/${id}`).then(res => res.json()).then(data => setReviewsSimple(data));
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let id = "5ec503cc434dff29cf56633b";
    let typeFetch = "bookingLocal";

    if (type === "experience") {
      id = "5fa3eb9f9412c3fe0513ddc6";
      typeFetch = "bookingExperience";
    }

    fetch(`http://nappetito-stage.herokuapp.com/api/${typeFetch}Reviews/${id}`).then(res => res.json()).then(data => setReviewsBooking(data));
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let id = "5ec503cc434dff29cf56633b";
    let typeFetch = "totalLocal";

    if (type === "experience") {
      id = "5fa3eb9f9412c3fe0513ddc6";
      typeFetch = "totalExperience";
    }

    fetch(`http://nappetito-stage.herokuapp.com/api/${typeFetch}Reviews/${id}`).then(res => res.json()).then(data => setReviewsTotal(data));
  }, []);

  const month_name = dt => {
    const date = new Date(dt);
    const mlist = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return `${date.getDate()}-${mlist[date.getMonth()].slice(0, 3)}-${date.getFullYear()}`;
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: "Reviews"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 118,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 117,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.review,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.tutto,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: "Tutto"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 122,
          columnNumber: 11
        }, this), [5, 4, 3, 2, 1].map((el, i) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.rat_num,
            children: el
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 125,
            columnNumber: 15
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.rat_star,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_ui__WEBPACK_IMPORTED_MODULE_5__["CustomizedRatings"], {
              rating: 5,
              size: "small"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 127,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 126,
            columnNumber: 15
          }, this)]
        }, i, true, {
          fileName: _jsxFileName,
          lineNumber: 124,
          columnNumber: 13
        }, this))]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 121,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
        container: true,
        className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.middle,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
          container: true,
          item: true,
          xs: 8,
          className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.middle_main,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
            container: true,
            item: true,
            xs: 12,
            justify: "space-between",
            alignItems: "center",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
              item: true,
              xs: 2,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Typography"], {
                className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.middle_main_heading,
                variant: "h5",
                children: "reviews"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 142,
                columnNumber: 17
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 141,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 134,
            columnNumber: 13
          }, this), (_reviewData = reviewData) === null || _reviewData === void 0 ? void 0 : _reviewData.map(rev => {
            const {
              _id,
              postedByName,
              text,
              replied,
              createdAt,
              rating,
              comments
            } = rev;
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
              item: true,
              xs: 12,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_reviews__WEBPACK_IMPORTED_MODULE_6__["ReviewBox"], {
                id: _id,
                name: postedByName,
                date: `${month_name(createdAt)} - Pick's Pub`,
                ratText: "Valutazione Complessiva",
                review: text,
                replied: replied,
                revRat: Number(rating),
                comments: comments
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 162,
                columnNumber: 19
              }, this)
            }, _id, false, {
              fileName: _jsxFileName,
              lineNumber: 161,
              columnNumber: 17
            }, this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__["Grid"], {
          item: true,
          xs: 4,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: _styles_review_module_css__WEBPACK_IMPORTED_MODULE_7___default.a.ratingBox,
            children: (_ref = [{
              title: "Reviews",
              ratings: reviewsSimple
            }, {
              title: "Booking Reviews",
              ratings: reviewsBooking
            }, {
              title: "Total Reviews",
              ratings: reviewsTotal
            }]) === null || _ref === void 0 ? void 0 : _ref.map((item, i) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(RatDescp, {
              title: item.title,
              reviewCount: item.ratings
            }, i, false, {
              fileName: _jsxFileName,
              lineNumber: 192,
              columnNumber: 17
            }, this))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 177,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 176,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 120,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
async function getStaticPaths() {
  const paths = ["/dashboard/local", "/dashboard/experience"];
  return {
    paths,
    fallback: true
  };
}
async function getStaticProps() {
  const local = await fetch("http://nappetito-stage.herokuapp.com/api/reviewsLocal/5ec503cc434dff29cf56633b");
  const reviewLocal = await local.json();
  const experience = await fetch(`http://nappetito-stage.herokuapp.com/api/reviewsExperience/5fa3eb9f9412c3fe0513ddc6`);
  const reviewExperience = await experience.json();
  return {
    props: {
      reviewLocal,
      reviewExperience
    }
  };
}

/***/ }),

/***/ "./styles/review.module.css":
/*!**********************************!*\
  !*** ./styles/review.module.css ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

// Exports
module.exports = {
	"tutto": "review_tutto__3yK3y",
	"rat_num": "review_rat_num__1agdL",
	"rat_star": "review_rat_star__2UdhW",
	"middle": "review_middle__2mmWo",
	"middle_main": "review_middle_main__2yBLT",
	"middle_main_heading": "review_middle_main_heading__3B6dT",
	"ratingBox": "review_ratingBox__25cu9",
	"ratDecp": "review_ratDecp__lu3KO"
};


/***/ }),

/***/ "@date-io/date-fns":
/*!************************************!*\
  !*** external "@date-io/date-fns" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@date-io/date-fns");

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/Accordion":
/*!**********************************************!*\
  !*** external "@material-ui/core/Accordion" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Accordion");

/***/ }),

/***/ "@material-ui/core/AccordionDetails":
/*!*****************************************************!*\
  !*** external "@material-ui/core/AccordionDetails" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/AccordionDetails");

/***/ }),

/***/ "@material-ui/core/AccordionSummary":
/*!*****************************************************!*\
  !*** external "@material-ui/core/AccordionSummary" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/AccordionSummary");

/***/ }),

/***/ "@material-ui/core/Box":
/*!****************************************!*\
  !*** external "@material-ui/core/Box" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Box");

/***/ }),

/***/ "@material-ui/core/Button":
/*!*******************************************!*\
  !*** external "@material-ui/core/Button" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "@material-ui/core/CircularProgress":
/*!*****************************************************!*\
  !*** external "@material-ui/core/CircularProgress" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CircularProgress");

/***/ }),

/***/ "@material-ui/core/Dialog":
/*!*******************************************!*\
  !*** external "@material-ui/core/Dialog" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Dialog");

/***/ }),

/***/ "@material-ui/core/DialogActions":
/*!**************************************************!*\
  !*** external "@material-ui/core/DialogActions" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogActions");

/***/ }),

/***/ "@material-ui/core/DialogContent":
/*!**************************************************!*\
  !*** external "@material-ui/core/DialogContent" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogContent");

/***/ }),

/***/ "@material-ui/core/DialogContentText":
/*!******************************************************!*\
  !*** external "@material-ui/core/DialogContentText" ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogContentText");

/***/ }),

/***/ "@material-ui/core/FormControl":
/*!************************************************!*\
  !*** external "@material-ui/core/FormControl" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/FormControl");

/***/ }),

/***/ "@material-ui/core/Grid":
/*!*****************************************!*\
  !*** external "@material-ui/core/Grid" ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Grid");

/***/ }),

/***/ "@material-ui/core/InputBase":
/*!**********************************************!*\
  !*** external "@material-ui/core/InputBase" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/InputBase");

/***/ }),

/***/ "@material-ui/core/NativeSelect":
/*!*************************************************!*\
  !*** external "@material-ui/core/NativeSelect" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/NativeSelect");

/***/ }),

/***/ "@material-ui/core/Slide":
/*!******************************************!*\
  !*** external "@material-ui/core/Slide" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Slide");

/***/ }),

/***/ "@material-ui/core/Typography":
/*!***********************************************!*\
  !*** external "@material-ui/core/Typography" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Typography");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "@material-ui/icons":
/*!*************************************!*\
  !*** external "@material-ui/icons" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ "@material-ui/icons/CalendarTodayOutlined":
/*!***********************************************************!*\
  !*** external "@material-ui/icons/CalendarTodayOutlined" ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/CalendarTodayOutlined");

/***/ }),

/***/ "@material-ui/icons/ExpandMore":
/*!************************************************!*\
  !*** external "@material-ui/icons/ExpandMore" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/ExpandMore");

/***/ }),

/***/ "@material-ui/icons/StarBorder":
/*!************************************************!*\
  !*** external "@material-ui/icons/StarBorder" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/StarBorder");

/***/ }),

/***/ "@material-ui/lab/Rating":
/*!******************************************!*\
  !*** external "@material-ui/lab/Rating" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/lab/Rating");

/***/ }),

/***/ "@material-ui/pickers":
/*!***************************************!*\
  !*** external "@material-ui/pickers" ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/pickers");

/***/ }),

/***/ "@material-ui/styles":
/*!**************************************!*\
  !*** external "@material-ui/styles" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/styles");

/***/ }),

/***/ "date-fns":
/*!***************************!*\
  !*** external "date-fns" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("date-fns");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9yZXZpZXdzL2Fuc3dlci9hbnN3ZXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9yZXZpZXdzL2luZGV4LmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvcmV2aWV3cy9yZXZpZXdCb3gvcmV2aWV3Qm94LmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvcmV2aWV3cy9yZXZpZXdCb3gvcmV2aWV3Qm94Lm1vZHVsZS5jc3MiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9kYXRlUGlja2VyL2RhdGVQaWNrZXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9kcm9wRG93bi9kcm9wRG93bi5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL3VpL2luZGV4LmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvdWkvbGdCdG4vbGdCdG4uanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9tb2RhbC9tb2RhbC5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL3VpL3BhZ2VUaXRsZS9wYWdlVGl0bGUuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9yYXRpbmdTdGFyL3JhdGluZ1N0YXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9zcGlubmVyL3NwaW5uZXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29udGV4dC9ib29raW5nRmV0Y2guanMiLCJ3ZWJwYWNrOi8vLy4vY29udGV4dC9kYXNoYm9hcmRGZXRjaC5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9kYXNoYm9hcmQvW3Jldmlld10uanMiLCJ3ZWJwYWNrOi8vLy4vc3R5bGVzL3Jldmlldy5tb2R1bGUuY3NzIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBkYXRlLWlvL2RhdGUtZm5zXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9BY2NvcmRpb25cIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9BY2NvcmRpb25EZXRhaWxzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQWNjb3JkaW9uU3VtbWFyeVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0JveFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0J1dHRvblwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0NpcmN1bGFyUHJvZ3Jlc3NcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dBY3Rpb25zXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nQ29udGVudFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ0NvbnRlbnRUZXh0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvRm9ybUNvbnRyb2xcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9HcmlkXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvSW5wdXRCYXNlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvTmF0aXZlU2VsZWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvU2xpZGVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL0NhbGVuZGFyVG9kYXlPdXRsaW5lZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9pY29ucy9FeHBhbmRNb3JlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL1N0YXJCb3JkZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvbGFiL1JhdGluZ1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9waWNrZXJzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL3N0eWxlc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcImRhdGUtZm5zXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9oZWFkXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9yb3V0ZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sIm5hbWVzIjpbInVzZVN0eWxlcyIsIm1ha2VTdHlsZXMiLCJ0aGVtZSIsInJvb3QiLCJ3aWR0aCIsImFjY29yZGlvbiIsImJveFNoYWRvdyIsImJvZGVyIiwic3VtbWFyeSIsImJhY2tncm91bmQiLCJjb2xvciIsImJvcmRlclJhZGl1cyIsIm1hcmdpbkxlZnQiLCJoZWFkaW5nIiwiZm9udFNpemUiLCJkZXRhaWxzIiwibWFyZ2luVG9wIiwibWVzc2FnZSIsImRpc3BsYXkiLCJmbGV4RmxvdyIsInBhZGRpbmciLCJoZWlnaHQiLCJib3JkZXIiLCJyZXNpemUiLCJvdXRsaW5lIiwiYnRuU2VuZCIsInRleHRUcmFuc2Zvcm0iLCJBbnN3ZXIiLCJhbnN3ZXIiLCJpZCIsImNsYXNzZXMiLCJyb3V0ZXIiLCJ1c2VSb3V0ZXIiLCJzZXRNZXNzYWdlIiwiUmVhY3QiLCJ1c2VTdGF0ZSIsInNlbmRSZXN1bHQiLCJmZXRjaCIsIm1ldGhvZCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwicmV2aWV3SWQiLCJ1c2VySWQiLCJoZWFkZXJzIiwidGhlbiIsInJlcyIsImpzb24iLCJyZXNwb25zZSIsImNvbnNvbGUiLCJsb2ciLCJyZWxvYWQiLCJjYXRjaCIsImVyciIsIm1hcCIsImNvbW1pdCIsImkiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJSZXZpZXdCb3giLCJuYW1lIiwiZGF0ZSIsInJldmlldyIsInJhdFRleHQiLCJyZXZSYXQiLCJjb21tZW50cyIsImFuc3dlcnMiLCJzZXRBbnN3ZXJzIiwidXNlRWZmZWN0IiwidGV4dCIsInJldmlld0JveCIsInJhdCIsImZvbnRXZWlnaHQiLCJtYXhXaWR0aCIsIkRhdGVQaWNrZXIiLCJ1c2VDb250ZXh0IiwiQm9va2luZ0NvbnRleHQiLCJzZXREYXRlIiwic2V0TW9udGgiLCJtb250aCIsImRhdGVUZXh0IiwibW9udGhfbmFtZSIsIkRhdGUiLCJnZXREYXRlIiwiZHQiLCJtbGlzdCIsImdldE1vbnRoIiwiaGFuZGxlRGF0ZUNoYW5nZSIsImRhdCIsIkRhdGVGbnNVdGlscyIsIkJvb3RzdHJhcElucHV0Iiwid2l0aFN0eWxlcyIsImlucHV0IiwibWluV2lkdGgiLCJwb3NpdGlvbiIsImJhY2tncm91bmRDb2xvciIsInBhbGV0dGUiLCJwcmltYXJ5IiwibWFpbiIsIklucHV0QmFzZSIsIm9uU3RhcnRFbmQiLCJ5ZWFyIiwiQ3VzdG9taXplZFNlbGVjdHMiLCJzZXRTdGFydERhdGUiLCJzZXRFbmREYXRlIiwiRGFzaEJvcmRDb250ZXh0IiwiZGF0ZUhhbmRsZXIiLCJldmVudCIsIm5ld0RhdGUiLCJnZXRGdWxsWWVhciIsImJ0biIsImJvcmRlclRvcExlZnRSYWRpdXMiLCJib3JkZXJCb3R0b21MZWZ0UmFkaXVzIiwiYWN0aXZlIiwiTGdCdG4iLCJzZXRCb29raW5nVHlwZSIsImJvb2tpbmdUeXBlIiwiY2FsZW5kZXIiLCJtYW5hZ2VtZW50IiwibG9jYWwiLCJleHBlcmllbmNlIiwibWFyZ2luIiwiVHJhbnNpdGlvbiIsImZvcndhcmRSZWYiLCJwcm9wcyIsInJlZiIsIlNpbXBsZU1vZGFsIiwib3BlbiIsImhhbmRsZUNsb3NlIiwic3RhdHVzSGFuZGxlciIsInRpdGxlIiwiUGFnZVRpdGxlIiwiQ3VzdG9taXplZFJhdGluZ3MiLCJyYXRpbmciLCJzaXplIiwibWF4Iiwic3BhY2luZyIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsIlNwaW5uZXIiLCJjcmVhdGVDb250ZXh0IiwiQm9va2luZ0ZldGNoIiwiY2hpbGRyZW4iLCJib29raW5ncyIsInNldEJvb2tpbmdzIiwiY29tcGxldGVkIiwic2V0Q29tcGxldGVkIiwicGVuZGluZyIsInNldFBlbmRpbmciLCJub1Nob3ciLCJzZXROb1Nob3ciLCJkZWxldGVkIiwic2V0RGVsZXRlZCIsImJvb2tpbmdEYXRhIiwic2V0Qm9va2luZ0RhdGEiLCJib29raW5nSGVhZGVyIiwic2V0Qm9va2luZ0hlYWRlciIsImZpbHRlciIsImFycmF5Iiwic3RhdHVzIiwic2V0RnVuYyIsIkZpbHRlckFycmF5IiwiZWwiLCJib29raW5nc0tleXMiLCJib29raW5nc0RhdGEiLCJmZXRjaGVyIiwicHJveHlVcmwiLCJ1cmwiLCJkYXRhIiwiT2JqZWN0IiwidmFsdWVzIiwiZm9yRWFjaCIsImtleXMiLCJrZXkiLCJwdXNoIiwibGFiZWwiLCJlcnJvciIsImVuZHBvaW50Iiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsInNldERhdGEiLCJyZXN1bHQiLCJmZXRjaGVyUmV2aWV3cyIsInVybGwiLCJEYXNoYm9hcmRGZXRjaCIsInJldmlld3MiLCJzZXRSZXZpZXdzIiwiZXhwUmV2aWV3cyIsInNldEV4cFJldmlld3MiLCJleHBCb29raW5ncyIsInNldEV4cEJvb2tpbmdzIiwiZWFybmluZ3MiLCJzZXRFYXJuaW5ncyIsInNyYyIsInR4dCIsInRvdGFsIiwiUmF0RGVzY3AiLCJyZXZpZXdDb3VudCIsInJhdERlY3AiLCJSZXZpZXciLCJyZXZpZXdMb2NhbCIsInJldmlld0V4cGVyaWVuY2UiLCJ0eXBlIiwicXVlcnkiLCJyZXZpZXdEYXRhIiwicmV2aWV3c1NpbXBsZSIsInNldFJldmlld3NTaW1wbGUiLCJyZXZpZXdzQm9va2luZyIsInNldFJldmlld3NCb29raW5nIiwicmV2aWV3c1RvdGFsIiwic2V0UmV2aWV3c1RvdGFsIiwidHlwZUZldGNoIiwic2xpY2UiLCJ0dXR0byIsInJhdF9udW0iLCJyYXRfc3RhciIsIm1pZGRsZSIsIm1pZGRsZV9tYWluIiwibWlkZGxlX21haW5faGVhZGluZyIsInJldiIsIl9pZCIsInBvc3RlZEJ5TmFtZSIsInJlcGxpZWQiLCJjcmVhdGVkQXQiLCJOdW1iZXIiLCJyYXRpbmdCb3giLCJyYXRpbmdzIiwiaXRlbSIsImdldFN0YXRpY1BhdGhzIiwicGF0aHMiLCJmYWxsYmFjayIsImdldFN0YXRpY1Byb3BzIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEZBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLE1BQU1BLFNBQVMsR0FBR0MsMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3ZDQyxNQUFJLEVBQUU7QUFDSkMsU0FBSyxFQUFFO0FBREgsR0FEaUM7QUFJdkNDLFdBQVMsRUFBRTtBQUNURCxTQUFLLEVBQUUsTUFERTtBQUVURSxhQUFTLEVBQUUsTUFGRjtBQUdUQyxTQUFLLEVBQUU7QUFIRSxHQUo0QjtBQVN2Q0MsU0FBTyxFQUFFO0FBQ1BKLFNBQUssRUFBRSxLQURBO0FBRVBLLGNBQVUsRUFBRSxzQkFGTDtBQUdQQyxTQUFLLEVBQUUsTUFIQTtBQUlQQyxnQkFBWSxFQUFFLEtBSlA7QUFLUEMsY0FBVSxFQUFFO0FBTEwsR0FUOEI7QUFnQnZDQyxTQUFPLEVBQUU7QUFDUEMsWUFBUSxFQUFFO0FBREgsR0FoQjhCO0FBbUJ2Q0MsU0FBTyxFQUFFO0FBQ1BKLGdCQUFZLEVBQUUsS0FEUDtBQUVQSyxhQUFTLEVBQUUsUUFGSjtBQUdQVixhQUFTLEVBQUU7QUFISixHQW5COEI7QUF3QnZDVyxTQUFPLEVBQUU7QUFDUEMsV0FBTyxFQUFFLE1BREY7QUFFUEMsWUFBUSxFQUFFLFFBRkg7QUFHUEMsV0FBTyxFQUFFLFVBSEY7QUFJUGhCLFNBQUssRUFBRSxNQUpBO0FBS1Asa0JBQWM7QUFDWmlCLFlBQU0sRUFBRSxPQURJO0FBRVpWLGtCQUFZLEVBQUUsS0FGRjtBQUdaUyxhQUFPLEVBQUUsUUFIRztBQUlaRSxZQUFNLEVBQUUsZ0JBSkk7QUFLWkMsWUFBTSxFQUFFLE1BTEk7QUFNWkMsYUFBTyxFQUFFO0FBTkc7QUFMUCxHQXhCOEI7QUFzQ3ZDQyxTQUFPLEVBQUU7QUFDUFQsYUFBUyxFQUFFLFFBREo7QUFFUFAsY0FBVSxFQUFFLHNCQUZMO0FBR1BDLFNBQUssRUFBRSxNQUhBO0FBSVBnQixpQkFBYSxFQUFFLFlBSlI7QUFLUCxlQUFXO0FBQ1RqQixnQkFBVSxFQUFFO0FBREg7QUFMSjtBQXRDOEIsQ0FBWixDQUFELENBQTVCO0FBaURPLFNBQVNrQixNQUFULENBQWdCO0FBQUVDLFFBQUY7QUFBVUM7QUFBVixDQUFoQixFQUFnQztBQUNyQyxRQUFNQyxPQUFPLEdBQUc5QixTQUFTLEVBQXpCO0FBQ0EsUUFBTStCLE1BQU0sR0FBR0MsNkRBQVMsRUFBeEI7QUFFQSxRQUFNLENBQUNmLE9BQUQsRUFBVWdCLFVBQVYsSUFBd0JDLDRDQUFLLENBQUNDLFFBQU4sQ0FBZSxFQUFmLENBQTlCOztBQUVBLFFBQU1DLFVBQVUsR0FBRyxNQUFNO0FBQ3ZCQyxTQUFLLENBQ0gscUZBREcsRUFFSDtBQUNFQyxZQUFNLEVBQUUsTUFEVjtBQUVFQyxVQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ25CQyxnQkFBUSxFQUFFYixFQURTO0FBRW5CYyxjQUFNLEVBQUUsMEJBRlc7QUFHbkIxQixlQUFPLEVBQUVBO0FBSFUsT0FBZixDQUZSO0FBT0UyQixhQUFPLEVBQUU7QUFBRSx3QkFBZ0I7QUFBbEI7QUFQWCxLQUZHLENBQUwsQ0FZR0MsSUFaSCxDQVlTQyxHQUFELElBQVNBLEdBQUcsQ0FBQ0MsSUFBSixFQVpqQixFQWFHRixJQWJILENBYVNHLFFBQUQsSUFBYztBQUNsQkMsYUFBTyxDQUFDQyxHQUFSLENBQVksYUFBWixFQUEyQkYsUUFBM0I7QUFDQWpCLFlBQU0sQ0FBQ29CLE1BQVA7QUFDRCxLQWhCSCxFQWlCR0MsS0FqQkgsQ0FpQlVDLEdBQUQsSUFBUztBQUNkSixhQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCRyxHQUF4QjtBQUNBdEIsWUFBTSxDQUFDb0IsTUFBUDtBQUNELEtBcEJIO0FBcUJELEdBdEJEOztBQXdCQSxzQkFDRTtBQUFLLGFBQVMsRUFBRXJCLE9BQU8sQ0FBQzNCLElBQXhCO0FBQUEsMkJBQ0UscUVBQUMsa0VBQUQ7QUFBVyxlQUFTLEVBQUUyQixPQUFPLENBQUN6QixTQUE5QjtBQUFBLDhCQUNFLHFFQUFDLHlFQUFEO0FBQ0UsaUJBQVMsRUFBRXlCLE9BQU8sQ0FBQ3RCLE9BRHJCO0FBRUUsa0JBQVUsZUFBRSxxRUFBQyxvRUFBRDtBQUFnQixlQUFLLEVBQUU7QUFBRUUsaUJBQUssRUFBRTtBQUFUO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRmQ7QUFHRSx5QkFBYyxpQkFIaEI7QUFJRSxVQUFFLEVBQUMsZ0JBSkw7QUFBQSwrQkFNRSxxRUFBQyxtRUFBRDtBQUFZLG1CQUFTLEVBQUVvQixPQUFPLENBQUNqQixPQUEvQjtBQUFBLG9CQUNHZSxNQUFNLElBQUlBLE1BQU0sQ0FBQyxDQUFELENBQWhCLEdBQXNCLFlBQXRCLEdBQXFDO0FBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFXRSxxRUFBQyx5RUFBRDtBQUFrQixpQkFBUyxFQUFFRSxPQUFPLENBQUNmLE9BQXJDO0FBQUEsa0JBQ0dhLE1BQU0sSUFBSUEsTUFBTSxDQUFDLENBQUQsQ0FBaEIsR0FDQ0EsTUFBTSxDQUFDMEIsR0FBUCxDQUFXLENBQUNDLE1BQUQsRUFBU0MsQ0FBVCxrQkFBZSxxRUFBQyxtRUFBRDtBQUFBLG9CQUFxQkQ7QUFBckIsV0FBaUJDLENBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQTFCLENBREQsZ0JBR0M7QUFBSyxtQkFBUyxFQUFFMUIsT0FBTyxDQUFDYixPQUF4QjtBQUFBLGtDQUNFO0FBQ0UsdUJBQVcsRUFBQyxjQURkO0FBRUUsaUJBQUssRUFBRUEsT0FGVDtBQUdFLG9CQUFRLEVBQUd3QyxDQUFELElBQU94QixVQUFVLENBQUN3QixDQUFDLENBQUNDLE1BQUYsQ0FBU0MsS0FBVjtBQUg3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBTUUscUVBQUMsd0RBQUQ7QUFBUSxtQkFBTyxFQUFFLE1BQU12QixVQUFVLEVBQWpDO0FBQXFDLHFCQUFTLEVBQUVOLE9BQU8sQ0FBQ0wsT0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQWdDRCxDOzs7Ozs7Ozs7Ozs7QUMxSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFFQTtBQUVBO0FBQ0E7QUFFQTtBQUVPLFNBQVNtQyxTQUFULENBQW1CO0FBQ3hCQyxNQUR3QjtBQUV4QkMsTUFGd0I7QUFHeEJDLFFBSHdCO0FBSXhCQyxTQUp3QjtBQUt4QkMsUUFMd0I7QUFNeEJDLFVBTndCO0FBT3hCckM7QUFQd0IsQ0FBbkIsRUFRSjtBQUNELFFBQU0sQ0FBQ3NDLE9BQUQsRUFBVUMsVUFBVixJQUF3QmxDLDRDQUFLLENBQUNDLFFBQU4sRUFBOUI7QUFDQUQsOENBQUssQ0FBQ21DLFNBQU4sQ0FBZ0IsTUFBTTtBQUNwQixVQUFNQyxJQUFJLEdBQUdKLFFBQVEsQ0FBQ1osR0FBVCxDQUFhLENBQUM7QUFBRWdCO0FBQUYsS0FBRCxLQUFjQSxJQUEzQixDQUFiO0FBQ0FGLGNBQVUsQ0FBQ0UsSUFBRCxDQUFWO0FBQ0QsR0FIRCxFQUdHLENBQUNKLFFBQUQsQ0FISDtBQUtBLHNCQUNFO0FBQUssYUFBUyxFQUFFcEMsNERBQU8sQ0FBQ3lDLFNBQXhCO0FBQUEsNEJBQ0UscUVBQUMsNERBQUQ7QUFBWSxhQUFPLEVBQUMsSUFBcEI7QUFBQSxnQkFBMEJWO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUVFLHFFQUFDLDREQUFEO0FBQVksV0FBSyxFQUFFO0FBQUVuRCxhQUFLLEVBQUU7QUFBVCxPQUFuQjtBQUFzRCxhQUFPLEVBQUMsV0FBOUQ7QUFBQSxnQkFDR29EO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBS0U7QUFBSyxlQUFTLEVBQUVoQyw0REFBTyxDQUFDMEMsR0FBeEI7QUFBQSw4QkFDRSxxRUFBQyw0REFBRDtBQUFZLGFBQUssRUFBRTtBQUFFQyxvQkFBVSxFQUFFO0FBQWQsU0FBbkI7QUFBMEMsZUFBTyxFQUFDLFdBQWxEO0FBQUEsa0JBQ0dUO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBSUU7QUFBSyxhQUFLLEVBQUU7QUFBRWhELG1CQUFTLEVBQUU7QUFBYixTQUFaO0FBQUEsK0JBQ0UscUVBQUMscURBQUQ7QUFBbUIsY0FBSSxFQUFDLE9BQXhCO0FBQWdDLGFBQUcsRUFBRSxDQUFyQztBQUF3QyxnQkFBTSxFQUFFaUQ7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFMRixlQWFFLHFFQUFDLDREQUFEO0FBQVksV0FBSyxFQUFFO0FBQUVTLGdCQUFRLEVBQUU7QUFBWixPQUFuQjtBQUF3QyxhQUFPLEVBQUMsV0FBaEQ7QUFBQSxnQkFDR1g7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYkYsZUFnQkUscUVBQUMsc0RBQUQ7QUFBTSxlQUFTLE1BQWY7QUFBZ0IsYUFBTyxFQUFDLFVBQXhCO0FBQUEsNkJBQ0UscUVBQUMsd0NBQUQ7QUFBUSxjQUFNLEVBQUVJLE9BQWhCO0FBQXlCLFVBQUUsRUFBRXRDO0FBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBc0JELEM7Ozs7Ozs7Ozs7O0FDOUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0xBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBRUE7QUFFTyxTQUFTOEMsVUFBVCxHQUFzQjtBQUMzQixRQUFNaEIsS0FBSyxHQUFHaUIsd0RBQVUsQ0FBQ0Msb0VBQUQsQ0FBeEI7QUFDQSxRQUFNO0FBQUVmLFFBQUY7QUFBUWdCLFdBQVI7QUFBaUJDLFlBQWpCO0FBQTJCQztBQUEzQixNQUFxQ3JCLEtBQTNDO0FBRUF6Qiw4Q0FBSyxDQUFDbUMsU0FBTixDQUFnQixNQUFNO0FBQ3BCLFVBQU1ZLFFBQVEsR0FBR0MsVUFBVSxDQUFDLElBQUlDLElBQUosRUFBRCxDQUFWLEdBQXlCLEdBQXpCLEdBQStCLElBQUlBLElBQUosR0FBV0MsT0FBWCxFQUFoRDtBQUNBTCxZQUFRLENBQUNFLFFBQUQsQ0FBUjtBQUNBaEMsV0FBTyxDQUFDQyxHQUFSLENBQVk4QixLQUFaO0FBQ0QsR0FKRCxFQUlHLEVBSkg7O0FBTUEsUUFBTUUsVUFBVSxHQUFJRyxFQUFELElBQVE7QUFDekIsVUFBTUMsS0FBSyxHQUFHLENBQ1osU0FEWSxFQUVaLFVBRlksRUFHWixPQUhZLEVBSVosT0FKWSxFQUtaLEtBTFksRUFNWixNQU5ZLEVBT1osTUFQWSxFQVFaLFFBUlksRUFTWixXQVRZLEVBVVosU0FWWSxFQVdaLFVBWFksRUFZWixVQVpZLENBQWQ7QUFjQSxXQUFPQSxLQUFLLENBQUNELEVBQUUsQ0FBQ0UsUUFBSCxFQUFELENBQVo7QUFDRCxHQWhCRDs7QUFrQkEsUUFBTUMsZ0JBQWdCLEdBQUlDLEdBQUQsSUFBUztBQUNoQ1gsV0FBTyxDQUFDVyxHQUFELENBQVA7QUFDQSxVQUFNUixRQUFRLEdBQUdDLFVBQVUsQ0FBQyxJQUFJQyxJQUFKLENBQVNNLEdBQVQsQ0FBRCxDQUFWLEdBQTRCLEdBQTVCLEdBQWtDQSxHQUFHLENBQUNMLE9BQUosRUFBbkQ7QUFDQUwsWUFBUSxDQUFDRSxRQUFELENBQVI7QUFDRCxHQUpEOztBQU1BLHNCQUNFLHFFQUFDLDRFQUFEO0FBQXlCLFNBQUssRUFBRVMsd0RBQWhDO0FBQUEsMkJBQ0UscUVBQUMsNkRBQUQ7QUFBTSxVQUFJLE1BQVY7QUFBVyxRQUFFLEVBQUUsQ0FBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxhQUFmO0FBQUEsK0JBQ0UscUVBQUMsdUVBQUQ7QUFDRSxzQkFBWSxlQUNWO0FBQ0UsaUJBQUssRUFBQyw0QkFEUjtBQUVFLGlCQUFLLEVBQUMsSUFGUjtBQUdFLGtCQUFNLEVBQUMsSUFIVDtBQUlFLG1CQUFPLEVBQUMsV0FKVjtBQUFBLG1DQU1FO0FBQ0UsZ0JBQUUsRUFBQyxhQURMO0FBRUUsMkJBQVUsYUFGWjtBQUdFLHVCQUFTLEVBQUMsNEJBSFo7QUFBQSxzQ0FLRTtBQUNFLGtCQUFFLEVBQUMsWUFETDtBQUVFLDZCQUFVLFlBRlo7QUFHRSxpQkFBQyxFQUFDLDBSQUhKO0FBSUUseUJBQVMsRUFBQyxzQkFKWjtBQUtFLG9CQUFJLEVBQUMsU0FMUDtBQU1FLHNCQUFNLEVBQUMsU0FOVDtBQU9FLGdDQUFhO0FBUGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFMRixlQWNFO0FBQ0Usa0JBQUUsRUFBQyxjQURMO0FBRUUsNkJBQVUsY0FGWjtBQUdFLGtCQUFFLEVBQUMsT0FITDtBQUlFLGtCQUFFLEVBQUMsT0FKTDtBQUtFLGtCQUFFLEVBQUMsT0FMTDtBQU1FLGtCQUFFLEVBQUMsT0FOTDtBQU9FLHlCQUFTLEVBQUMsMkJBUFo7QUFRRSxvQkFBSSxFQUFDO0FBUlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFkRixlQXdCRTtBQUNFLGtCQUFFLEVBQUMsY0FETDtBQUVFLDZCQUFVLGNBRlo7QUFHRSxrQkFBRSxFQUFDLE9BSEw7QUFJRSxrQkFBRSxFQUFDLE9BSkw7QUFLRSxrQkFBRSxFQUFDLE9BTEw7QUFNRSxrQkFBRSxFQUFDLE9BTkw7QUFPRSx5QkFBUyxFQUFDLDJCQVBaO0FBUUUsb0JBQUksRUFBQztBQVJQO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBeEJGLGVBa0NFO0FBQ0Usa0JBQUUsRUFBQyxjQURMO0FBRUUsNkJBQVUsY0FGWjtBQUdFLGtCQUFFLEVBQUMsT0FITDtBQUlFLGtCQUFFLEVBQUMsT0FKTDtBQUtFLGtCQUFFLEVBQUMsT0FMTDtBQU1FLGtCQUFFLEVBQUMsT0FOTDtBQU9FLHlCQUFTLEVBQUMsMkJBUFo7QUFRRSxvQkFBSSxFQUFDO0FBUlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFsQ0YsZUE0Q0U7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLE9BSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNUNGLGVBb0RFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxLQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXBERixlQTRERTtBQUNFLGtCQUFFLEVBQUMsZ0JBREw7QUFFRSw2QkFBVSxnQkFGWjtBQUdFLHFCQUFLLEVBQUMsT0FIUjtBQUlFLHNCQUFNLEVBQUMsT0FKVDtBQUtFLHlCQUFTLEVBQUMsNEJBTFo7QUFNRSxvQkFBSSxFQUFDO0FBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkE1REYsZUFvRUU7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLEtBSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBcEVGLGVBNEVFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxPQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQTVFRixlQW9GRTtBQUNFLGtCQUFFLEVBQUMsZ0JBREw7QUFFRSw2QkFBVSxnQkFGWjtBQUdFLHFCQUFLLEVBQUMsS0FIUjtBQUlFLHNCQUFNLEVBQUMsT0FKVDtBQUtFLHlCQUFTLEVBQUMsNEJBTFo7QUFNRSxvQkFBSSxFQUFDO0FBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFwRkYsZUE0RkU7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLE9BSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNUZGLGVBb0dFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxLQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXBHRixlQTRHRTtBQUNFLGtCQUFFLEVBQUMsZ0JBREw7QUFFRSw2QkFBVSxnQkFGWjtBQUdFLHFCQUFLLEVBQUMsT0FIUjtBQUlFLHNCQUFNLEVBQUMsT0FKVDtBQUtFLHlCQUFTLEVBQUMsNEJBTFo7QUFNRSxvQkFBSSxFQUFDO0FBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkE1R0YsZUFvSEU7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLEtBSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBcEhGLGVBNEhFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxPQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQTVIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZKO0FBK0lFLGdCQUFNLEVBQUMsUUEvSVQ7QUFnSkUsZUFBSyxFQUFFNUIsSUFoSlQ7QUFpSkUsa0JBQVEsRUFBRTBCLGdCQWpKWjtBQWtKRSxnQkFBTSxFQUFDLGFBbEpUO0FBbUpFLDZCQUFtQixFQUFFO0FBQ25CLDBCQUFjO0FBREs7QUFuSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQStKRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hORDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQSxNQUFNRyxjQUFjLEdBQUdDLDJFQUFVLENBQUUxRixLQUFELEtBQVk7QUFDNUMyRixPQUFLLEVBQUU7QUFDTEMsWUFBUSxFQUFFLE1BREw7QUFFTG5GLGdCQUFZLEVBQUUsQ0FGVDtBQUdMb0YsWUFBUSxFQUFFLFVBSEw7QUFJTEMsbUJBQWUsRUFBRTlGLEtBQUssQ0FBQytGLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQkMsSUFKbEM7QUFLTDdFLFVBQU0sRUFBRSxNQUxIO0FBTUxSLFlBQVEsRUFBRSxFQU5MO0FBT0xNLFdBQU8sRUFBRSxvQkFQSjtBQVFMVixTQUFLLEVBQUUsTUFSRjtBQVNMLGVBQVc7QUFDVEQsZ0JBQVUsRUFBRVAsS0FBSyxDQUFDK0YsT0FBTixDQUFjQyxPQUFkLENBQXNCQyxJQUR6QjtBQUVUeEYsa0JBQVksRUFBRTtBQUZMO0FBVE47QUFEcUMsQ0FBWixDQUFELENBQVYsQ0FlbkJ5RixrRUFmbUIsQ0FBdkI7O0FBaUJBLE1BQU1DLFVBQVUsR0FBRyxDQUFDdkMsSUFBRCxFQUFPa0IsS0FBUCxFQUFjc0IsSUFBZCxLQUF1QjtBQUN4QyxTQUFRLEdBQUVBLElBQUssSUFBR3RCLEtBQU0sSUFBR2xCLElBQUssRUFBaEM7QUFDRCxDQUZEOztBQUlPLFNBQVN5QyxpQkFBVCxHQUE2QjtBQUNsQyxRQUFNLENBQUN6QyxJQUFELEVBQU9nQixPQUFQLElBQWtCNUMsNENBQUssQ0FBQ0MsUUFBTixDQUFlLE9BQWYsQ0FBeEI7QUFFQSxRQUFNO0FBQUVxRSxnQkFBRjtBQUFnQkM7QUFBaEIsTUFBK0I3Qix3REFBVSxDQUFDOEIsdUVBQUQsQ0FBL0M7QUFFQXJDLHlEQUFTLENBQUMsTUFBTTtBQUNkcEIsV0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUF1QlksSUFBdkI7QUFDRCxHQUZRLEVBRU4sQ0FBQ0EsSUFBRCxDQUZNLENBQVQ7O0FBSUEsUUFBTTZDLFdBQVcsR0FBSUMsS0FBRCxJQUFXO0FBQzdCLFVBQU1DLE9BQU8sR0FBRyxJQUFJMUIsSUFBSixFQUFoQjtBQUNBLFVBQU14QixLQUFLLEdBQUdpRCxLQUFLLENBQUNsRCxNQUFOLENBQWFDLEtBQTNCOztBQUNBLFlBQVFBLEtBQVI7QUFDRSxXQUFLLE9BQUw7QUFDRTZDLG9CQUFZLENBQ1ZILFVBQVUsQ0FDUlEsT0FBTyxDQUFDekIsT0FBUixFQURRLEVBRVJ5QixPQUFPLENBQUN0QixRQUFSLEtBQXFCLENBRmIsRUFHUnNCLE9BQU8sQ0FBQ0MsV0FBUixFQUhRLENBREEsQ0FBWjtBQU9BTCxrQkFBVSxDQUNSSixVQUFVLENBQ1JRLE9BQU8sQ0FBQ3pCLE9BQVIsRUFEUSxFQUVSeUIsT0FBTyxDQUFDdEIsUUFBUixLQUFxQixDQUZiLEVBR1JzQixPQUFPLENBQUNDLFdBQVIsRUFIUSxDQURGLENBQVY7QUFPQTs7QUFDRixXQUFLLFNBQUw7QUFDRU4sb0JBQVksQ0FDVkgsVUFBVSxDQUFDLElBQUQsRUFBT1EsT0FBTyxDQUFDdEIsUUFBUixLQUFxQixDQUE1QixFQUErQnNCLE9BQU8sQ0FBQ0MsV0FBUixFQUEvQixDQURBLENBQVo7QUFHQUwsa0JBQVUsQ0FDUkosVUFBVSxDQUFDLElBQUQsRUFBT1EsT0FBTyxDQUFDdEIsUUFBUixLQUFxQixDQUE1QixFQUErQnNCLE9BQU8sQ0FBQ0MsV0FBUixFQUEvQixDQURGLENBQVY7QUFHQTs7QUFDRixXQUFLLE9BQUw7QUFDRU4sb0JBQVksQ0FDVkgsVUFBVSxDQUFDLElBQUQsRUFBT1EsT0FBTyxDQUFDdEIsUUFBUixLQUFxQixDQUE1QixFQUErQnNCLE9BQU8sQ0FBQ0MsV0FBUixFQUEvQixDQURBLENBQVo7QUFHQUwsa0JBQVUsQ0FDUkosVUFBVSxDQUFDLElBQUQsRUFBT1EsT0FBTyxDQUFDdEIsUUFBUixLQUFxQixDQUE1QixFQUErQnNCLE9BQU8sQ0FBQ0MsV0FBUixFQUEvQixDQURGLENBQVY7QUFHQTs7QUFDRixXQUFLLEtBQUw7QUFDRU4sb0JBQVksQ0FDVkgsVUFBVSxDQUFDLElBQUQsRUFBT1EsT0FBTyxDQUFDdEIsUUFBUixLQUFxQixDQUE1QixFQUErQnNCLE9BQU8sQ0FBQ0MsV0FBUixFQUEvQixDQURBLENBQVo7QUFHQUwsa0JBQVUsQ0FDUkosVUFBVSxDQUFDLElBQUQsRUFBT1EsT0FBTyxDQUFDdEIsUUFBUixLQUFxQixDQUE1QixFQUErQnNCLE9BQU8sQ0FBQ0MsV0FBUixFQUEvQixDQURGLENBQVY7QUFHQTs7QUFDRixXQUFLLE1BQUw7QUFDRU4sb0JBQVksQ0FBQ0gsVUFBVSxDQUFDLElBQUQsRUFBTyxJQUFQLEVBQWFRLE9BQU8sQ0FBQ0MsV0FBUixLQUF3QixDQUFyQyxDQUFYLENBQVo7QUFDQUwsa0JBQVUsQ0FBQ0osVUFBVSxDQUFDLElBQUQsRUFBTyxJQUFQLEVBQWFRLE9BQU8sQ0FBQ0MsV0FBUixLQUF3QixDQUFyQyxDQUFYLENBQVY7QUFDQTs7QUFDRjtBQUNFO0FBOUNKOztBQWdEQWhDLFdBQU8sQ0FBQzhCLEtBQUssQ0FBQ2xELE1BQU4sQ0FBYUMsS0FBZCxDQUFQO0FBQ0QsR0FwREQ7O0FBc0RBLHNCQUNFO0FBQUEsMkJBQ0UscUVBQUMsb0VBQUQ7QUFBQSw2QkFDRSxxRUFBQyxxRUFBRDtBQUNFLFVBQUUsRUFBQywrQkFETDtBQUVFLGFBQUssRUFBRUcsSUFGVDtBQUdFLGdCQUFRLEVBQUU2QyxXQUhaO0FBSUUsYUFBSyxlQUFFLHFFQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFKVDtBQUFBLGdDQU1FO0FBQVEsZUFBSyxFQUFFO0FBQUVqRyxpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsT0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTkYsZUFTRTtBQUFRLGVBQUssRUFBRTtBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsU0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVEYsZUFZRTtBQUFRLGVBQUssRUFBRTtBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsT0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkYsZUFlRTtBQUFRLGVBQUssRUFBRTtBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZkYsZUFrQkU7QUFBUSxlQUFLLEVBQUU7QUFBRUEsaUJBQUssRUFBRTtBQUFULFdBQWY7QUFBa0MsZUFBSyxFQUFFLE1BQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBNEJELEM7Ozs7Ozs7Ozs7OztBQ3hIRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMQTtBQUVBO0FBQ0E7QUFFQTtBQUVBLE1BQU1WLFNBQVMsR0FBR0Msc0VBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3ZDQyxNQUFJLEVBQUU7QUFDSmEsYUFBUyxFQUFFO0FBRFAsR0FEaUM7QUFJdkMrRixLQUFHLEVBQUU7QUFDSDNHLFNBQUssRUFBRSxNQURKO0FBRUhnQixXQUFPLEVBQUUsVUFGTjtBQUdITSxpQkFBYSxFQUFFLFlBSFo7QUFJSGpCLGNBQVUsRUFBRSxTQUpUO0FBS0h1Ryx1QkFBbUIsRUFBRSxHQUxsQjtBQU1IQywwQkFBc0IsRUFBRSxHQU5yQjtBQU9IdkcsU0FBSyxFQUFFLE1BUEo7QUFRSCxlQUFXO0FBQ1RELGdCQUFVLEVBQUU7QUFESDtBQVJSLEdBSmtDO0FBZ0J2Q3lHLFFBQU0sRUFBRTtBQUNOOUcsU0FBSyxFQUFFLE1BREQ7QUFFTk0sU0FBSyxFQUFFLE1BRkQ7QUFHTkQsY0FBVSxFQUFFUCxLQUFLLENBQUMrRixPQUFOLENBQWNDLE9BQWQsQ0FBc0JDLElBSDVCO0FBSU4vRixTQUFLLEVBQUUsTUFKRDtBQUtOZ0IsV0FBTyxFQUFFLFVBTEg7QUFNTk0saUJBQWEsRUFBRSxZQU5UO0FBT05zRix1QkFBbUIsRUFBRSxHQVBmO0FBUU5DLDBCQUFzQixFQUFFLEdBUmxCO0FBU04sZUFBVztBQUNUeEcsZ0JBQVUsRUFBRTtBQURIO0FBVEw7QUFoQitCLENBQVosQ0FBRCxDQUE1QjtBQStCTyxNQUFNMEcsS0FBSyxHQUFHLENBQUM7QUFDcEJDLGdCQURvQjtBQUVwQkMsYUFGb0I7QUFHcEJDLFVBSG9CO0FBSXBCQztBQUpvQixDQUFELEtBS2Y7QUFDSixRQUFNekYsT0FBTyxHQUFHOUIsU0FBUyxFQUF6QjtBQUVBLE1BQUl3SCxLQUFLLEdBQUcsZUFBWjtBQUNBLE1BQUlDLFVBQVUsR0FBRyxvQkFBakI7O0FBRUEsTUFBSUYsVUFBSixFQUFnQjtBQUNkQyxTQUFLLEdBQUcsUUFBUjtBQUNBQyxjQUFVLEdBQUcsYUFBYjtBQUNEOztBQUVELHNCQUNFLHFFQUFDLHNEQUFEO0FBQU0sYUFBUyxNQUFmO0FBQWdCLFFBQUksTUFBcEI7QUFBcUIsTUFBRSxFQUFFLENBQXpCO0FBQTRCLGFBQVMsRUFBRTNGLE9BQU8sQ0FBQzNCLElBQS9DO0FBQXFELGdCQUFZLEVBQUMsUUFBbEU7QUFBQSw0QkFDRSxxRUFBQyxzREFBRDtBQUFNLFVBQUksTUFBVjtBQUFXLFFBQUUsRUFBRSxDQUFmO0FBQUEsNkJBQ0UscUVBQUMsd0RBQUQ7QUFDRSxlQUFPLEVBQUUsTUFBTWlILGNBQWMsQ0FBQ0ksS0FBRCxDQUQvQjtBQUVFLGlCQUFTLEVBQUVILFdBQVcsS0FBS0csS0FBaEIsR0FBd0IxRixPQUFPLENBQUNvRixNQUFoQyxHQUF5Q3BGLE9BQU8sQ0FBQ2lGLEdBRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVNFLHFFQUFDLHNEQUFEO0FBQU0sVUFBSSxNQUFWO0FBQVcsUUFBRSxFQUFFLENBQWY7QUFBQSw2QkFDRSxxRUFBQyx3REFBRDtBQUNFLGVBQU8sRUFBRSxNQUFNSyxjQUFjLENBQUNLLFVBQUQsQ0FEL0I7QUFFRSxpQkFBUyxFQUFFSixXQUFXLEtBQUtJLFVBQWhCLEdBQTZCM0YsT0FBTyxDQUFDb0YsTUFBckMsR0FBOENwRixPQUFPLENBQUNpRixHQUZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVEYsZUFpQkUscUVBQUMsc0RBQUQ7QUFBTSxVQUFJLE1BQVY7QUFBVyxRQUFFLEVBQUUsQ0FBZjtBQUFBLDZCQUNFO0FBQ0UsYUFBSyxFQUFFO0FBQ0xXLGdCQUFNLEVBQUU7QUFESCxTQURUO0FBQUEsa0JBS0dKLFFBQVEsaUJBQUkscUVBQUMsNENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTZCRCxDQTdDTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOztBQUNBO0FBRUEsTUFBTUssVUFBVSxnQkFBR3pGLDRDQUFLLENBQUMwRixVQUFOLENBQWlCLFNBQVNELFVBQVQsQ0FBb0JFLEtBQXBCLEVBQTJCQyxHQUEzQixFQUFnQztBQUNsRSxzQkFBTyxxRUFBQyw4REFBRDtBQUFPLGFBQVMsRUFBQyxJQUFqQjtBQUFzQixPQUFHLEVBQUVBO0FBQTNCLEtBQW9DRCxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDRCxDQUZrQixDQUFuQjtBQUlPLFNBQVNFLFdBQVQsQ0FBcUI7QUFBRUMsTUFBRjtBQUFRQyxhQUFSO0FBQXFCQztBQUFyQixDQUFyQixFQUEyRDtBQUNoRSxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLCtEQUFEO0FBQ0UsVUFBSSxFQUFFRixJQURSO0FBRUUseUJBQW1CLEVBQUVMLFVBRnZCO0FBR0UsaUJBQVcsTUFIYjtBQUlFLGFBQU8sRUFBRU0sV0FKWDtBQUtFLHlCQUFnQiwwQkFMbEI7QUFNRSwwQkFBaUIsZ0NBTm5CO0FBQUEsOEJBUUUscUVBQUMsc0VBQUQ7QUFBQSwrQkFDRSxxRUFBQywwRUFBRDtBQUFtQixZQUFFLEVBQUMsZ0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVJGLGVBYUUscUVBQUMsc0VBQUQ7QUFBQSxnQ0FDRSxxRUFBQywrREFBRDtBQUFRLGlCQUFPLEVBQUVBLFdBQWpCO0FBQThCLGVBQUssRUFBQyxTQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUlFLHFFQUFDLCtEQUFEO0FBQVEsaUJBQU8sRUFBRUMsYUFBakI7QUFBZ0MsZUFBSyxFQUFDLFNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQTBCRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4Q0Q7QUFFQTtBQUNBO0FBRUEsTUFBTWxJLFNBQVMsR0FBR0Msc0VBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3ZDaUksT0FBSyxFQUFFO0FBQ0x6RyxpQkFBYSxFQUFFO0FBRFY7QUFEZ0MsQ0FBWixDQUFELENBQTVCO0FBTU8sTUFBTTBHLFNBQVMsR0FBRyxDQUFDO0FBQUU5RDtBQUFGLENBQUQsS0FBYztBQUNyQyxRQUFNeEMsT0FBTyxHQUFHOUIsU0FBUyxFQUF6QjtBQUNBLHNCQUNFO0FBQUEsMkJBQ0UscUVBQUMsc0RBQUQ7QUFBTSxlQUFTLE1BQWY7QUFBQSw2QkFDRSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQUEsK0JBQ0UscUVBQUMsNERBQUQ7QUFBWSxtQkFBUyxFQUFFOEIsT0FBTyxDQUFDcUcsS0FBL0I7QUFBc0MsaUJBQU8sRUFBQyxJQUE5QztBQUFBLG9CQUNHN0Q7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFXRCxDQWJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWFA7QUFDQTtBQUNBO0FBQ0E7QUFFTyxTQUFTK0QsaUJBQVQsQ0FBMkI7QUFBRUMsUUFBRjtBQUFVQyxNQUFWO0FBQWdCQyxLQUFHLEdBQUcsQ0FBdEI7QUFBeUJ2RTtBQUF6QixDQUEzQixFQUE4RDtBQUNuRSxNQUFJTixLQUFLLEdBQUcsSUFBWjs7QUFDQSxNQUFJMkUsTUFBTSxLQUFLLENBQVgsSUFBZ0IsQ0FBQ3JFLE1BQXJCLEVBQTZCO0FBQzNCTixTQUFLLEdBQUcsQ0FBUjtBQUNELEdBRkQsTUFFTyxJQUFJMkUsTUFBTSxHQUFHLENBQVQsSUFBYyxDQUFDckUsTUFBbkIsRUFBMkI7QUFDaENOLFNBQUssR0FBRyxHQUFSO0FBQ0Q7O0FBQ0Qsc0JBQ0U7QUFBQSwyQkFDRSxxRUFBQyw0REFBRDtBQUFLLGVBQVMsRUFBQyxVQUFmO0FBQTBCLFFBQUUsRUFBRSxDQUE5QjtBQUFpQyxpQkFBVyxFQUFDLGFBQTdDO0FBQUEsNkJBQ0UscUVBQUMsOERBQUQ7QUFDRSxhQUFLLEVBQUU7QUFBRWpELGVBQUssRUFBRTtBQUFULFNBRFQ7QUFFRSxZQUFJLEVBQUMsa0JBRlA7QUFHRSxnQkFBUSxNQUhWO0FBSUUsV0FBRyxFQUFFOEgsR0FKUDtBQUtFLGlCQUFTLEVBQUUsR0FMYjtBQU1FLGFBQUssRUFBRTdFLEtBQUssR0FBR0EsS0FBSCxHQUFXTSxNQU56QjtBQU9FLFlBQUksRUFBRXNFLElBUFI7QUFRRSxpQkFBUyxlQUFFLHFFQUFDLG9FQUFEO0FBQWdCLGtCQUFRLEVBQUM7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBZ0JELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUJEO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTXZJLFNBQVMsR0FBR0MsMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3ZDQyxNQUFJLEVBQUU7QUFDSmUsV0FBTyxFQUFFLE1BREw7QUFFSixpQkFBYTtBQUNYTixnQkFBVSxFQUFFVixLQUFLLENBQUN1SSxPQUFOLENBQWMsQ0FBZDtBQURELEtBRlQ7QUFLSnJJLFNBQUssRUFBRSxNQUxIO0FBTUppQixVQUFNLEVBQUUsT0FOSjtBQU9KcUgsa0JBQWMsRUFBRSxRQVBaO0FBUUpDLGNBQVUsRUFBRTtBQVJSO0FBRGlDLENBQVosQ0FBRCxDQUE1QjtBQWFPLFNBQVNDLE9BQVQsR0FBbUI7QUFDeEIsUUFBTTlHLE9BQU8sR0FBRzlCLFNBQVMsRUFBekI7QUFFQSxzQkFDRTtBQUFLLGFBQVMsRUFBRThCLE9BQU8sQ0FBQzNCLElBQXhCO0FBQUEsMkJBQ0UscUVBQUMseUVBQUQ7QUFBa0IsV0FBSyxFQUFDO0FBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFLRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQkQ7QUFFTyxNQUFNMEUsY0FBYyxnQkFBR2dFLDJEQUFhLEVBQXBDO0FBRVEsU0FBU0MsWUFBVCxDQUFzQjtBQUFFQztBQUFGLENBQXRCLEVBQW9DO0FBQ2pELFFBQU07QUFBQSxPQUFDQyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQjlHLHNEQUFRLEVBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUMrRyxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0QmhILHNEQUFRLEVBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNpSCxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QmxILHNEQUFRLEVBQXRDO0FBQ0EsUUFBTTtBQUFBLE9BQUNtSCxNQUFEO0FBQUEsT0FBU0M7QUFBVCxNQUFzQnBILHNEQUFRLEVBQXBDO0FBQ0EsUUFBTTtBQUFBLE9BQUNxSCxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QnRILHNEQUFRLEVBQXRDO0FBQ0EsUUFBTTtBQUFBLE9BQUNrRixXQUFEO0FBQUEsT0FBY0Q7QUFBZCxNQUFnQ2pGLHNEQUFRLENBQUMsZUFBRCxDQUE5QztBQUVBLFFBQU07QUFBQSxPQUFDdUgsV0FBRDtBQUFBLE9BQWNDO0FBQWQsTUFBZ0N4SCxzREFBUSxFQUE5QztBQUNBLFFBQU07QUFBQSxPQUFDeUgsYUFBRDtBQUFBLE9BQWdCQztBQUFoQixNQUFvQzFILHNEQUFRLEVBQWxEO0FBRUEsUUFBTTtBQUFBLE9BQUMyQixJQUFEO0FBQUEsT0FBT2dCO0FBQVAsTUFBa0IzQyxzREFBUSxDQUFDLElBQUlnRCxJQUFKLEVBQUQsQ0FBaEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0gsS0FBRDtBQUFBLE9BQVFEO0FBQVIsTUFBb0I1QyxzREFBUSxDQUFDLEVBQUQsQ0FBbEM7O0FBRUEsUUFBTTJILE1BQU0sR0FBRyxDQUFDQyxLQUFELEVBQVFDLE1BQVIsRUFBZ0JDLE9BQWhCLEtBQTRCO0FBQ3pDLFVBQU1DLFdBQVcsR0FBR0gsS0FBSyxDQUFDRCxNQUFOLENBQWNLLEVBQUQsSUFBUUEsRUFBRSxDQUFDSCxNQUFILEtBQWNBLE1BQW5DLENBQXBCO0FBQ0FDLFdBQU8sQ0FBQ0MsV0FBRCxDQUFQO0FBQ0QsR0FIRDs7QUFLQTdGLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUkrRixZQUFZLEdBQUcsRUFBbkI7QUFDQSxRQUFJQyxZQUFZLEdBQUcsRUFBbkI7O0FBQ0EsVUFBTUMsT0FBTyxHQUFHLFlBQVk7QUFDMUIsVUFBSTtBQUNGLGNBQU16RCxPQUFPLEdBQUcsSUFBSTFCLElBQUosQ0FBU3JCLElBQVQsQ0FBaEI7QUFDQSxjQUFNeUcsUUFBUSxHQUFHLHNDQUFqQjtBQUNBLGNBQU1DLEdBQUcsR0FBSSw0Q0FBMkNuRCxXQUFZLDZCQUE0QlIsT0FBTyxDQUFDQyxXQUFSLEVBQXNCLElBQ3BIRCxPQUFPLENBQUN0QixRQUFSLEtBQXFCLENBQ3RCLElBQUdzQixPQUFPLENBQUN6QixPQUFSLEVBQWtCLE1BRnRCO0FBR0EsY0FBTXRDLEdBQUcsR0FBRyxNQUFNVCxLQUFLLENBQUNrSSxRQUFRLEdBQUdDLEdBQVosQ0FBdkI7QUFDQSxjQUFNQyxJQUFJLEdBQUcsTUFBTTNILEdBQUcsQ0FBQ0MsSUFBSixFQUFuQjtBQUNBa0csbUJBQVcsQ0FBQ3dCLElBQUQsQ0FBWDtBQUNBQyxjQUFNLENBQUNDLE1BQVAsQ0FBY0YsSUFBZCxFQUFvQkcsT0FBcEIsQ0FBNEIsQ0FBQ1QsRUFBRCxFQUFLM0csQ0FBTCxLQUFXO0FBQ3JDLGNBQUlBLENBQUMsS0FBSyxDQUFWLEVBQWE7QUFDWGtILGtCQUFNLENBQUNHLElBQVAsQ0FBWVYsRUFBWixFQUFnQlMsT0FBaEIsQ0FBeUJFLEdBQUQsSUFBUztBQUMvQlYsMEJBQVksQ0FBQ1csSUFBYixDQUFrQjtBQUFFQyxxQkFBSyxFQUFFRixHQUFUO0FBQWNBLG1CQUFHLEVBQUVBO0FBQW5CLGVBQWxCO0FBQ0QsYUFGRDtBQUdEOztBQUNEVCxzQkFBWSxDQUFDVSxJQUFiLENBQWtCWixFQUFsQjtBQUNELFNBUEQ7QUFRQVIsc0JBQWMsQ0FBQ1UsWUFBRCxDQUFkO0FBQ0FSLHdCQUFnQixDQUFDTyxZQUFELENBQWhCO0FBQ0FOLGNBQU0sQ0FBQ1csSUFBRCxFQUFPLFNBQVAsRUFBa0JoQixVQUFsQixDQUFOO0FBQ0FLLGNBQU0sQ0FBQ1csSUFBRCxFQUFPLFNBQVAsRUFBa0JwQixVQUFsQixDQUFOO0FBQ0FTLGNBQU0sQ0FBQ1csSUFBRCxFQUFPLFNBQVAsRUFBa0JsQixTQUFsQixDQUFOO0FBQ0FPLGNBQU0sQ0FBQ1csSUFBRCxFQUFPLFdBQVAsRUFBb0J0QixZQUFwQixDQUFOO0FBQ0QsT0F2QkQsQ0F1QkUsT0FBTzhCLEtBQVAsRUFBYztBQUNkaEksZUFBTyxDQUFDQyxHQUFSLENBQVkrSCxLQUFaO0FBQ0Q7QUFDRixLQTNCRDs7QUE0QkFYLFdBQU87QUFDUixHQWhDUSxFQWdDTixDQUFDeEcsSUFBRCxFQUFPdUQsV0FBUCxDQWhDTSxDQUFUO0FBaUNBLHNCQUNFLHFFQUFDLGNBQUQsQ0FBZ0IsUUFBaEI7QUFDRSxTQUFLLEVBQUU7QUFDTDJCLGNBREs7QUFFTGxGLFVBRks7QUFHTGdCLGFBSEs7QUFJTDBFLGFBSks7QUFLTEosYUFMSztBQU1MRSxZQU5LO0FBT0xKLGVBUEs7QUFRTFEsaUJBUks7QUFTTEUsbUJBVEs7QUFVTDVFLFdBVks7QUFXTEQsY0FYSztBQVlMcUMsb0JBWks7QUFhTEM7QUFiSyxLQURUO0FBQUEsY0FpQkcwQjtBQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFxQkQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0VEO0FBRU8sTUFBTXJDLGVBQWUsZ0JBQUdtQywyREFBYSxFQUFyQzs7QUFFUCxNQUFNeUIsT0FBTyxHQUFHLENBQUNZLFFBQUQsRUFBV0MsU0FBWCxFQUFzQkMsT0FBdEIsRUFBK0JDLE9BQS9CLEtBQTJDO0FBQ3pEaEosT0FBSyxDQUNGLGdGQUErRTZJLFFBQVMsRUFEdEYsRUFFSDtBQUNFNUksVUFBTSxFQUFFLE1BRFY7QUFFRUMsUUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNuQjBJLGVBQVMsRUFBRUEsU0FEUTtBQUVuQkMsYUFBTyxFQUFFQSxPQUZVO0FBR25CekksWUFBTSxFQUFFO0FBSFcsS0FBZixDQUZSO0FBT0VDLFdBQU8sRUFBRTtBQUFFLHNCQUFnQjtBQUFsQjtBQVBYLEdBRkcsQ0FBTCxDQVlHQyxJQVpILENBWVNDLEdBQUQsSUFBU0EsR0FBRyxDQUFDQyxJQUFKLEVBWmpCLEVBYUdGLElBYkgsQ0FhU3lJLE1BQUQsSUFBWTtBQUNoQkQsV0FBTyxDQUFDQyxNQUFELENBQVA7QUFDRCxHQWZILEVBZ0JHbEksS0FoQkgsQ0FnQlVDLEdBQUQsSUFBU0osT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF3QkcsR0FBeEIsQ0FoQmxCO0FBaUJELENBbEJEOztBQW9CQSxNQUFNa0ksY0FBYyxHQUFHLE9BQU9mLEdBQVAsRUFBWWEsT0FBWixLQUF3QjtBQUM3QyxNQUFJO0FBQ0YsVUFBTWQsUUFBUSxHQUFHLHNDQUFqQjtBQUNBLFVBQU1pQixJQUFJLEdBQUdoQixHQUFiO0FBQ0EsVUFBTTFILEdBQUcsR0FBRyxNQUFNVCxLQUFLLENBQUNrSSxRQUFRLEdBQUdpQixJQUFaLENBQXZCO0FBQ0EsVUFBTWYsSUFBSSxHQUFHLE1BQU0zSCxHQUFHLENBQUNDLElBQUosRUFBbkI7QUFDQXNJLFdBQU8sQ0FBQ1osSUFBRCxDQUFQO0FBQ0QsR0FORCxDQU1FLE9BQU9RLEtBQVAsRUFBYztBQUNkaEksV0FBTyxDQUFDQyxHQUFSLENBQVkrSCxLQUFaO0FBQ0Q7QUFDRixDQVZEOztBQVllLFNBQVNRLGNBQVQsQ0FBd0I7QUFBRTFDO0FBQUYsQ0FBeEIsRUFBc0M7QUFDbkQsUUFBTTtBQUFBLE9BQUNvQyxTQUFEO0FBQUEsT0FBWTNFO0FBQVosTUFBNEJyRSxzREFBUSxDQUFDLElBQUlnRCxJQUFKLEVBQUQsQ0FBMUM7QUFDQSxRQUFNO0FBQUEsT0FBQ2lHLE9BQUQ7QUFBQSxPQUFVM0U7QUFBVixNQUF3QnRFLHNEQUFRLENBQUMsSUFBSWdELElBQUosRUFBRCxDQUF0QztBQUVBLFFBQU07QUFBQSxPQUFDdUcsT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0J4SixzREFBUSxFQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDNkcsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEI5RyxzREFBUSxFQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDK0csU0FBRDtBQUFBLE9BQVlDO0FBQVosTUFBNEJoSCxzREFBUSxFQUExQztBQUNBLFFBQU07QUFBQSxPQUFDcUgsT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0J0SCxzREFBUSxFQUF0QztBQUNBLFFBQU07QUFBQSxPQUFDbUgsTUFBRDtBQUFBLE9BQVNDO0FBQVQsTUFBc0JwSCxzREFBUSxFQUFwQztBQUVBLFFBQU07QUFBQSxPQUFDeUosVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBOEIxSixzREFBUSxFQUE1QztBQUNBLFFBQU07QUFBQSxPQUFDMkosV0FBRDtBQUFBLE9BQWNDO0FBQWQsTUFBZ0M1SixzREFBUSxFQUE5QztBQUNBLFFBQU07QUFBQSxPQUFDNkosUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEI5SixzREFBUSxFQUF4QztBQUVBa0MseURBQVMsQ0FBQyxNQUFNO0FBQ2RrSCxrQkFBYyxDQUNYLHlGQURXLEVBRVpJLFVBRlksQ0FBZDtBQUtBSixrQkFBYyxDQUNaLDhGQURZLEVBRVpNLGFBRlksQ0FBZDtBQUtBdkIsV0FBTyxDQUFDLHlCQUFELEVBQTRCYSxTQUE1QixFQUF1Q0MsT0FBdkMsRUFBZ0RuQyxXQUFoRCxDQUFQO0FBQ0FxQixXQUFPLENBQUMsNkJBQUQsRUFBZ0NhLFNBQWhDLEVBQTJDQyxPQUEzQyxFQUFvRGpDLFlBQXBELENBQVA7QUFDQW1CLFdBQU8sQ0FBQywyQkFBRCxFQUE4QmEsU0FBOUIsRUFBeUNDLE9BQXpDLEVBQWtEM0IsVUFBbEQsQ0FBUDtBQUNBYSxXQUFPLENBQUMsMEJBQUQsRUFBNkJhLFNBQTdCLEVBQXdDQyxPQUF4QyxFQUFpRDdCLFNBQWpELENBQVA7QUFFQWUsV0FBTyxDQUFDLDhCQUFELEVBQWlDYSxTQUFqQyxFQUE0Q0MsT0FBNUMsRUFBcURXLGNBQXJELENBQVA7QUFDQXpCLFdBQU8sQ0FBQyw2QkFBRCxFQUFnQ2EsU0FBaEMsRUFBMkNDLE9BQTNDLEVBQW9EYSxXQUFwRCxDQUFQO0FBQ0QsR0FsQlEsRUFrQk4sQ0FDRGpELFFBREMsRUFFRDBDLE9BRkMsRUFHRHhDLFNBSEMsRUFJRE0sT0FKQyxFQUtERixNQUxDLEVBTUQ2QixTQU5DLEVBT0RDLE9BUEMsRUFRRFEsVUFSQyxFQVNERSxXQVRDLEVBVURFLFFBVkMsQ0FsQk0sQ0FBVDtBQStCQSxRQUFNeEUsS0FBSyxHQUFHLENBQ1o7QUFBRTBFLE9BQUcsRUFBRSxtQkFBUDtBQUE0QkMsT0FBRyxFQUFFLFNBQWpDO0FBQTRDQyxTQUFLLEVBQUVWO0FBQW5ELEdBRFksRUFFWjtBQUNFUSxPQUFHLEVBQUUsc0JBRFA7QUFFRUMsT0FBRyxFQUFFLGdCQUZQO0FBR0VDLFNBQUssRUFBRXBEO0FBSFQsR0FGWSxFQU9aO0FBQ0VrRCxPQUFHLEVBQUUsdUJBRFA7QUFFRUMsT0FBRyxFQUFFLG9CQUZQO0FBR0VDLFNBQUssRUFBRWxEO0FBSFQsR0FQWSxFQVlaO0FBQUVnRCxPQUFHLEVBQUUsc0JBQVA7QUFBK0JDLE9BQUcsRUFBRSxrQkFBcEM7QUFBd0RDLFNBQUssRUFBRTVDO0FBQS9ELEdBWlksRUFhWjtBQUFFMEMsT0FBRyxFQUFFLHlCQUFQO0FBQWtDQyxPQUFHLEVBQUUsa0JBQXZDO0FBQTJEQyxTQUFLLEVBQUU5QztBQUFsRSxHQWJZLENBQWQ7QUFnQkEsUUFBTTdCLFVBQVUsR0FBRyxDQUNqQjtBQUFFeUUsT0FBRyxFQUFFLG1CQUFQO0FBQTRCQyxPQUFHLEVBQUUsU0FBakM7QUFBNENDLFNBQUssRUFBRVI7QUFBbkQsR0FEaUIsRUFFakI7QUFDRU0sT0FBRyxFQUFFLHNCQURQO0FBRUVDLE9BQUcsRUFBRSxnQkFGUDtBQUdFQyxTQUFLLEVBQUVOO0FBSFQsR0FGaUIsRUFPakI7QUFDRUksT0FBRyxFQUFFLHFCQURQO0FBRUVDLE9BQUcsRUFBRSxVQUZQO0FBR0VDLFNBQUssRUFBRUo7QUFIVCxHQVBpQixDQUFuQjtBQWNBLHNCQUNFLHFFQUFDLGVBQUQsQ0FBaUIsUUFBakI7QUFDRSxTQUFLLEVBQUU7QUFDTHhGLGtCQURLO0FBRUxDLGdCQUZLO0FBR0xlLFdBSEs7QUFJTEM7QUFKSyxLQURUO0FBQUEsY0FRR3NCO0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBWUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0hEO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUVBOztBQUVBLE1BQU1zRCxRQUFRLEdBQUcsQ0FBQztBQUFFQyxhQUFGO0FBQWVuRTtBQUFmLENBQUQsS0FBNEI7QUFDM0Msc0JBQ0UscUVBQUMsc0RBQUQ7QUFBTSxhQUFTLE1BQWY7QUFBZ0IsV0FBTyxFQUFDLGVBQXhCO0FBQXdDLGFBQVMsRUFBRXJHLGdFQUFPLENBQUN5SyxPQUEzRDtBQUFBLDRCQUNFLHFFQUFDLHNEQUFEO0FBQU0sZUFBUyxNQUFmO0FBQWdCLFVBQUksTUFBcEI7QUFBcUIsUUFBRSxFQUFFLENBQXpCO0FBQUEsOEJBQ0UscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsQ0FBZjtBQUFBLGtCQUNHRCxXQUFXLEtBQUssQ0FBaEIsSUFDRUEsV0FBVyxHQUFHLENBQWQsaUJBQ0MscUVBQUMsNERBQUQ7QUFBWSxpQkFBTyxFQUFDLElBQXBCO0FBQUEsb0JBQTBCQTtBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQU9FLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLENBQWY7QUFBQSwrQkFDRTtBQUFLLGVBQUssRUFBRTtBQUFFdEwscUJBQVMsRUFBRTtBQUFiLFdBQVo7QUFBQSxpQ0FDRSxxRUFBQyxnRUFBRDtBQUFtQixlQUFHLEVBQUUsQ0FBeEI7QUFBMkIsa0JBQU0sRUFBRyxHQUFFc0wsV0FBWSxFQUFsRDtBQUFxRCxnQkFBSSxFQUFDO0FBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFjRSxxRUFBQyxzREFBRDtBQUFNLFVBQUksTUFBVjtBQUFXLFFBQUUsRUFBRSxDQUFmO0FBQUEsNkJBQ0UscUVBQUMsNERBQUQ7QUFDRSxhQUFLLEVBQUU7QUFBRXRMLG1CQUFTLEVBQUU7QUFBYixTQURUO0FBRUUsZUFBTyxFQUFDLFdBRlY7QUFHRSxhQUFLLEVBQUMsT0FIUjtBQUFBLGtCQUtHbUg7QUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTBCRCxDQTNCRDs7QUE2QmUsU0FBU3FFLE1BQVQsQ0FBZ0I7QUFBRUMsYUFBRjtBQUFlQztBQUFmLENBQWhCLEVBQW1EO0FBQUE7O0FBQ2hFLFFBQU0zSyxNQUFNLEdBQUdDLDZEQUFTLEVBQXhCO0FBRUEsUUFBTTJLLElBQUksR0FBRzVLLE1BQU0sQ0FBQzZLLEtBQVAsQ0FBYTdJLE1BQTFCO0FBRUEsTUFBSThJLFVBQVUsR0FBRyxJQUFqQjs7QUFDQSxNQUFJRixJQUFJLEtBQUssT0FBYixFQUFzQjtBQUNwQkUsY0FBVSxHQUFHSixXQUFiO0FBQ0QsR0FGRCxNQUVPO0FBQ0xJLGNBQVUsR0FBR0gsZ0JBQWI7QUFDRDs7QUFFRCxRQUFNO0FBQUEsT0FBQ0ksYUFBRDtBQUFBLE9BQWdCQztBQUFoQixNQUFvQzVLLHNEQUFRLEVBQWxEO0FBQ0EsUUFBTTtBQUFBLE9BQUM2SyxjQUFEO0FBQUEsT0FBaUJDO0FBQWpCLE1BQXNDOUssc0RBQVEsRUFBcEQ7QUFDQSxRQUFNO0FBQUEsT0FBQytLLFlBQUQ7QUFBQSxPQUFlQztBQUFmLE1BQWtDaEwsc0RBQVEsRUFBaEQ7QUFFQWtDLHlEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUl4QyxFQUFFLEdBQUcsMEJBQVQ7QUFDQSxRQUFJdUwsU0FBUyxHQUFHLGFBQWhCOztBQUNBLFFBQUlULElBQUksS0FBSyxZQUFiLEVBQTJCO0FBQ3pCOUssUUFBRSxHQUFHLDBCQUFMO0FBQ0F1TCxlQUFTLEdBQUcsa0JBQVo7QUFDRDs7QUFDRC9LLFNBQUssQ0FBRSw0Q0FBMkMrSyxTQUFVLFdBQVV2TCxFQUFHLEVBQXBFLENBQUwsQ0FDR2dCLElBREgsQ0FDU0MsR0FBRCxJQUFTQSxHQUFHLENBQUNDLElBQUosRUFEakIsRUFFR0YsSUFGSCxDQUVTNEgsSUFBRCxJQUFVc0MsZ0JBQWdCLENBQUN0QyxJQUFELENBRmxDO0FBR0QsR0FWUSxFQVVOLEVBVk0sQ0FBVDtBQVlBcEcseURBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSXhDLEVBQUUsR0FBRywwQkFBVDtBQUNBLFFBQUl1TCxTQUFTLEdBQUcsY0FBaEI7O0FBQ0EsUUFBSVQsSUFBSSxLQUFLLFlBQWIsRUFBMkI7QUFDekI5SyxRQUFFLEdBQUcsMEJBQUw7QUFDQXVMLGVBQVMsR0FBRyxtQkFBWjtBQUNEOztBQUNEL0ssU0FBSyxDQUFFLDRDQUEyQytLLFNBQVUsV0FBVXZMLEVBQUcsRUFBcEUsQ0FBTCxDQUNHZ0IsSUFESCxDQUNTQyxHQUFELElBQVNBLEdBQUcsQ0FBQ0MsSUFBSixFQURqQixFQUVHRixJQUZILENBRVM0SCxJQUFELElBQVV3QyxpQkFBaUIsQ0FBQ3hDLElBQUQsQ0FGbkM7QUFHRCxHQVZRLEVBVU4sRUFWTSxDQUFUO0FBWUFwRyx5REFBUyxDQUFDLE1BQU07QUFDZCxRQUFJeEMsRUFBRSxHQUFHLDBCQUFUO0FBQ0EsUUFBSXVMLFNBQVMsR0FBRyxZQUFoQjs7QUFDQSxRQUFJVCxJQUFJLEtBQUssWUFBYixFQUEyQjtBQUN6QjlLLFFBQUUsR0FBRywwQkFBTDtBQUNBdUwsZUFBUyxHQUFHLGlCQUFaO0FBQ0Q7O0FBQ0QvSyxTQUFLLENBQUUsNENBQTJDK0ssU0FBVSxXQUFVdkwsRUFBRyxFQUFwRSxDQUFMLENBQ0dnQixJQURILENBQ1NDLEdBQUQsSUFBU0EsR0FBRyxDQUFDQyxJQUFKLEVBRGpCLEVBRUdGLElBRkgsQ0FFUzRILElBQUQsSUFBVTBDLGVBQWUsQ0FBQzFDLElBQUQsQ0FGakM7QUFHRCxHQVZRLEVBVU4sRUFWTSxDQUFUOztBQVlBLFFBQU12RixVQUFVLEdBQUlHLEVBQUQsSUFBUTtBQUN6QixVQUFNdkIsSUFBSSxHQUFHLElBQUlxQixJQUFKLENBQVNFLEVBQVQsQ0FBYjtBQUNBLFVBQU1DLEtBQUssR0FBRyxDQUNaLFNBRFksRUFFWixVQUZZLEVBR1osT0FIWSxFQUlaLE9BSlksRUFLWixLQUxZLEVBTVosTUFOWSxFQU9aLE1BUFksRUFRWixRQVJZLEVBU1osV0FUWSxFQVVaLFNBVlksRUFXWixVQVhZLEVBWVosVUFaWSxDQUFkO0FBY0EsV0FBUSxHQUFFeEIsSUFBSSxDQUFDc0IsT0FBTCxFQUFlLElBQUdFLEtBQUssQ0FBQ3hCLElBQUksQ0FBQ3lCLFFBQUwsRUFBRCxDQUFMLENBQXVCOEgsS0FBdkIsQ0FDMUIsQ0FEMEIsRUFFMUIsQ0FGMEIsQ0FHMUIsSUFBR3ZKLElBQUksQ0FBQ2dELFdBQUwsRUFBbUIsRUFIeEI7QUFJRCxHQXBCRDs7QUFzQkEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxnREFBRDtBQUFBLDZCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBSUU7QUFBSyxlQUFTLEVBQUVoRixnRUFBTyxDQUFDaUMsTUFBeEI7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUVqQyxnRUFBTyxDQUFDd0wsS0FBeEI7QUFBQSxnQ0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixFQUVHLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsQ0FBVixFQUFhLENBQWIsRUFBZ0JoSyxHQUFoQixDQUFvQixDQUFDNkcsRUFBRCxFQUFLM0csQ0FBTCxrQkFDbkI7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUUxQixnRUFBTyxDQUFDeUwsT0FBeEI7QUFBQSxzQkFBa0NwRDtBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBRUU7QUFBSyxxQkFBUyxFQUFFckksZ0VBQU8sQ0FBQzBMLFFBQXhCO0FBQUEsbUNBQ0UscUVBQUMsZ0VBQUQ7QUFBbUIsb0JBQU0sRUFBRSxDQUEzQjtBQUE4QixrQkFBSSxFQUFDO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUEsV0FBVWhLLENBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERCxDQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBWUUscUVBQUMsc0RBQUQ7QUFBTSxpQkFBUyxNQUFmO0FBQWdCLGlCQUFTLEVBQUUxQixnRUFBTyxDQUFDMkwsTUFBbkM7QUFBQSxnQ0FDRSxxRUFBQyxzREFBRDtBQUFNLG1CQUFTLE1BQWY7QUFBZ0IsY0FBSSxNQUFwQjtBQUFxQixZQUFFLEVBQUUsQ0FBekI7QUFBNEIsbUJBQVMsRUFBRTNMLGdFQUFPLENBQUM0TCxXQUEvQztBQUFBLGtDQUNFLHFFQUFDLHNEQUFEO0FBQ0UscUJBQVMsTUFEWDtBQUVFLGdCQUFJLE1BRk47QUFHRSxjQUFFLEVBQUUsRUFITjtBQUlFLG1CQUFPLEVBQUMsZUFKVjtBQUtFLHNCQUFVLEVBQUMsUUFMYjtBQUFBLG1DQU9FLHFFQUFDLHNEQUFEO0FBQU0sa0JBQUksTUFBVjtBQUFXLGdCQUFFLEVBQUUsQ0FBZjtBQUFBLHFDQUNFLHFFQUFDLDREQUFEO0FBQ0UseUJBQVMsRUFBRTVMLGdFQUFPLENBQUM2TCxtQkFEckI7QUFFRSx1QkFBTyxFQUFDLElBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixpQkFpQkdkLFVBakJILGdEQWlCRyxZQUFZdkosR0FBWixDQUFpQnNLLEdBQUQsSUFBUztBQUN4QixrQkFBTTtBQUNKQyxpQkFESTtBQUVKQywwQkFGSTtBQUdKeEosa0JBSEk7QUFJSnlKLHFCQUpJO0FBS0pDLHVCQUxJO0FBTUoxRixvQkFOSTtBQU9KcEU7QUFQSSxnQkFRRjBKLEdBUko7QUFTQSxnQ0FDRSxxRUFBQyxzREFBRDtBQUFNLGtCQUFJLE1BQVY7QUFBVyxnQkFBRSxFQUFFLEVBQWY7QUFBQSxxQ0FDRSxxRUFBQyw2REFBRDtBQUNFLGtCQUFFLEVBQUVDLEdBRE47QUFFRSxvQkFBSSxFQUFFQyxZQUZSO0FBR0Usb0JBQUksRUFBRyxHQUFFNUksVUFBVSxDQUFDOEksU0FBRCxDQUFZLGVBSGpDO0FBSUUsdUJBQU8sRUFBQyx5QkFKVjtBQUtFLHNCQUFNLEVBQUUxSixJQUxWO0FBTUUsdUJBQU8sRUFBRXlKLE9BTlg7QUFPRSxzQkFBTSxFQUFFRSxNQUFNLENBQUMzRixNQUFELENBUGhCO0FBUUUsd0JBQVEsRUFBRXBFO0FBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGVBQXdCMkosR0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERjtBQWNELFdBeEJBLENBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQTRDRSxxRUFBQyxzREFBRDtBQUFNLGNBQUksTUFBVjtBQUFXLFlBQUUsRUFBRSxDQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFFL0wsZ0VBQU8sQ0FBQ29NLFNBQXhCO0FBQUEsOEJBQ0csQ0FDQztBQUNFL0YsbUJBQUssRUFBRSxTQURUO0FBRUVnRyxxQkFBTyxFQUFFckI7QUFGWCxhQURELEVBS0M7QUFDRTNFLG1CQUFLLEVBQUUsaUJBRFQ7QUFFRWdHLHFCQUFPLEVBQUVuQjtBQUZYLGFBTEQsRUFTQztBQUNFN0UsbUJBQUssRUFBRSxlQURUO0FBRUVnRyxxQkFBTyxFQUFFakI7QUFGWCxhQVRELENBREgseUNBQ0csS0FhRTVKLEdBYkYsQ0FhTSxDQUFDOEssSUFBRCxFQUFPNUssQ0FBUCxrQkFDTCxxRUFBQyxRQUFEO0FBRUUsbUJBQUssRUFBRTRLLElBQUksQ0FBQ2pHLEtBRmQ7QUFHRSx5QkFBVyxFQUFFaUcsSUFBSSxDQUFDRDtBQUhwQixlQUNPM0ssQ0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUpGO0FBQUEsa0JBREY7QUF5RkQ7QUFFTSxlQUFlNkssY0FBZixHQUFnQztBQUNyQyxRQUFNQyxLQUFLLEdBQUcsQ0FBQyxrQkFBRCxFQUFxQix1QkFBckIsQ0FBZDtBQUNBLFNBQU87QUFBRUEsU0FBRjtBQUFTQyxZQUFRLEVBQUU7QUFBbkIsR0FBUDtBQUNEO0FBRU0sZUFBZUMsY0FBZixHQUFnQztBQUNyQyxRQUFNaEgsS0FBSyxHQUFHLE1BQU1uRixLQUFLLENBQ3ZCLGdGQUR1QixDQUF6QjtBQUdBLFFBQU1vSyxXQUFXLEdBQUcsTUFBTWpGLEtBQUssQ0FBQ3pFLElBQU4sRUFBMUI7QUFFQSxRQUFNMEUsVUFBVSxHQUFHLE1BQU1wRixLQUFLLENBQzNCLHFGQUQyQixDQUE5QjtBQUdBLFFBQU1xSyxnQkFBZ0IsR0FBRyxNQUFNakYsVUFBVSxDQUFDMUUsSUFBWCxFQUEvQjtBQUVBLFNBQU87QUFDTDhFLFNBQUssRUFBRTtBQUNMNEUsaUJBREs7QUFFTEM7QUFGSztBQURGLEdBQVA7QUFNRCxDOzs7Ozs7Ozs7OztBQ25PRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNWQSw4Qzs7Ozs7Ozs7Ozs7QUNBQSw4Qzs7Ozs7Ozs7Ozs7QUNBQSx3RDs7Ozs7Ozs7Ozs7QUNBQSwrRDs7Ozs7Ozs7Ozs7QUNBQSwrRDs7Ozs7Ozs7Ozs7QUNBQSxrRDs7Ozs7Ozs7Ozs7QUNBQSxxRDs7Ozs7Ozs7Ozs7QUNBQSwrRDs7Ozs7Ozs7Ozs7QUNBQSxxRDs7Ozs7Ozs7Ozs7QUNBQSw0RDs7Ozs7Ozs7Ozs7QUNBQSw0RDs7Ozs7Ozs7Ozs7QUNBQSxnRTs7Ozs7Ozs7Ozs7QUNBQSwwRDs7Ozs7Ozs7Ozs7QUNBQSxtRDs7Ozs7Ozs7Ozs7QUNBQSx3RDs7Ozs7Ozs7Ozs7QUNBQSwyRDs7Ozs7Ozs7Ozs7QUNBQSxvRDs7Ozs7Ozs7Ozs7QUNBQSx5RDs7Ozs7Ozs7Ozs7QUNBQSxxRDs7Ozs7Ozs7Ozs7QUNBQSwrQzs7Ozs7Ozs7Ozs7QUNBQSxxRTs7Ozs7Ozs7Ozs7QUNBQSwwRDs7Ozs7Ozs7Ozs7QUNBQSwwRDs7Ozs7Ozs7Ozs7QUNBQSxvRDs7Ozs7Ozs7Ozs7QUNBQSxpRDs7Ozs7Ozs7Ozs7QUNBQSxnRDs7Ozs7Ozs7Ozs7QUNBQSxxQzs7Ozs7Ozs7Ozs7QUNBQSxzQzs7Ozs7Ozs7Ozs7QUNBQSx3Qzs7Ozs7Ozs7Ozs7QUNBQSxrQzs7Ozs7Ozs7Ozs7QUNBQSxrRCIsImZpbGUiOiJwYWdlcy9kYXNoYm9hcmQvW3Jldmlld10uanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uLy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3BhZ2VzL2Rhc2hib2FyZC9bcmV2aWV3XS5qc1wiKTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcblxyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIjtcclxuaW1wb3J0IEFjY29yZGlvbiBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvQWNjb3JkaW9uXCI7XHJcbmltcG9ydCBBY2NvcmRpb25TdW1tYXJ5IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9BY2NvcmRpb25TdW1tYXJ5XCI7XHJcbmltcG9ydCBBY2NvcmRpb25EZXRhaWxzIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9BY2NvcmRpb25EZXRhaWxzXCI7XHJcbmltcG9ydCBUeXBvZ3JhcGh5IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5XCI7XHJcbmltcG9ydCBFeHBhbmRNb3JlSWNvbiBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zL0V4cGFuZE1vcmVcIjtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gIHJvb3Q6IHtcclxuICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICB9LFxyXG4gIGFjY29yZGlvbjoge1xyXG4gICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgYm94U2hhZG93OiBcIm5vbmVcIixcclxuICAgIGJvZGVyOiBcIm5vbmVcIixcclxuICB9LFxyXG4gIHN1bW1hcnk6IHtcclxuICAgIHdpZHRoOiBcIjE4JVwiLFxyXG4gICAgYmFja2dyb3VuZDogXCJ2YXIoLS1wcmltYXJ5LWNvbG9yKVwiLFxyXG4gICAgY29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgYm9yZGVyUmFkaXVzOiBcIjVweFwiLFxyXG4gICAgbWFyZ2luTGVmdDogXCI4MiVcIixcclxuICB9LFxyXG4gIGhlYWRpbmc6IHtcclxuICAgIGZvbnRTaXplOiBcIjE0cHhcIixcclxuICB9LFxyXG4gIGRldGFpbHM6IHtcclxuICAgIGJvcmRlclJhZGl1czogXCI4cHhcIixcclxuICAgIG1hcmdpblRvcDogXCIwLjVyZW1cIixcclxuICAgIGJveFNoYWRvdzogXCIwcHggM3B4IDE1cHggcmdiYSgwLDAsMCwwLjEpXCIsXHJcbiAgfSxcclxuICBtZXNzYWdlOiB7XHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgIGZsZXhGbG93OiBcImNvbHVtblwiLFxyXG4gICAgcGFkZGluZzogXCIwLjVyZW0gMFwiLFxyXG4gICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgXCImIHRleHRhcmVhXCI6IHtcclxuICAgICAgaGVpZ2h0OiBcIjEwMHB4XCIsXHJcbiAgICAgIGJvcmRlclJhZGl1czogXCI4cHhcIixcclxuICAgICAgcGFkZGluZzogXCIwLjVyZW1cIixcclxuICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjYmJiXCIsXHJcbiAgICAgIHJlc2l6ZTogXCJub25lXCIsXHJcbiAgICAgIG91dGxpbmU6IFwibm9uZVwiLFxyXG4gICAgfSxcclxuICB9LFxyXG4gIGJ0blNlbmQ6IHtcclxuICAgIG1hcmdpblRvcDogXCIwLjVyZW1cIixcclxuICAgIGJhY2tncm91bmQ6IFwidmFyKC0tcHJpbWFyeS1jb2xvcilcIixcclxuICAgIGNvbG9yOiBcIiNmZmZcIixcclxuICAgIHRleHRUcmFuc2Zvcm06IFwiY2FwaXRhbGl6ZVwiLFxyXG4gICAgXCImOmhvdmVyXCI6IHtcclxuICAgICAgYmFja2dyb3VuZDogXCJ2YXIoLS1wcmltYXJ5LWNvbG9yKVwiLFxyXG4gICAgfSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQW5zd2VyKHsgYW5zd2VyLCBpZCB9KSB7XHJcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG5cclxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSBSZWFjdC51c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3Qgc2VuZFJlc3VsdCA9ICgpID0+IHtcclxuICAgIGZldGNoKFxyXG4gICAgICBcImh0dHBzOi8vY29ycy1hbnl3aGVyZS5oZXJva3VhcHAuY29tL2h0dHA6Ly9uYXBwZXRpdG8tc3RhZ2UuaGVyb2t1YXBwLmNvbS9hcGkvcmV2aWV3XCIsXHJcbiAgICAgIHtcclxuICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIHJldmlld0lkOiBpZCxcclxuICAgICAgICAgIHVzZXJJZDogXCI1ZWM1MDNjYzQzNGRmZjI5Y2Y1NjYzM2JcIixcclxuICAgICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHJlcy5qc29uKCkpXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwicmVzIHNlbmQgPSBcIiwgcmVzcG9uc2UpO1xyXG4gICAgICAgIHJvdXRlci5yZWxvYWQoKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yID0gXCIsIGVycik7XHJcbiAgICAgICAgcm91dGVyLnJlbG9hZCgpO1xyXG4gICAgICB9KTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMucm9vdH0+XHJcbiAgICAgIDxBY2NvcmRpb24gY2xhc3NOYW1lPXtjbGFzc2VzLmFjY29yZGlvbn0+XHJcbiAgICAgICAgPEFjY29yZGlvblN1bW1hcnlcclxuICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5zdW1tYXJ5fVxyXG4gICAgICAgICAgZXhwYW5kSWNvbj17PEV4cGFuZE1vcmVJY29uIHN0eWxlPXt7IGNvbG9yOiBcIiNmZmZcIiB9fSAvPn1cclxuICAgICAgICAgIGFyaWEtY29udHJvbHM9XCJwYW5lbDFhLWNvbnRlbnRcIlxyXG4gICAgICAgICAgaWQ9XCJwYW5lbDFhLWhlYWRlclwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHkgY2xhc3NOYW1lPXtjbGFzc2VzLmhlYWRpbmd9PlxyXG4gICAgICAgICAgICB7YW5zd2VyICYmIGFuc3dlclswXSA/IFwiU2VlIEFuc3dlclwiIDogXCJBbnN3ZXJcIn1cclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8L0FjY29yZGlvblN1bW1hcnk+XHJcbiAgICAgICAgPEFjY29yZGlvbkRldGFpbHMgY2xhc3NOYW1lPXtjbGFzc2VzLmRldGFpbHN9PlxyXG4gICAgICAgICAge2Fuc3dlciAmJiBhbnN3ZXJbMF0gPyAoXHJcbiAgICAgICAgICAgIGFuc3dlci5tYXAoKGNvbW1pdCwgaSkgPT4gPFR5cG9ncmFwaHkga2V5PXtpfT57Y29tbWl0fTwvVHlwb2dyYXBoeT4pXHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5tZXNzYWdlfT5cclxuICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQW5zd2VyXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXttZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNZXNzYWdlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2VuZFJlc3VsdCgpfSBjbGFzc05hbWU9e2NsYXNzZXMuYnRuU2VuZH0+XHJcbiAgICAgICAgICAgICAgICBTZW5kXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L0FjY29yZGlvbkRldGFpbHM+XHJcbiAgICAgIDwvQWNjb3JkaW9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iLCJleHBvcnQgeyBSZXZpZXdCb3ggfSBmcm9tIFwiLi9yZXZpZXdCb3gvcmV2aWV3Qm94XCI7XHJcbmV4cG9ydCB7IEFuc3dlciB9IGZyb20gXCIuL2Fuc3dlci9hbnN3ZXJcIjtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IHsgVHlwb2dyYXBoeSwgR3JpZCB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5cclxuaW1wb3J0IHsgQ3VzdG9taXplZFJhdGluZ3MgfSBmcm9tIFwiLi4vLi4vdWlcIjtcclxuaW1wb3J0IHsgQW5zd2VyIH0gZnJvbSBcIi4uL1wiO1xyXG5cclxuaW1wb3J0IGNsYXNzZXMgZnJvbSBcIi4vcmV2aWV3Qm94Lm1vZHVsZS5jc3NcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBSZXZpZXdCb3goe1xyXG4gIG5hbWUsXHJcbiAgZGF0ZSxcclxuICByZXZpZXcsXHJcbiAgcmF0VGV4dCxcclxuICByZXZSYXQsXHJcbiAgY29tbWVudHMsXHJcbiAgaWQsXHJcbn0pIHtcclxuICBjb25zdCBbYW5zd2Vycywgc2V0QW5zd2Vyc10gPSBSZWFjdC51c2VTdGF0ZSgpO1xyXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0ZXh0ID0gY29tbWVudHMubWFwKCh7IHRleHQgfSkgPT4gdGV4dCk7XHJcbiAgICBzZXRBbnN3ZXJzKHRleHQpO1xyXG4gIH0sIFtjb21tZW50c10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMucmV2aWV3Qm94fT5cclxuICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg1XCI+e25hbWV9PC9UeXBvZ3JhcGh5PlxyXG4gICAgICA8VHlwb2dyYXBoeSBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1wcmltYXJ5LWNvbG9yKVwiIH19IHZhcmlhbnQ9XCJzdWJ0aXRsZTJcIj5cclxuICAgICAgICB7ZGF0ZX1cclxuICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5yYXR9PlxyXG4gICAgICAgIDxUeXBvZ3JhcGh5IHN0eWxlPXt7IGZvbnRXZWlnaHQ6IFwiNjAwXCIgfX0gdmFyaWFudD1cInN1YnRpdGxlMVwiPlxyXG4gICAgICAgICAge3JhdFRleHR9XHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiBcIjAuMTVyZW1cIiB9fT5cclxuICAgICAgICAgIDxDdXN0b21pemVkUmF0aW5ncyBzaXplPVwic21hbGxcIiBtYXg9ezV9IHJldlJhdD17cmV2UmF0fSAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPFR5cG9ncmFwaHkgc3R5bGU9e3sgbWF4V2lkdGg6IFwiOTAlXCIgfX0gdmFyaWFudD1cInN1YnRpdGxlMlwiPlxyXG4gICAgICAgIHtyZXZpZXd9XHJcbiAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgPEdyaWQgY29udGFpbmVyIGp1c3RpZnk9XCJmbGV4LWVuZFwiPlxyXG4gICAgICAgIDxBbnN3ZXIgYW5zd2VyPXthbnN3ZXJzfSBpZD17aWR9IC8+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIiwiLy8gRXhwb3J0c1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFwicmV2aWV3Qm94XCI6IFwicmV2aWV3Qm94X3Jldmlld0JveF9fMW1oUzdcIixcblx0XCJyYXRcIjogXCJyZXZpZXdCb3hfcmF0X18zQU50V1wiLFxuXHRcImFuc19idG5cIjogXCJyZXZpZXdCb3hfYW5zX2J0bl9fMTRSbG9cIlxufTtcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbXBvcnQgXCJkYXRlLWZuc1wiO1xyXG5cclxuaW1wb3J0IEdyaWQgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0dyaWRcIjtcclxuaW1wb3J0IERhdGVGbnNVdGlscyBmcm9tIFwiQGRhdGUtaW8vZGF0ZS1mbnNcIjtcclxuaW1wb3J0IHtcclxuICBNdWlQaWNrZXJzVXRpbHNQcm92aWRlcixcclxuICBLZXlib2FyZERhdGVQaWNrZXIsXHJcbn0gZnJvbSBcIkBtYXRlcmlhbC11aS9waWNrZXJzXCI7XHJcbmltcG9ydCBDYWxlbmRhclRvZGF5T3V0bGluZWRJY29uIGZyb20gXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQ2FsZW5kYXJUb2RheU91dGxpbmVkXCI7XHJcbmltcG9ydCB7IFR5cG9ncmFwaHkgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuXHJcbmltcG9ydCB7IEJvb2tpbmdDb250ZXh0IH0gZnJvbSBcIi4uLy4uLy4uL2NvbnRleHQvYm9va2luZ0ZldGNoXCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRGF0ZVBpY2tlcigpIHtcclxuICBjb25zdCB2YWx1ZSA9IHVzZUNvbnRleHQoQm9va2luZ0NvbnRleHQpO1xyXG4gIGNvbnN0IHsgZGF0ZSwgc2V0RGF0ZSwgc2V0TW9udGgsIG1vbnRoIH0gPSB2YWx1ZTtcclxuXHJcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGRhdGVUZXh0ID0gbW9udGhfbmFtZShuZXcgRGF0ZSgpKSArIFwiIFwiICsgbmV3IERhdGUoKS5nZXREYXRlKCk7XHJcbiAgICBzZXRNb250aChkYXRlVGV4dCk7XHJcbiAgICBjb25zb2xlLmxvZyhtb250aCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBtb250aF9uYW1lID0gKGR0KSA9PiB7XHJcbiAgICBjb25zdCBtbGlzdCA9IFtcclxuICAgICAgXCJKYW51YXJ5XCIsXHJcbiAgICAgIFwiRmVicnVhcnlcIixcclxuICAgICAgXCJNYXJjaFwiLFxyXG4gICAgICBcIkFwcmlsXCIsXHJcbiAgICAgIFwiTWF5XCIsXHJcbiAgICAgIFwiSnVuZVwiLFxyXG4gICAgICBcIkp1bHlcIixcclxuICAgICAgXCJBdWd1c3RcIixcclxuICAgICAgXCJTZXB0ZW1iZXJcIixcclxuICAgICAgXCJPY3RvYmVyXCIsXHJcbiAgICAgIFwiTm92ZW1iZXJcIixcclxuICAgICAgXCJEZWNlbWJlclwiLFxyXG4gICAgXTtcclxuICAgIHJldHVybiBtbGlzdFtkdC5nZXRNb250aCgpXTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEYXRlQ2hhbmdlID0gKGRhdCkgPT4ge1xyXG4gICAgc2V0RGF0ZShkYXQpO1xyXG4gICAgY29uc3QgZGF0ZVRleHQgPSBtb250aF9uYW1lKG5ldyBEYXRlKGRhdCkpICsgXCIgXCIgKyBkYXQuZ2V0RGF0ZSgpO1xyXG4gICAgc2V0TW9udGgoZGF0ZVRleHQpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TXVpUGlja2Vyc1V0aWxzUHJvdmlkZXIgdXRpbHM9e0RhdGVGbnNVdGlsc30+XHJcbiAgICAgIDxHcmlkIGl0ZW0geHM9ezZ9PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGF0ZS1waWNrZXJcIj5cclxuICAgICAgICAgIDxLZXlib2FyZERhdGVQaWNrZXJcclxuICAgICAgICAgICAga2V5Ym9hcmRJY29uPXtcclxuICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcclxuICAgICAgICAgICAgICAgIHdpZHRoPVwiNDBcIlxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0PVwiNDBcIlxyXG4gICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCA2MCA2MFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGdcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJHcm91cF8xNDM2NVwiXHJcbiAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIkdyb3VwIDE0MzY1XCJcclxuICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKC01NDEuMjUgLTE0NC43NSlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiUGF0aF8xNDg4OFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiUGF0aCAxNDg4OFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZD1cIk0zNC4xMTQsMEg1LjM4NkE1LjM5Myw1LjM5MywwLDAsMCwwLDUuMzg2VjM0LjExNEE1LjM5NCw1LjM5NCwwLDAsMCw1LjM4NiwzOS41SDM0LjExNEE1LjM5NCw1LjM5NCwwLDAsMCwzOS41LDM0LjExNFY1LjM4NkE1LjM5NCw1LjM5NCwwLDAsMCwzNC4xMTQsMFpNMzcuNywzNC4xMTRBMy42LDMuNiwwLDAsMSwzNC4xMTQsMzcuN0g1LjM4NkEzLjYsMy42LDAsMCwxLDEuOCwzNC4xMTRWNS4zODZBMy42LDMuNiwwLDAsMSw1LjM4NiwxLjhIMzQuMTE0QTMuNiwzLjYsMCwwLDEsMzcuNyw1LjM4NlpcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NDEuNSAxNDUpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlLXdpZHRoPVwiMC41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGVsbGlwc2VcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIkVsbGlwc2VfMzU1MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiRWxsaXBzZSAzNTUwXCJcclxuICAgICAgICAgICAgICAgICAgICBjeD1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICBjeT1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICByeD1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICByeT1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoNTUxLjA0NyAxNTEuMTcpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxlbGxpcHNlXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJFbGxpcHNlXzM1NTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIkVsbGlwc2UgMzU1MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY3g9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY3k9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcng9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcnk9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU1OS43MjcgMTUxLjE3KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNlNzIzMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZWxsaXBzZVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiRWxsaXBzZV8zNTUyXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJFbGxpcHNlIDM1NTJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN4PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN5PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ4PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ5PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NjguNDA0IDE1MS4xNylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODY0XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg2NFwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjUwMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiNC44OTNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NTQuODI3IDE2MC40NDMpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxyZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJSZWN0YW5nbGVfMjg2NVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDI4NjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiNS41XCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5M1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU2Mi4xNzIgMTYwLjQ0MylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODY2XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg2NlwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjUwMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiNC44OTNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NjkuNTE0IDE2MC40NDMpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxyZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJSZWN0YW5nbGVfMjg2N1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDI4NjdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiNS41XCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU0Ny40ODQgMTY2Ljk3NilcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODY4XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg2OFwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjUwMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiNC44OTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NTQuODI3IDE2Ni45NzYpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxyZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJSZWN0YW5nbGVfMjg2OVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDI4NjlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiNS41XCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU2Mi4xNzIgMTY2Ljk3NilcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODcwXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg3MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjUwMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiNC44OTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NjkuNTE0IDE2Ni45NzYpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxyZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJSZWN0YW5nbGVfMjg3MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDI4NzFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiNS41XCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU0Ny40ODQgMTczLjUwNylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODcyXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg3MlwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjUwMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiNC44OTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NTQuODI3IDE3My41MDcpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxyZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJSZWN0YW5nbGVfMjg3M1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiUmVjdGFuZ2xlIDI4NzNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiNS41XCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU2Mi4xNzIgMTczLjUwNylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODc0XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg3NFwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjUwMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiNC44OTFcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NjkuNTE0IDE3My41MDcpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2c+XHJcbiAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbWFyZ2luPVwibm9ybWFsXCJcclxuICAgICAgICAgICAgdmFsdWU9e2RhdGV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVEYXRlQ2hhbmdlfVxyXG4gICAgICAgICAgICBmb3JtYXQ9XCJ5eXl5LU1NLWRkZFwiXHJcbiAgICAgICAgICAgIEtleWJvYXJkQnV0dG9uUHJvcHM9e3tcclxuICAgICAgICAgICAgICBcImFyaWEtbGFiZWxcIjogXCJjaGFuZ2UgZGF0ZVwiLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9HcmlkPlxyXG4gICAgPC9NdWlQaWNrZXJzVXRpbHNQcm92aWRlcj5cclxuICApO1xyXG59XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHdpdGhTdHlsZXMgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCI7XHJcbmltcG9ydCBGb3JtQ29udHJvbCBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvRm9ybUNvbnRyb2xcIjtcclxuaW1wb3J0IE5hdGl2ZVNlbGVjdCBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvTmF0aXZlU2VsZWN0XCI7XHJcbmltcG9ydCBJbnB1dEJhc2UgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0lucHV0QmFzZVwiO1xyXG5cclxuaW1wb3J0IHsgRGFzaEJvcmRDb250ZXh0IH0gZnJvbSBcIi4uLy4uLy4uL2NvbnRleHQvZGFzaGJvYXJkRmV0Y2hcIjtcclxuXHJcbmNvbnN0IEJvb3RzdHJhcElucHV0ID0gd2l0aFN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgaW5wdXQ6IHtcclxuICAgIG1pbldpZHRoOiBcIjhyZW1cIixcclxuICAgIGJvcmRlclJhZGl1czogNCxcclxuICAgIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gICAgYm9yZGVyOiBcIm5vbmVcIixcclxuICAgIGZvbnRTaXplOiAxNCxcclxuICAgIHBhZGRpbmc6IFwiMTBweCAyNnB4IDEwcHggNXB4XCIsXHJcbiAgICBjb2xvcjogXCIjZmZmXCIsXHJcbiAgICBcIiY6Zm9jdXNcIjoge1xyXG4gICAgICBiYWNrZ3JvdW5kOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubWFpbixcclxuICAgICAgYm9yZGVyUmFkaXVzOiBcIjRweFwiLFxyXG4gICAgfSxcclxuICB9LFxyXG59KSkoSW5wdXRCYXNlKTtcclxuXHJcbmNvbnN0IG9uU3RhcnRFbmQgPSAoZGF0ZSwgbW9udGgsIHllYXIpID0+IHtcclxuICByZXR1cm4gYCR7eWVhcn0tJHttb250aH0tJHtkYXRlfWA7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ3VzdG9taXplZFNlbGVjdHMoKSB7XHJcbiAgY29uc3QgW2RhdGUsIHNldERhdGVdID0gUmVhY3QudXNlU3RhdGUoXCJ0b2RheVwiKTtcclxuXHJcbiAgY29uc3QgeyBzZXRTdGFydERhdGUsIHNldEVuZERhdGUgfSA9IHVzZUNvbnRleHQoRGFzaEJvcmRDb250ZXh0KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKFwiRGF0ZSA9IFwiLCBkYXRlKTtcclxuICB9LCBbZGF0ZV0pO1xyXG5cclxuICBjb25zdCBkYXRlSGFuZGxlciA9IChldmVudCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCB2YWx1ZSA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuICAgIHN3aXRjaCAodmFsdWUpIHtcclxuICAgICAgY2FzZSBcInRvZGF5XCI6XHJcbiAgICAgICAgc2V0U3RhcnREYXRlKFxyXG4gICAgICAgICAgb25TdGFydEVuZChcclxuICAgICAgICAgICAgbmV3RGF0ZS5nZXREYXRlKCksXHJcbiAgICAgICAgICAgIG5ld0RhdGUuZ2V0TW9udGgoKSArIDEsXHJcbiAgICAgICAgICAgIG5ld0RhdGUuZ2V0RnVsbFllYXIoKVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0RW5kRGF0ZShcclxuICAgICAgICAgIG9uU3RhcnRFbmQoXHJcbiAgICAgICAgICAgIG5ld0RhdGUuZ2V0RGF0ZSgpLFxyXG4gICAgICAgICAgICBuZXdEYXRlLmdldE1vbnRoKCkgKyAxLFxyXG4gICAgICAgICAgICBuZXdEYXRlLmdldEZ1bGxZZWFyKClcclxuICAgICAgICAgIClcclxuICAgICAgICApO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwiY3VycmVudFwiOlxyXG4gICAgICAgIHNldFN0YXJ0RGF0ZShcclxuICAgICAgICAgIG9uU3RhcnRFbmQoXCIwMVwiLCBuZXdEYXRlLmdldE1vbnRoKCkgKyAxLCBuZXdEYXRlLmdldEZ1bGxZZWFyKCkpXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRFbmREYXRlKFxyXG4gICAgICAgICAgb25TdGFydEVuZChcIjMwXCIsIG5ld0RhdGUuZ2V0TW9udGgoKSArIDEsIG5ld0RhdGUuZ2V0RnVsbFllYXIoKSlcclxuICAgICAgICApO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwidGhyZWVcIjpcclxuICAgICAgICBzZXRTdGFydERhdGUoXHJcbiAgICAgICAgICBvblN0YXJ0RW5kKFwiMDFcIiwgbmV3RGF0ZS5nZXRNb250aCgpIC0gMiwgbmV3RGF0ZS5nZXRGdWxsWWVhcigpKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0RW5kRGF0ZShcclxuICAgICAgICAgIG9uU3RhcnRFbmQoXCIzMFwiLCBuZXdEYXRlLmdldE1vbnRoKCkgKyAxLCBuZXdEYXRlLmdldEZ1bGxZZWFyKCkpXHJcbiAgICAgICAgKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcInNpeFwiOlxyXG4gICAgICAgIHNldFN0YXJ0RGF0ZShcclxuICAgICAgICAgIG9uU3RhcnRFbmQoXCIwMVwiLCBuZXdEYXRlLmdldE1vbnRoKCkgLSA1LCBuZXdEYXRlLmdldEZ1bGxZZWFyKCkpXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRFbmREYXRlKFxyXG4gICAgICAgICAgb25TdGFydEVuZChcIjMwXCIsIG5ld0RhdGUuZ2V0TW9udGgoKSArIDEsIG5ld0RhdGUuZ2V0RnVsbFllYXIoKSlcclxuICAgICAgICApO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwieWVhclwiOlxyXG4gICAgICAgIHNldFN0YXJ0RGF0ZShvblN0YXJ0RW5kKFwiMDFcIiwgXCIwMVwiLCBuZXdEYXRlLmdldEZ1bGxZZWFyKCkgLSAxKSk7XHJcbiAgICAgICAgc2V0RW5kRGF0ZShvblN0YXJ0RW5kKFwiMzBcIiwgXCIxMlwiLCBuZXdEYXRlLmdldEZ1bGxZZWFyKCkgLSAxKSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICBzZXREYXRlKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxGb3JtQ29udHJvbD5cclxuICAgICAgICA8TmF0aXZlU2VsZWN0XHJcbiAgICAgICAgICBpZD1cImRlbW8tY3VzdG9taXplZC1zZWxlY3QtbmF0aXZlXCJcclxuICAgICAgICAgIHZhbHVlPXtkYXRlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9e2RhdGVIYW5kbGVyfVxyXG4gICAgICAgICAgaW5wdXQ9ezxCb290c3RyYXBJbnB1dCAvPn1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8b3B0aW9uIHN0eWxlPXt7IGNvbG9yOiBcIiMwMDBcIiB9fSB2YWx1ZT17XCJ0b2RheVwifT5cclxuICAgICAgICAgICAgVG9kYXlcclxuICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgPG9wdGlvbiBzdHlsZT17eyBjb2xvcjogXCIjMDAwXCIgfX0gdmFsdWU9e1wiY3VycmVudFwifT5cclxuICAgICAgICAgICAgQ3VycmVudCBNb250aFxyXG4gICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICA8b3B0aW9uIHN0eWxlPXt7IGNvbG9yOiBcIiMwMDBcIiB9fSB2YWx1ZT17XCJ0aHJlZVwifT5cclxuICAgICAgICAgICAgTGFzdCBUaHJlZSBNb250aHNcclxuICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgPG9wdGlvbiBzdHlsZT17eyBjb2xvcjogXCIjMDAwXCIgfX0gdmFsdWU9e1wic2l4XCJ9PlxyXG4gICAgICAgICAgICBMYXN0IDYgTW9udGhzXHJcbiAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgIDxvcHRpb24gc3R5bGU9e3sgY29sb3I6IFwiIzAwMFwiIH19IHZhbHVlPXtcInllYXJcIn0+XHJcbiAgICAgICAgICAgIExhc3QgWWVhclxyXG4gICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgPC9OYXRpdmVTZWxlY3Q+XHJcbiAgICAgIDwvRm9ybUNvbnRyb2w+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiIsImV4cG9ydCB7IFNwaW5uZXIgfSBmcm9tIFwiLi9zcGlubmVyL3NwaW5uZXJcIjtcclxuZXhwb3J0IHsgUGFnZVRpdGxlIH0gZnJvbSBcIi4vcGFnZVRpdGxlL3BhZ2VUaXRsZVwiO1xyXG5leHBvcnQgeyBMZ0J0biB9IGZyb20gXCIuL2xnQnRuL2xnQnRuXCI7XHJcbmV4cG9ydCB7IERhdGVQaWNrZXIgfSBmcm9tIFwiLi9kYXRlUGlja2VyL2RhdGVQaWNrZXJcIjtcclxuZXhwb3J0IHsgU2ltcGxlTW9kYWwgfSBmcm9tIFwiLi9tb2RhbC9tb2RhbFwiO1xyXG5leHBvcnQgeyBDdXN0b21pemVkUmF0aW5ncyB9IGZyb20gXCIuL3JhdGluZ1N0YXIvcmF0aW5nU3RhclwiO1xyXG5leHBvcnQgeyBDdXN0b21pemVkU2VsZWN0cyB9IGZyb20gXCIuL2Ryb3BEb3duL2Ryb3BEb3duXCI7XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyBCdXR0b24sIEdyaWQgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuXHJcbmltcG9ydCB7IERhdGVQaWNrZXIgfSBmcm9tIFwiLi4vXCI7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICByb290OiB7XHJcbiAgICBtYXJnaW5Ub3A6IFwiMXJlbVwiLFxyXG4gIH0sXHJcbiAgYnRuOiB7XHJcbiAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICBwYWRkaW5nOiBcIjAuNXJlbSAwXCIsXHJcbiAgICB0ZXh0VHJhbnNmb3JtOiBcImNhcGl0YWxpemVcIixcclxuICAgIGJhY2tncm91bmQ6IFwiI2Y2ZjZmNlwiLFxyXG4gICAgYm9yZGVyVG9wTGVmdFJhZGl1czogXCIwXCIsXHJcbiAgICBib3JkZXJCb3R0b21MZWZ0UmFkaXVzOiBcIjBcIixcclxuICAgIGNvbG9yOiBcIiMwMDBcIixcclxuICAgIFwiJjpob3ZlclwiOiB7XHJcbiAgICAgIGJhY2tncm91bmQ6IFwiI2Y2ZjZmNlwiLFxyXG4gICAgfSxcclxuICB9LFxyXG4gIGFjdGl2ZToge1xyXG4gICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgY29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgYmFja2dyb3VuZDogdGhlbWUucGFsZXR0ZS5wcmltYXJ5Lm1haW4sXHJcbiAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICBwYWRkaW5nOiBcIjAuNXJlbSAwXCIsXHJcbiAgICB0ZXh0VHJhbnNmb3JtOiBcImNhcGl0YWxpemVcIixcclxuICAgIGJvcmRlclRvcExlZnRSYWRpdXM6IFwiMFwiLFxyXG4gICAgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogXCIwXCIsXHJcbiAgICBcIiY6aG92ZXJcIjoge1xyXG4gICAgICBiYWNrZ3JvdW5kOiBcInZhcigtLXByaW1hcnktY29sb3IpXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBjb25zdCBMZ0J0biA9ICh7XHJcbiAgc2V0Qm9va2luZ1R5cGUsXHJcbiAgYm9va2luZ1R5cGUsXHJcbiAgY2FsZW5kZXIsXHJcbiAgbWFuYWdlbWVudCxcclxufSkgPT4ge1xyXG4gIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuXHJcbiAgbGV0IGxvY2FsID0gXCJib29raW5nTG9jYWxzXCI7XHJcbiAgbGV0IGV4cGVyaWVuY2UgPSBcImJvb2tpbmdFeHBlcmllbmNlc1wiO1xyXG5cclxuICBpZiAobWFuYWdlbWVudCkge1xyXG4gICAgbG9jYWwgPSBcImxvY2Fsc1wiO1xyXG4gICAgZXhwZXJpZW5jZSA9IFwiZXhwZXJpZW5jZXNcIjtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8R3JpZCBjb250YWluZXIgaXRlbSB4cz17Nn0gY2xhc3NOYW1lPXtjbGFzc2VzLnJvb3R9IGFsaWduQ29udGVudD1cImNlbnRlclwiPlxyXG4gICAgICA8R3JpZCBpdGVtIHhzPXsyfT5cclxuICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCb29raW5nVHlwZShsb2NhbCl9XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2Jvb2tpbmdUeXBlID09PSBsb2NhbCA/IGNsYXNzZXMuYWN0aXZlIDogY2xhc3Nlcy5idG59XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgTG9jYWxzXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgICAgPEdyaWQgaXRlbSB4cz17Mn0+XHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Qm9va2luZ1R5cGUoZXhwZXJpZW5jZSl9XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2Jvb2tpbmdUeXBlID09PSBleHBlcmllbmNlID8gY2xhc3Nlcy5hY3RpdmUgOiBjbGFzc2VzLmJ0bn1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBFeHBlcmluY2VcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9HcmlkPlxyXG4gICAgICA8R3JpZCBpdGVtIHhzPXsyfT5cclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICBtYXJnaW46IFwiMC41cmVtIGF1dG9cIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2NhbGVuZGVyICYmIDxEYXRlUGlja2VyIC8+fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICA8L0dyaWQ+XHJcbiAgKTtcclxufTtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b25cIjtcclxuaW1wb3J0IERpYWxvZyBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nXCI7XHJcbmltcG9ydCBEaWFsb2dBY3Rpb25zIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dBY3Rpb25zXCI7XHJcbmltcG9ydCBEaWFsb2dDb250ZW50IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dDb250ZW50XCI7XHJcbmltcG9ydCBEaWFsb2dDb250ZW50VGV4dCBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nQ29udGVudFRleHRcIjtcclxuLy8gaW1wb3J0IERpYWxvZ1RpdGxlIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dUaXRsZVwiO1xyXG5pbXBvcnQgU2xpZGUgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL1NsaWRlXCI7XHJcblxyXG5jb25zdCBUcmFuc2l0aW9uID0gUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBUcmFuc2l0aW9uKHByb3BzLCByZWYpIHtcclxuICByZXR1cm4gPFNsaWRlIGRpcmVjdGlvbj1cInVwXCIgcmVmPXtyZWZ9IHsuLi5wcm9wc30gLz47XHJcbn0pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNpbXBsZU1vZGFsKHsgb3BlbiwgaGFuZGxlQ2xvc2UsIHN0YXR1c0hhbmRsZXIgfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8RGlhbG9nXHJcbiAgICAgICAgb3Blbj17b3Blbn1cclxuICAgICAgICBUcmFuc2l0aW9uQ29tcG9uZW50PXtUcmFuc2l0aW9ufVxyXG4gICAgICAgIGtlZXBNb3VudGVkXHJcbiAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2V9XHJcbiAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwiYWxlcnQtZGlhbG9nLXNsaWRlLXRpdGxlXCJcclxuICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PVwiYWxlcnQtZGlhbG9nLXNsaWRlLWRlc2NyaXB0aW9uXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxEaWFsb2dDb250ZW50PlxyXG4gICAgICAgICAgPERpYWxvZ0NvbnRlbnRUZXh0IGlkPVwiYWxlcnQtZGlhbG9nLXNsaWRlLWRlc2NyaXB0aW9uXCI+XHJcbiAgICAgICAgICAgIEFyZSBZb3UgU3VyZS4uP1xyXG4gICAgICAgICAgPC9EaWFsb2dDb250ZW50VGV4dD5cclxuICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgPERpYWxvZ0FjdGlvbnM+XHJcbiAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUNsb3NlfSBjb2xvcj1cInByaW1hcnlcIj5cclxuICAgICAgICAgICAgRGlzYWdyZWVcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtzdGF0dXNIYW5kbGVyfSBjb2xvcj1cInByaW1hcnlcIj5cclxuICAgICAgICAgICAgQWdyZWVcclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgIDwvRGlhbG9nQWN0aW9ucz5cclxuICAgICAgPC9EaWFsb2c+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCB7IFR5cG9ncmFwaHksIEdyaWQgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmVcIjtcclxuaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvc3R5bGVzXCI7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICB0aXRsZToge1xyXG4gICAgdGV4dFRyYW5zZm9ybTogXCJ1cHBlcmNhc2VcIixcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgY29uc3QgUGFnZVRpdGxlID0gKHsgdGV4dCB9KSA9PiB7XHJcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8R3JpZCBjb250YWluZXI+XHJcbiAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9PlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHkgY2xhc3NOYW1lPXtjbGFzc2VzLnRpdGxlfSB2YXJpYW50PVwiaDVcIj5cclxuICAgICAgICAgICAge3RleHR9XHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBSYXRpbmcgZnJvbSBcIkBtYXRlcmlhbC11aS9sYWIvUmF0aW5nXCI7XHJcbmltcG9ydCBTdGFyQm9yZGVySWNvbiBmcm9tIFwiQG1hdGVyaWFsLXVpL2ljb25zL1N0YXJCb3JkZXJcIjtcclxuaW1wb3J0IEJveCBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvQm94XCI7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ3VzdG9taXplZFJhdGluZ3MoeyByYXRpbmcsIHNpemUsIG1heCA9IDEsIHJldlJhdCB9KSB7XHJcbiAgbGV0IHZhbHVlID0gbnVsbDtcclxuICBpZiAocmF0aW5nID09PSA1ICYmICFyZXZSYXQpIHtcclxuICAgIHZhbHVlID0gMTtcclxuICB9IGVsc2UgaWYgKHJhdGluZyA8IDUgJiYgIXJldlJhdCkge1xyXG4gICAgdmFsdWUgPSAwLjU7XHJcbiAgfVxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8Qm94IGNvbXBvbmVudD1cImZpZWxkc2V0XCIgbWI9ezN9IGJvcmRlckNvbG9yPVwidHJhbnNwYXJlbnRcIj5cclxuICAgICAgICA8UmF0aW5nXHJcbiAgICAgICAgICBzdHlsZT17eyBjb2xvcjogXCJ2YXIoLS1wcmltYXJ5LWNvbG9yKVwiIH19XHJcbiAgICAgICAgICBuYW1lPVwiY3VzdG9taXplZC1lbXB0eVwiXHJcbiAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgbWF4PXttYXh9XHJcbiAgICAgICAgICBwcmVjaXNpb249ezAuNX1cclxuICAgICAgICAgIHZhbHVlPXt2YWx1ZSA/IHZhbHVlIDogcmV2UmF0fVxyXG4gICAgICAgICAgc2l6ZT17c2l6ZX1cclxuICAgICAgICAgIGVtcHR5SWNvbj17PFN0YXJCb3JkZXJJY29uIGZvbnRTaXplPVwiaW5oZXJpdFwiIC8+fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCI7XHJcbmltcG9ydCBDaXJjdWxhclByb2dyZXNzIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9DaXJjdWxhclByb2dyZXNzXCI7XHJcbmltcG9ydCB7IEhlaWdodCB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvaWNvbnNcIjtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gIHJvb3Q6IHtcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgXCImID4gKiArICpcIjoge1xyXG4gICAgICBtYXJnaW5MZWZ0OiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gICAgfSxcclxuICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgIGhlaWdodDogXCIxMDB2aFwiLFxyXG4gICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXHJcbiAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBTcGlubmVyKCkge1xyXG4gIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzLnJvb3R9PlxyXG4gICAgICA8Q2lyY3VsYXJQcm9ncmVzcyBjb2xvcj1cInNlY29uZGFyeVwiIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgY3JlYXRlQ29udGV4dCwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcblxyXG5leHBvcnQgY29uc3QgQm9va2luZ0NvbnRleHQgPSBjcmVhdGVDb250ZXh0KCk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBCb29raW5nRmV0Y2goeyBjaGlsZHJlbiB9KSB7XHJcbiAgY29uc3QgW2Jvb2tpbmdzLCBzZXRCb29raW5nc10gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtjb21wbGV0ZWQsIHNldENvbXBsZXRlZF0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtwZW5kaW5nLCBzZXRQZW5kaW5nXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW25vU2hvdywgc2V0Tm9TaG93XSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW2RlbGV0ZWQsIHNldERlbGV0ZWRdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbYm9va2luZ1R5cGUsIHNldEJvb2tpbmdUeXBlXSA9IHVzZVN0YXRlKFwiYm9va2luZ0xvY2Fsc1wiKTtcclxuXHJcbiAgY29uc3QgW2Jvb2tpbmdEYXRhLCBzZXRCb29raW5nRGF0YV0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtib29raW5nSGVhZGVyLCBzZXRCb29raW5nSGVhZGVyXSA9IHVzZVN0YXRlKCk7XHJcblxyXG4gIGNvbnN0IFtkYXRlLCBzZXREYXRlXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkpO1xyXG4gIGNvbnN0IFttb250aCwgc2V0TW9udGhdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IGZpbHRlciA9IChhcnJheSwgc3RhdHVzLCBzZXRGdW5jKSA9PiB7XHJcbiAgICBjb25zdCBGaWx0ZXJBcnJheSA9IGFycmF5LmZpbHRlcigoZWwpID0+IGVsLnN0YXR1cyA9PT0gc3RhdHVzKTtcclxuICAgIHNldEZ1bmMoRmlsdGVyQXJyYXkpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgYm9va2luZ3NLZXlzID0gW107XHJcbiAgICBsZXQgYm9va2luZ3NEYXRhID0gW107XHJcbiAgICBjb25zdCBmZXRjaGVyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IG5ld0RhdGUgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgICAgICBjb25zdCBwcm94eVVybCA9IFwiaHR0cHM6Ly9jb3JzLWFueXdoZXJlLmhlcm9rdWFwcC5jb20vXCI7XHJcbiAgICAgICAgY29uc3QgdXJsID0gYGh0dHA6Ly9uYXBwZXRpdG8tc3RhZ2UuaGVyb2t1YXBwLmNvbS9hcGkvJHtib29raW5nVHlwZX0vNWVjNTAzY2M0MzRkZmYyOWNmNTY2MzNiLyR7bmV3RGF0ZS5nZXRGdWxsWWVhcigpfS0ke1xyXG4gICAgICAgICAgbmV3RGF0ZS5nZXRNb250aCgpICsgMVxyXG4gICAgICAgIH0tJHtuZXdEYXRlLmdldERhdGUoKX0vYWxsYDtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChwcm94eVVybCArIHVybCk7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgc2V0Qm9va2luZ3MoZGF0YSk7XHJcbiAgICAgICAgT2JqZWN0LnZhbHVlcyhkYXRhKS5mb3JFYWNoKChlbCwgaSkgPT4ge1xyXG4gICAgICAgICAgaWYgKGkgPT09IDApIHtcclxuICAgICAgICAgICAgT2JqZWN0LmtleXMoZWwpLmZvckVhY2goKGtleSkgPT4ge1xyXG4gICAgICAgICAgICAgIGJvb2tpbmdzS2V5cy5wdXNoKHsgbGFiZWw6IGtleSwga2V5OiBrZXkgfSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgYm9va2luZ3NEYXRhLnB1c2goZWwpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldEJvb2tpbmdEYXRhKGJvb2tpbmdzRGF0YSk7XHJcbiAgICAgICAgc2V0Qm9va2luZ0hlYWRlcihib29raW5nc0tleXMpO1xyXG4gICAgICAgIGZpbHRlcihkYXRhLCBcImRlbGV0ZWRcIiwgc2V0RGVsZXRlZCk7XHJcbiAgICAgICAgZmlsdGVyKGRhdGEsIFwicGVuZGluZ1wiLCBzZXRQZW5kaW5nKTtcclxuICAgICAgICBmaWx0ZXIoZGF0YSwgXCJuby1zaG93XCIsIHNldE5vU2hvdyk7XHJcbiAgICAgICAgZmlsdGVyKGRhdGEsIFwiY29tcGxldGVkXCIsIHNldENvbXBsZXRlZCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hlcigpO1xyXG4gIH0sIFtkYXRlLCBib29raW5nVHlwZV0pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8Qm9va2luZ0NvbnRleHQuUHJvdmlkZXJcclxuICAgICAgdmFsdWU9e3tcclxuICAgICAgICBib29raW5ncyxcclxuICAgICAgICBkYXRlLFxyXG4gICAgICAgIHNldERhdGUsXHJcbiAgICAgICAgZGVsZXRlZCxcclxuICAgICAgICBwZW5kaW5nLFxyXG4gICAgICAgIG5vU2hvdyxcclxuICAgICAgICBjb21wbGV0ZWQsXHJcbiAgICAgICAgYm9va2luZ0RhdGEsXHJcbiAgICAgICAgYm9va2luZ0hlYWRlcixcclxuICAgICAgICBtb250aCxcclxuICAgICAgICBzZXRNb250aCxcclxuICAgICAgICBzZXRCb29raW5nVHlwZSxcclxuICAgICAgICBib29raW5nVHlwZVxyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L0Jvb2tpbmdDb250ZXh0LlByb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgY3JlYXRlQ29udGV4dCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBEYXNoQm9yZENvbnRleHQgPSBjcmVhdGVDb250ZXh0KCk7XHJcblxyXG5jb25zdCBmZXRjaGVyID0gKGVuZHBvaW50LCBzdGFydERhdGUsIGVuZERhdGUsIHNldERhdGEpID0+IHtcclxuICBmZXRjaChcclxuICAgIGBodHRwczovL2NvcnMtYW55d2hlcmUuaGVyb2t1YXBwLmNvbS9odHRwOi8vbmFwcGV0aXRvLXN0YWdlLmhlcm9rdWFwcC5jb20vYXBpLyR7ZW5kcG9pbnR9YCxcclxuICAgIHtcclxuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHN0YXJ0RGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgIGVuZERhdGU6IGVuZERhdGUsXHJcbiAgICAgICAgdXNlcklkOiBcIjVlYzUwM2NjNDM0ZGZmMjljZjU2NjMzYlwiLFxyXG4gICAgICB9KSxcclxuICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4gICAgfVxyXG4gIClcclxuICAgIC50aGVuKChyZXMpID0+IHJlcy5qc29uKCkpXHJcbiAgICAudGhlbigocmVzdWx0KSA9PiB7XHJcbiAgICAgIHNldERhdGEocmVzdWx0KTtcclxuICAgIH0pXHJcbiAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coXCJFcnJvciA9IFwiLCBlcnIpKTtcclxufTtcclxuXHJcbmNvbnN0IGZldGNoZXJSZXZpZXdzID0gYXN5bmMgKHVybCwgc2V0RGF0YSkgPT4ge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBwcm94eVVybCA9IFwiaHR0cHM6Ly9jb3JzLWFueXdoZXJlLmhlcm9rdWFwcC5jb20vXCI7XHJcbiAgICBjb25zdCB1cmxsID0gdXJsO1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2gocHJveHlVcmwgKyB1cmxsKTtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgc2V0RGF0YShkYXRhKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZEZldGNoKHsgY2hpbGRyZW4gfSkge1xyXG4gIGNvbnN0IFtzdGFydERhdGUsIHNldFN0YXJ0RGF0ZV0gPSB1c2VTdGF0ZShuZXcgRGF0ZSgpKTtcclxuICBjb25zdCBbZW5kRGF0ZSwgc2V0RW5kRGF0ZV0gPSB1c2VTdGF0ZShuZXcgRGF0ZSgpKTtcclxuXHJcbiAgY29uc3QgW3Jldmlld3MsIHNldFJldmlld3NdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbYm9va2luZ3MsIHNldEJvb2tpbmdzXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW2NvbXBsZXRlZCwgc2V0Q29tcGxldGVkXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW2RlbGV0ZWQsIHNldERlbGV0ZWRdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbbm9TaG93LCBzZXROb1Nob3ddID0gdXNlU3RhdGUoKTtcclxuXHJcbiAgY29uc3QgW2V4cFJldmlld3MsIHNldEV4cFJldmlld3NdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbZXhwQm9va2luZ3MsIHNldEV4cEJvb2tpbmdzXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW2Vhcm5pbmdzLCBzZXRFYXJuaW5nc10gPSB1c2VTdGF0ZSgpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hlclJldmlld3MoXHJcbiAgICAgIGBodHRwOi8vbmFwcGV0aXRvLXN0YWdlLmhlcm9rdWFwcC5jb20vYXBpL3Jldmlld0xvY2FsVG90YWxDb3VudC81ZWM1MDNjYzQzNGRmZjI5Y2Y1NjYzM2JgLFxyXG4gICAgICBzZXRSZXZpZXdzXHJcbiAgICApO1xyXG5cclxuICAgIGZldGNoZXJSZXZpZXdzKFxyXG4gICAgICBcImh0dHA6Ly9uYXBwZXRpdG8tc3RhZ2UuaGVyb2t1YXBwLmNvbS9hcGkvcmV2aWV3RXhwZXJpZW5jZVRvdGFsQ291bnQvNWZhM2ViOWY5NDEyYzNmZTA1MTNkZGM2XCIsXHJcbiAgICAgIHNldEV4cFJldmlld3NcclxuICAgICk7XHJcblxyXG4gICAgZmV0Y2hlcihcImJvb2tpbmdMb2NhbHNUb3RhbENvdW50XCIsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgc2V0Qm9va2luZ3MpO1xyXG4gICAgZmV0Y2hlcihcImJvb2tpbmdMb2NhbHNDb21wbGV0ZWRDb3VudFwiLCBzdGFydERhdGUsIGVuZERhdGUsIHNldENvbXBsZXRlZCk7XHJcbiAgICBmZXRjaGVyKFwiYm9va2luZ0xvY2Fsc0RlbGV0ZWRDb3VudFwiLCBzdGFydERhdGUsIGVuZERhdGUsIHNldERlbGV0ZWQpO1xyXG4gICAgZmV0Y2hlcihcImJvb2tpbmdMb2NhbHNOb1Nob3dDb3VudFwiLCBzdGFydERhdGUsIGVuZERhdGUsIHNldE5vU2hvdyk7XHJcblxyXG4gICAgZmV0Y2hlcihcImJvb2tpbmdFeHBlcmllbmNlc1RvdGFsQ291bnRcIiwgc3RhcnREYXRlLCBlbmREYXRlLCBzZXRFeHBCb29raW5ncyk7XHJcbiAgICBmZXRjaGVyKFwiYm9va2luZ0V4cGVyaWVuY2VzVG90YWxHYWluXCIsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgc2V0RWFybmluZ3MpO1xyXG4gIH0sIFtcclxuICAgIGJvb2tpbmdzLFxyXG4gICAgcmV2aWV3cyxcclxuICAgIGNvbXBsZXRlZCxcclxuICAgIGRlbGV0ZWQsXHJcbiAgICBub1Nob3csXHJcbiAgICBzdGFydERhdGUsXHJcbiAgICBlbmREYXRlLFxyXG4gICAgZXhwUmV2aWV3cyxcclxuICAgIGV4cEJvb2tpbmdzLFxyXG4gICAgZWFybmluZ3MsXHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IGxvY2FsID0gW1xyXG4gICAgeyBzcmM6IFwiL2ltYWdlcy9zdGFycy5zdmdcIiwgdHh0OiBcIlJldmlld3NcIiwgdG90YWw6IHJldmlld3MgfSxcclxuICAgIHtcclxuICAgICAgc3JjOiBcIi9pbWFnZXMvYm9va2luZ3Muc3ZnXCIsXHJcbiAgICAgIHR4dDogXCJCb29raW5ncyBUb3RhbFwiLFxyXG4gICAgICB0b3RhbDogYm9va2luZ3MsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBzcmM6IFwiL2ltYWdlcy9ib29rLWNvbXAuc3ZnXCIsXHJcbiAgICAgIHR4dDogXCJCb29raW5ncyBDb21wbGV0ZWRcIixcclxuICAgICAgdG90YWw6IGNvbXBsZXRlZCxcclxuICAgIH0sXHJcbiAgICB7IHNyYzogXCIvaW1hZ2VzL2Jvb2stZGVsLnN2Z1wiLCB0eHQ6IFwiQm9va2luZ3MgRGVsZXRlZFwiLCB0b3RhbDogZGVsZXRlZCB9LFxyXG4gICAgeyBzcmM6IFwiL2ltYWdlcy9ib29rLW5vU2hvdy5zdmdcIiwgdHh0OiBcIkJvb2tpbmdzIE5vLVNob3dcIiwgdG90YWw6IG5vU2hvdyB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGV4cGVyaWVuY2UgPSBbXHJcbiAgICB7IHNyYzogXCIvaW1hZ2VzL3N0YXJzLnN2Z1wiLCB0eHQ6IFwiUmV2aWV3c1wiLCB0b3RhbDogZXhwUmV2aWV3cyB9LFxyXG4gICAge1xyXG4gICAgICBzcmM6IFwiL2ltYWdlcy9ib29raW5ncy5zdmdcIixcclxuICAgICAgdHh0OiBcIkJvb2tpbmdzIFRvdGFsXCIsXHJcbiAgICAgIHRvdGFsOiBleHBCb29raW5ncyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHNyYzogXCIvaW1hZ2VzL2Vhcm5pbmcuc3ZnXCIsXHJcbiAgICAgIHR4dDogXCJFYXJuaW5nc1wiLFxyXG4gICAgICB0b3RhbDogZWFybmluZ3MsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RGFzaEJvcmRDb250ZXh0LlByb3ZpZGVyXHJcbiAgICAgIHZhbHVlPXt7XHJcbiAgICAgICAgc2V0U3RhcnREYXRlLFxyXG4gICAgICAgIHNldEVuZERhdGUsXHJcbiAgICAgICAgbG9jYWwsXHJcbiAgICAgICAgZXhwZXJpZW5jZSxcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9EYXNoQm9yZENvbnRleHQuUHJvdmlkZXI+XHJcbiAgKTtcclxufVxyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuaW1wb3J0IHsgR3JpZCwgVHlwb2dyYXBoeSB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5cclxuaW1wb3J0IHsgQ3VzdG9taXplZFJhdGluZ3MgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy91aVwiO1xyXG5pbXBvcnQgeyBSZXZpZXdCb3ggfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9yZXZpZXdzXCI7XHJcblxyXG5pbXBvcnQgY2xhc3NlcyBmcm9tIFwiLi4vLi4vc3R5bGVzL3Jldmlldy5tb2R1bGUuY3NzXCI7XHJcblxyXG5jb25zdCBSYXREZXNjcCA9ICh7IHJldmlld0NvdW50LCB0aXRsZSB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxHcmlkIGNvbnRhaW5lciBqdXN0aWZ5PVwic3BhY2UtYmV0d2VlblwiIGNsYXNzTmFtZT17Y2xhc3Nlcy5yYXREZWNwfT5cclxuICAgICAgPEdyaWQgY29udGFpbmVyIGl0ZW0geHM9ezZ9PlxyXG4gICAgICAgIDxHcmlkIGl0ZW0geHM9ezN9PlxyXG4gICAgICAgICAge3Jldmlld0NvdW50ID09PSAwIHx8XHJcbiAgICAgICAgICAgIChyZXZpZXdDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoNVwiPntyZXZpZXdDb3VudH08L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8R3JpZCBpdGVtIHhzPXs2fT5cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiBcIjAuNHJlbVwiIH19PlxyXG4gICAgICAgICAgICA8Q3VzdG9taXplZFJhdGluZ3MgbWF4PXs1fSByZXZSYXQ9e2Ake3Jldmlld0NvdW50fWB9IHNpemU9XCJzbWFsbFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgICAgPEdyaWQgaXRlbSB4cz17Nn0+XHJcbiAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgIHN0eWxlPXt7IG1hcmdpblRvcDogXCIwLjNyZW1cIiB9fVxyXG4gICAgICAgICAgdmFyaWFudD1cInN1YnRpdGxlMVwiXHJcbiAgICAgICAgICBhbGlnbj1cInJpZ2h0XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICA8L0dyaWQ+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJldmlldyh7IHJldmlld0xvY2FsLCByZXZpZXdFeHBlcmllbmNlIH0pIHtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuXHJcbiAgY29uc3QgdHlwZSA9IHJvdXRlci5xdWVyeS5yZXZpZXc7XHJcblxyXG4gIGxldCByZXZpZXdEYXRhID0gbnVsbDtcclxuICBpZiAodHlwZSA9PT0gXCJsb2NhbFwiKSB7XHJcbiAgICByZXZpZXdEYXRhID0gcmV2aWV3TG9jYWw7XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldmlld0RhdGEgPSByZXZpZXdFeHBlcmllbmNlO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgW3Jldmlld3NTaW1wbGUsIHNldFJldmlld3NTaW1wbGVdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbcmV2aWV3c0Jvb2tpbmcsIHNldFJldmlld3NCb29raW5nXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW3Jldmlld3NUb3RhbCwgc2V0UmV2aWV3c1RvdGFsXSA9IHVzZVN0YXRlKCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgaWQgPSBcIjVlYzUwM2NjNDM0ZGZmMjljZjU2NjMzYlwiO1xyXG4gICAgbGV0IHR5cGVGZXRjaCA9IFwicHVibGljTG9jYWxcIjtcclxuICAgIGlmICh0eXBlID09PSBcImV4cGVyaWVuY2VcIikge1xyXG4gICAgICBpZCA9IFwiNWZhM2ViOWY5NDEyYzNmZTA1MTNkZGM2XCI7XHJcbiAgICAgIHR5cGVGZXRjaCA9IFwicHVibGljRXhwZXJpZW5jZVwiO1xyXG4gICAgfVxyXG4gICAgZmV0Y2goYGh0dHA6Ly9uYXBwZXRpdG8tc3RhZ2UuaGVyb2t1YXBwLmNvbS9hcGkvJHt0eXBlRmV0Y2h9UmV2aWV3cy8ke2lkfWApXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHJlcy5qc29uKCkpXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiBzZXRSZXZpZXdzU2ltcGxlKGRhdGEpKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgaWQgPSBcIjVlYzUwM2NjNDM0ZGZmMjljZjU2NjMzYlwiO1xyXG4gICAgbGV0IHR5cGVGZXRjaCA9IFwiYm9va2luZ0xvY2FsXCI7XHJcbiAgICBpZiAodHlwZSA9PT0gXCJleHBlcmllbmNlXCIpIHtcclxuICAgICAgaWQgPSBcIjVmYTNlYjlmOTQxMmMzZmUwNTEzZGRjNlwiO1xyXG4gICAgICB0eXBlRmV0Y2ggPSBcImJvb2tpbmdFeHBlcmllbmNlXCI7XHJcbiAgICB9XHJcbiAgICBmZXRjaChgaHR0cDovL25hcHBldGl0by1zdGFnZS5oZXJva3VhcHAuY29tL2FwaS8ke3R5cGVGZXRjaH1SZXZpZXdzLyR7aWR9YClcclxuICAgICAgLnRoZW4oKHJlcykgPT4gcmVzLmpzb24oKSlcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHNldFJldmlld3NCb29raW5nKGRhdGEpKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgaWQgPSBcIjVlYzUwM2NjNDM0ZGZmMjljZjU2NjMzYlwiO1xyXG4gICAgbGV0IHR5cGVGZXRjaCA9IFwidG90YWxMb2NhbFwiO1xyXG4gICAgaWYgKHR5cGUgPT09IFwiZXhwZXJpZW5jZVwiKSB7XHJcbiAgICAgIGlkID0gXCI1ZmEzZWI5Zjk0MTJjM2ZlMDUxM2RkYzZcIjtcclxuICAgICAgdHlwZUZldGNoID0gXCJ0b3RhbEV4cGVyaWVuY2VcIjtcclxuICAgIH1cclxuICAgIGZldGNoKGBodHRwOi8vbmFwcGV0aXRvLXN0YWdlLmhlcm9rdWFwcC5jb20vYXBpLyR7dHlwZUZldGNofVJldmlld3MvJHtpZH1gKVxyXG4gICAgICAudGhlbigocmVzKSA9PiByZXMuanNvbigpKVxyXG4gICAgICAudGhlbigoZGF0YSkgPT4gc2V0UmV2aWV3c1RvdGFsKGRhdGEpKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IG1vbnRoX25hbWUgPSAoZHQpID0+IHtcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkdCk7XHJcbiAgICBjb25zdCBtbGlzdCA9IFtcclxuICAgICAgXCJKYW51YXJ5XCIsXHJcbiAgICAgIFwiRmVicnVhcnlcIixcclxuICAgICAgXCJNYXJjaFwiLFxyXG4gICAgICBcIkFwcmlsXCIsXHJcbiAgICAgIFwiTWF5XCIsXHJcbiAgICAgIFwiSnVuZVwiLFxyXG4gICAgICBcIkp1bHlcIixcclxuICAgICAgXCJBdWd1c3RcIixcclxuICAgICAgXCJTZXB0ZW1iZXJcIixcclxuICAgICAgXCJPY3RvYmVyXCIsXHJcbiAgICAgIFwiTm92ZW1iZXJcIixcclxuICAgICAgXCJEZWNlbWJlclwiLFxyXG4gICAgXTtcclxuICAgIHJldHVybiBgJHtkYXRlLmdldERhdGUoKX0tJHttbGlzdFtkYXRlLmdldE1vbnRoKCldLnNsaWNlKFxyXG4gICAgICAwLFxyXG4gICAgICAzXHJcbiAgICApfS0ke2RhdGUuZ2V0RnVsbFllYXIoKX1gO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8SGVhZD5cclxuICAgICAgICA8dGl0bGU+UmV2aWV3czwvdGl0bGU+XHJcbiAgICAgIDwvSGVhZD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMucmV2aWV3fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy50dXR0b30+XHJcbiAgICAgICAgICA8ZGl2PlR1dHRvPC9kaXY+XHJcbiAgICAgICAgICB7WzUsIDQsIDMsIDIsIDFdLm1hcCgoZWwsIGkpID0+IChcclxuICAgICAgICAgICAgPGRpdiBrZXk9e2l9PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzLnJhdF9udW19PntlbH08L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5yYXRfc3Rhcn0+XHJcbiAgICAgICAgICAgICAgICA8Q3VzdG9taXplZFJhdGluZ3MgcmF0aW5nPXs1fSBzaXplPVwic21hbGxcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxHcmlkIGNvbnRhaW5lciBjbGFzc05hbWU9e2NsYXNzZXMubWlkZGxlfT5cclxuICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBpdGVtIHhzPXs4fSBjbGFzc05hbWU9e2NsYXNzZXMubWlkZGxlX21haW59PlxyXG4gICAgICAgICAgICA8R3JpZFxyXG4gICAgICAgICAgICAgIGNvbnRhaW5lclxyXG4gICAgICAgICAgICAgIGl0ZW1cclxuICAgICAgICAgICAgICB4cz17MTJ9XHJcbiAgICAgICAgICAgICAganVzdGlmeT1cInNwYWNlLWJldHdlZW5cIlxyXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17Mn0+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMubWlkZGxlX21haW5faGVhZGluZ31cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImg1XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgcmV2aWV3c1xyXG4gICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICB7cmV2aWV3RGF0YT8ubWFwKChyZXYpID0+IHtcclxuICAgICAgICAgICAgICBjb25zdCB7XHJcbiAgICAgICAgICAgICAgICBfaWQsXHJcbiAgICAgICAgICAgICAgICBwb3N0ZWRCeU5hbWUsXHJcbiAgICAgICAgICAgICAgICB0ZXh0LFxyXG4gICAgICAgICAgICAgICAgcmVwbGllZCxcclxuICAgICAgICAgICAgICAgIGNyZWF0ZWRBdCxcclxuICAgICAgICAgICAgICAgIHJhdGluZyxcclxuICAgICAgICAgICAgICAgIGNvbW1lbnRzLFxyXG4gICAgICAgICAgICAgIH0gPSByZXY7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBrZXk9e19pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDxSZXZpZXdCb3hcclxuICAgICAgICAgICAgICAgICAgICBpZD17X2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9e3Bvc3RlZEJ5TmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBkYXRlPXtgJHttb250aF9uYW1lKGNyZWF0ZWRBdCl9IC0gUGljaydzIFB1YmB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmF0VGV4dD1cIlZhbHV0YXppb25lIENvbXBsZXNzaXZhXCJcclxuICAgICAgICAgICAgICAgICAgICByZXZpZXc9e3RleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVwbGllZD17cmVwbGllZH1cclxuICAgICAgICAgICAgICAgICAgICByZXZSYXQ9e051bWJlcihyYXRpbmcpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbW1lbnRzPXtjb21tZW50c31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezR9PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5yYXRpbmdCb3h9PlxyXG4gICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlJldmlld3NcIixcclxuICAgICAgICAgICAgICAgICAgcmF0aW5nczogcmV2aWV3c1NpbXBsZSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIkJvb2tpbmcgUmV2aWV3c1wiLFxyXG4gICAgICAgICAgICAgICAgICByYXRpbmdzOiByZXZpZXdzQm9va2luZyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIlRvdGFsIFJldmlld3NcIixcclxuICAgICAgICAgICAgICAgICAgcmF0aW5nczogcmV2aWV3c1RvdGFsLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBdPy5tYXAoKGl0ZW0sIGkpID0+IChcclxuICAgICAgICAgICAgICAgIDxSYXREZXNjcFxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2l9XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPXtpdGVtLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICByZXZpZXdDb3VudD17aXRlbS5yYXRpbmdzfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdGF0aWNQYXRocygpIHtcclxuICBjb25zdCBwYXRocyA9IFtcIi9kYXNoYm9hcmQvbG9jYWxcIiwgXCIvZGFzaGJvYXJkL2V4cGVyaWVuY2VcIl07XHJcbiAgcmV0dXJuIHsgcGF0aHMsIGZhbGxiYWNrOiB0cnVlIH07XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTdGF0aWNQcm9wcygpIHtcclxuICBjb25zdCBsb2NhbCA9IGF3YWl0IGZldGNoKFxyXG4gICAgXCJodHRwOi8vbmFwcGV0aXRvLXN0YWdlLmhlcm9rdWFwcC5jb20vYXBpL3Jldmlld3NMb2NhbC81ZWM1MDNjYzQzNGRmZjI5Y2Y1NjYzM2JcIlxyXG4gICk7XHJcbiAgY29uc3QgcmV2aWV3TG9jYWwgPSBhd2FpdCBsb2NhbC5qc29uKCk7XHJcblxyXG4gIGNvbnN0IGV4cGVyaWVuY2UgPSBhd2FpdCBmZXRjaChcclxuICAgIGBodHRwOi8vbmFwcGV0aXRvLXN0YWdlLmhlcm9rdWFwcC5jb20vYXBpL3Jldmlld3NFeHBlcmllbmNlLzVmYTNlYjlmOTQxMmMzZmUwNTEzZGRjNmBcclxuICApO1xyXG4gIGNvbnN0IHJldmlld0V4cGVyaWVuY2UgPSBhd2FpdCBleHBlcmllbmNlLmpzb24oKTtcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIHByb3BzOiB7XHJcbiAgICAgIHJldmlld0xvY2FsLFxyXG4gICAgICByZXZpZXdFeHBlcmllbmNlLFxyXG4gICAgfSxcclxuICB9O1xyXG59XHJcbiIsIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcInR1dHRvXCI6IFwicmV2aWV3X3R1dHRvX18zeUszeVwiLFxuXHRcInJhdF9udW1cIjogXCJyZXZpZXdfcmF0X251bV9fMWFnZExcIixcblx0XCJyYXRfc3RhclwiOiBcInJldmlld19yYXRfc3Rhcl9fMlVkaFdcIixcblx0XCJtaWRkbGVcIjogXCJyZXZpZXdfbWlkZGxlX18ybW1Xb1wiLFxuXHRcIm1pZGRsZV9tYWluXCI6IFwicmV2aWV3X21pZGRsZV9tYWluX18yeUJMVFwiLFxuXHRcIm1pZGRsZV9tYWluX2hlYWRpbmdcIjogXCJyZXZpZXdfbWlkZGxlX21haW5faGVhZGluZ19fM0I2ZFRcIixcblx0XCJyYXRpbmdCb3hcIjogXCJyZXZpZXdfcmF0aW5nQm94X18yNWN1OVwiLFxuXHRcInJhdERlY3BcIjogXCJyZXZpZXdfcmF0RGVjcF9fbHUzS09cIlxufTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBkYXRlLWlvL2RhdGUtZm5zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0FjY29yZGlvblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9BY2NvcmRpb25EZXRhaWxzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0FjY29yZGlvblN1bW1hcnlcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQm94XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0J1dHRvblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9DaXJjdWxhclByb2dyZXNzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dBY3Rpb25zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ0NvbnRlbnRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nQ29udGVudFRleHRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvRm9ybUNvbnRyb2xcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvR3JpZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9JbnB1dEJhc2VcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvTmF0aXZlU2VsZWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL1NsaWRlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL1R5cG9ncmFwaHlcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29uc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQ2FsZW5kYXJUb2RheU91dGxpbmVkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9FeHBhbmRNb3JlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9TdGFyQm9yZGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9sYWIvUmF0aW5nXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9waWNrZXJzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZGF0ZS1mbnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9oZWFkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvcm91dGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9