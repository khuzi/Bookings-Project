module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/ui/datePicker/datePicker.js":
/*!************************************************!*\
  !*** ./components/ui/datePicker/datePicker.js ***!
  \************************************************/
/*! exports provided: DatePicker */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DatePicker", function() { return DatePicker; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! date-fns */ "date-fns");
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Grid */ "@material-ui/core/Grid");
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @date-io/date-fns */ "@date-io/date-fns");
/* harmony import */ var _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_date_io_date_fns__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/pickers */ "@material-ui/pickers");
/* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_icons_CalendarTodayOutlined__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/icons/CalendarTodayOutlined */ "@material-ui/icons/CalendarTodayOutlined");
/* harmony import */ var _material_ui_icons_CalendarTodayOutlined__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_CalendarTodayOutlined__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _context_bookingFetch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../context/bookingFetch */ "./context/bookingFetch.js");

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\datePicker\\datePicker.js";








function DatePicker() {
  const value = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(_context_bookingFetch__WEBPACK_IMPORTED_MODULE_8__["BookingContext"]);
  const {
    date,
    setDate,
    setMonth,
    month
  } = value;
  react__WEBPACK_IMPORTED_MODULE_1___default.a.useEffect(() => {
    const dateText = month_name(new Date()) + " " + new Date().getDate();
    setMonth(dateText);
    console.log(month);
  }, []);

  const month_name = dt => {
    const mlist = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return mlist[dt.getMonth()];
  };

  const handleDateChange = dat => {
    setDate(dat);
    const dateText = month_name(new Date(dat)) + " " + dat.getDate();
    setMonth(dateText);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__["MuiPickersUtilsProvider"], {
    utils: _date_io_date_fns__WEBPACK_IMPORTED_MODULE_4___default.a,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_3___default.a, {
      item: true,
      xs: 6,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "date-picker",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_5__["KeyboardDatePicker"], {
          keyboardIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "40",
            height: "40",
            viewBox: "0 0 60 60",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("g", {
              id: "Group_14365",
              "data-name": "Group 14365",
              transform: "translate(-541.25 -144.75)",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("path", {
                id: "Path_14888",
                "data-name": "Path 14888",
                d: "M34.114,0H5.386A5.393,5.393,0,0,0,0,5.386V34.114A5.394,5.394,0,0,0,5.386,39.5H34.114A5.394,5.394,0,0,0,39.5,34.114V5.386A5.394,5.394,0,0,0,34.114,0ZM37.7,34.114A3.6,3.6,0,0,1,34.114,37.7H5.386A3.6,3.6,0,0,1,1.8,34.114V5.386A3.6,3.6,0,0,1,5.386,1.8H34.114A3.6,3.6,0,0,1,37.7,5.386Z",
                transform: "translate(541.5 145)",
                fill: "#e72311",
                stroke: "#e72311",
                "stroke-width": "0.5"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 67,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ellipse", {
                id: "Ellipse_3550",
                "data-name": "Ellipse 3550",
                cx: "1.524",
                cy: "1.524",
                rx: "1.524",
                ry: "1.524",
                transform: "translate(551.047 151.17)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ellipse", {
                id: "Ellipse_3551",
                "data-name": "Ellipse 3551",
                cx: "1.524",
                cy: "1.524",
                rx: "1.524",
                ry: "1.524",
                transform: "translate(559.727 151.17)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("ellipse", {
                id: "Ellipse_3552",
                "data-name": "Ellipse 3552",
                cx: "1.524",
                cy: "1.524",
                rx: "1.524",
                ry: "1.524",
                transform: "translate(568.404 151.17)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 96,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2864",
                "data-name": "Rectangle 2864",
                width: "5.501",
                height: "4.893",
                transform: "translate(554.827 160.443)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 106,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2865",
                "data-name": "Rectangle 2865",
                width: "5.5",
                height: "4.893",
                transform: "translate(562.172 160.443)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 114,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2866",
                "data-name": "Rectangle 2866",
                width: "5.501",
                height: "4.893",
                transform: "translate(569.514 160.443)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 122,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2867",
                "data-name": "Rectangle 2867",
                width: "5.5",
                height: "4.891",
                transform: "translate(547.484 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 130,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2868",
                "data-name": "Rectangle 2868",
                width: "5.501",
                height: "4.891",
                transform: "translate(554.827 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 138,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2869",
                "data-name": "Rectangle 2869",
                width: "5.5",
                height: "4.891",
                transform: "translate(562.172 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 146,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2870",
                "data-name": "Rectangle 2870",
                width: "5.501",
                height: "4.891",
                transform: "translate(569.514 166.976)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 154,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2871",
                "data-name": "Rectangle 2871",
                width: "5.5",
                height: "4.891",
                transform: "translate(547.484 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 162,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2872",
                "data-name": "Rectangle 2872",
                width: "5.501",
                height: "4.891",
                transform: "translate(554.827 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 170,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2873",
                "data-name": "Rectangle 2873",
                width: "5.5",
                height: "4.891",
                transform: "translate(562.172 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 178,
                columnNumber: 19
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("rect", {
                id: "Rectangle_2874",
                "data-name": "Rectangle 2874",
                width: "5.501",
                height: "4.891",
                transform: "translate(569.514 173.507)",
                fill: "#e72311"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 186,
                columnNumber: 19
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 62,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 56,
            columnNumber: 15
          }, this),
          margin: "normal",
          value: date,
          onChange: handleDateChange,
          format: "yyyy-MM-ddd",
          KeyboardButtonProps: {
            "aria-label": "change date"
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 51,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/dropDown/dropDown.js":
/*!********************************************!*\
  !*** ./components/ui/dropDown/dropDown.js ***!
  \********************************************/
/*! exports provided: CustomizedSelects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomizedSelects", function() { return CustomizedSelects; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/FormControl */ "@material-ui/core/FormControl");
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/NativeSelect */ "@material-ui/core/NativeSelect");
/* harmony import */ var _material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/InputBase */ "@material-ui/core/InputBase");
/* harmony import */ var _material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _context_dashboardFetch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../context/dashboardFetch */ "./context/dashboardFetch.js");

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\dropDown\\dropDown.js";






const BootstrapInput = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__["withStyles"])(theme => ({
  input: {
    minWidth: "8rem",
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.primary.main,
    border: "none",
    fontSize: 14,
    padding: "10px 26px 10px 5px",
    color: "#fff",
    "&:focus": {
      background: theme.palette.primary.main,
      borderRadius: "4px"
    }
  }
}))(_material_ui_core_InputBase__WEBPACK_IMPORTED_MODULE_5___default.a);

const onStartEnd = (date, month, year) => {
  return `${year}-${month}-${date}`;
};

function CustomizedSelects() {
  const [date, setDate] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState("today");
  const {
    setStartDate,
    setEndDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useContext"])(_context_dashboardFetch__WEBPACK_IMPORTED_MODULE_6__["DashBordContext"]);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    console.log("Date = ", date);
  }, [date]);

  const dateHandler = event => {
    const newDate = new Date();
    const value = event.target.value;

    switch (value) {
      case "today":
        setStartDate(onStartEnd(newDate.getDate(), newDate.getMonth() + 1, newDate.getFullYear()));
        setEndDate(onStartEnd(newDate.getDate(), newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "current":
        setStartDate(onStartEnd("01", newDate.getMonth() + 1, newDate.getFullYear()));
        setEndDate(onStartEnd("30", newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "three":
        setStartDate(onStartEnd("01", newDate.getMonth() - 2, newDate.getFullYear()));
        setEndDate(onStartEnd("30", newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "six":
        setStartDate(onStartEnd("01", newDate.getMonth() - 5, newDate.getFullYear()));
        setEndDate(onStartEnd("30", newDate.getMonth() + 1, newDate.getFullYear()));
        break;

      case "year":
        setStartDate(onStartEnd("01", "01", newDate.getFullYear() - 1));
        setEndDate(onStartEnd("30", "12", newDate.getFullYear() - 1));
        break;

      default:
        break;
    }

    setDate(event.target.value);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_3___default.a, {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_NativeSelect__WEBPACK_IMPORTED_MODULE_4___default.a, {
        id: "demo-customized-select-native",
        value: date,
        onChange: dateHandler,
        input: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(BootstrapInput, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 18
        }, this),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "today",
          children: "Today"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 102,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "current",
          children: "Current Month"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "three",
          children: "Last Three Months"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "six",
          children: "Last 6 Months"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 111,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("option", {
          style: {
            color: "#000"
          },
          value: "year",
          children: "Last Year"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 114,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 94,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/index.js":
/*!********************************!*\
  !*** ./components/ui/index.js ***!
  \********************************/
/*! exports provided: Spinner, PageTitle, LgBtn, DatePicker, SimpleModal, CustomizedRatings, CustomizedSelects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _spinner_spinner__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./spinner/spinner */ "./components/ui/spinner/spinner.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Spinner", function() { return _spinner_spinner__WEBPACK_IMPORTED_MODULE_0__["Spinner"]; });

/* harmony import */ var _pageTitle_pageTitle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pageTitle/pageTitle */ "./components/ui/pageTitle/pageTitle.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PageTitle", function() { return _pageTitle_pageTitle__WEBPACK_IMPORTED_MODULE_1__["PageTitle"]; });

/* harmony import */ var _lgBtn_lgBtn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lgBtn/lgBtn */ "./components/ui/lgBtn/lgBtn.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LgBtn", function() { return _lgBtn_lgBtn__WEBPACK_IMPORTED_MODULE_2__["LgBtn"]; });

/* harmony import */ var _datePicker_datePicker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./datePicker/datePicker */ "./components/ui/datePicker/datePicker.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DatePicker", function() { return _datePicker_datePicker__WEBPACK_IMPORTED_MODULE_3__["DatePicker"]; });

/* harmony import */ var _modal_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modal/modal */ "./components/ui/modal/modal.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SimpleModal", function() { return _modal_modal__WEBPACK_IMPORTED_MODULE_4__["SimpleModal"]; });

/* harmony import */ var _ratingStar_ratingStar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ratingStar/ratingStar */ "./components/ui/ratingStar/ratingStar.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CustomizedRatings", function() { return _ratingStar_ratingStar__WEBPACK_IMPORTED_MODULE_5__["CustomizedRatings"]; });

/* harmony import */ var _dropDown_dropDown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dropDown/dropDown */ "./components/ui/dropDown/dropDown.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CustomizedSelects", function() { return _dropDown_dropDown__WEBPACK_IMPORTED_MODULE_6__["CustomizedSelects"]; });









/***/ }),

/***/ "./components/ui/lgBtn/lgBtn.js":
/*!**************************************!*\
  !*** ./components/ui/lgBtn/lgBtn.js ***!
  \**************************************/
/*! exports provided: LgBtn */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LgBtn", function() { return LgBtn; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/styles */ "@material-ui/styles");
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ */ "./components/ui/index.js");

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\lgBtn\\lgBtn.js";




const useStyles = Object(_material_ui_styles__WEBPACK_IMPORTED_MODULE_2__["makeStyles"])(theme => ({
  root: {
    marginTop: "1rem"
  },
  btn: {
    width: "100%",
    padding: "0.5rem 0",
    textTransform: "capitalize",
    background: "#f6f6f6",
    borderTopLeftRadius: "0",
    borderBottomLeftRadius: "0",
    color: "#000",
    "&:hover": {
      background: "#f6f6f6"
    }
  },
  active: {
    width: "100%",
    color: "#fff",
    background: theme.palette.primary.main,
    width: "100%",
    padding: "0.5rem 0",
    textTransform: "capitalize",
    borderTopLeftRadius: "0",
    borderBottomLeftRadius: "0",
    "&:hover": {
      background: "var(--primary-color)"
    }
  }
}));
const LgBtn = ({
  setBookingType,
  bookingType,
  calender,
  management
}) => {
  const classes = useStyles();
  let local = "bookingLocals";
  let experience = "bookingExperiences";

  if (management) {
    local = "locals";
    experience = "experiences";
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
    container: true,
    item: true,
    xs: 6,
    className: classes.root,
    alignContent: "center",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
      item: true,
      xs: 2,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        onClick: () => setBookingType(local),
        className: bookingType === local ? classes.active : classes.btn,
        children: "Locals"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 57,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
      item: true,
      xs: 2,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        onClick: () => setBookingType(experience),
        className: bookingType === experience ? classes.active : classes.btn,
        children: "Experince"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
      item: true,
      xs: 2,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          margin: "0.5rem auto"
        },
        children: calender && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(___WEBPACK_IMPORTED_MODULE_4__["DatePicker"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 24
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 56,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/ui/modal/modal.js":
/*!**************************************!*\
  !*** ./components/ui/modal/modal.js ***!
  \**************************************/
/*! exports provided: SimpleModal */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimpleModal", function() { return SimpleModal; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Button */ "@material-ui/core/Button");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Dialog */ "@material-ui/core/Dialog");
/* harmony import */ var _material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/DialogActions */ "@material-ui/core/DialogActions");
/* harmony import */ var _material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/DialogContent */ "@material-ui/core/DialogContent");
/* harmony import */ var _material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/DialogContentText */ "@material-ui/core/DialogContentText");
/* harmony import */ var _material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Slide */ "@material-ui/core/Slide");
/* harmony import */ var _material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\modal\\modal.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






 // import DialogTitle from "@material-ui/core/DialogTitle";


const Transition = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.forwardRef(function Transition(props, ref) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Slide__WEBPACK_IMPORTED_MODULE_7___default.a, _objectSpread({
    direction: "up",
    ref: ref
  }, props), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 10
  }, this);
});
function SimpleModal({
  open,
  handleClose,
  statusHandler
}) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Dialog__WEBPACK_IMPORTED_MODULE_3___default.a, {
      open: open,
      TransitionComponent: Transition,
      keepMounted: true,
      onClose: handleClose,
      "aria-labelledby": "alert-dialog-slide-title",
      "aria-describedby": "alert-dialog-slide-description",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_DialogContent__WEBPACK_IMPORTED_MODULE_5___default.a, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_DialogContentText__WEBPACK_IMPORTED_MODULE_6___default.a, {
          id: "alert-dialog-slide-description",
          children: "Are You Sure..?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_DialogActions__WEBPACK_IMPORTED_MODULE_4___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2___default.a, {
          onClick: handleClose,
          color: "primary",
          children: "Disagree"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_2___default.a, {
          onClick: statusHandler,
          color: "primary",
          children: "Agree"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/pageTitle/pageTitle.js":
/*!**********************************************!*\
  !*** ./components/ui/pageTitle/pageTitle.js ***!
  \**********************************************/
/*! exports provided: PageTitle */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageTitle", function() { return PageTitle; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/styles */ "@material-ui/styles");
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_3__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\pageTitle\\pageTitle.js";



const useStyles = Object(_material_ui_styles__WEBPACK_IMPORTED_MODULE_3__["makeStyles"])(theme => ({
  title: {
    textTransform: "uppercase"
  }
}));
const PageTitle = ({
  text
}) => {
  const classes = useStyles();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
      container: true,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Grid"], {
        item: true,
        xs: 12,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
          className: classes.title,
          variant: "h5",
          children: text
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./components/ui/ratingStar/ratingStar.js":
/*!************************************************!*\
  !*** ./components/ui/ratingStar/ratingStar.js ***!
  \************************************************/
/*! exports provided: CustomizedRatings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomizedRatings", function() { return CustomizedRatings; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/lab/Rating */ "@material-ui/lab/Rating");
/* harmony import */ var _material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/StarBorder */ "@material-ui/icons/StarBorder");
/* harmony import */ var _material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Box */ "@material-ui/core/Box");
/* harmony import */ var _material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\ratingStar\\ratingStar.js";




function CustomizedRatings({
  rating,
  size,
  max = 1,
  revRat
}) {
  let value = null;

  if (rating === 5 && !revRat) {
    value = 1;
  } else if (rating < 5 && !revRat) {
    value = 0.5;
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Box__WEBPACK_IMPORTED_MODULE_4___default.a, {
      component: "fieldset",
      mb: 3,
      borderColor: "transparent",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_lab_Rating__WEBPACK_IMPORTED_MODULE_2___default.a, {
        style: {
          color: "var(--primary-color)"
        },
        name: "customized-empty",
        readOnly: true,
        max: max,
        precision: 0.5,
        value: value ? value : revRat,
        size: size,
        emptyIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_3___default.a, {
          fontSize: "inherit"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 22
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./components/ui/spinner/spinner.js":
/*!******************************************!*\
  !*** ./components/ui/spinner/spinner.js ***!
  \******************************************/
/*! exports provided: Spinner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Spinner", function() { return Spinner; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/CircularProgress */ "@material-ui/core/CircularProgress");
/* harmony import */ var _material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/icons */ "@material-ui/icons");
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "E:\\Next.js\\bookings\\components\\ui\\spinner\\spinner.js";




const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_2__["makeStyles"])(theme => ({
  root: {
    display: "flex",
    "& > * + *": {
      marginLeft: theme.spacing(2)
    },
    width: "100%",
    height: "100vh",
    justifyContent: "center",
    alignItems: "center"
  }
}));
function Spinner() {
  const classes = useStyles();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: classes.root,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_3___default.a, {
      color: "secondary"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./context/bookingFetch.js":
/*!*********************************!*\
  !*** ./context/bookingFetch.js ***!
  \*********************************/
/*! exports provided: BookingContext, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingContext", function() { return BookingContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return BookingFetch; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "E:\\Next.js\\bookings\\context\\bookingFetch.js";

const BookingContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])();
function BookingFetch({
  children
}) {
  const {
    0: bookings,
    1: setBookings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: completed,
    1: setCompleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: pending,
    1: setPending
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: noShow,
    1: setNoShow
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: deleted,
    1: setDeleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: bookingType,
    1: setBookingType
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("bookingLocals");
  const {
    0: bookingData,
    1: setBookingData
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: bookingHeader,
    1: setBookingHeader
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: date,
    1: setDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(new Date());
  const {
    0: month,
    1: setMonth
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");

  const filter = (array, status, setFunc) => {
    const FilterArray = array.filter(el => el.status === status);
    setFunc(FilterArray);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    let bookingsKeys = [];
    let bookingsData = [];

    const fetcher = async () => {
      try {
        const newDate = new Date(date);
        const proxyUrl = "https://cors-anywhere.herokuapp.com/";
        const url = `http://nappetito-stage.herokuapp.com/api/${bookingType}/5ec503cc434dff29cf56633b/${newDate.getFullYear()}-${newDate.getMonth() + 1}-${newDate.getDate()}/all`;
        const res = await fetch(proxyUrl + url);
        const data = await res.json();
        setBookings(data);
        Object.values(data).forEach((el, i) => {
          if (i === 0) {
            Object.keys(el).forEach(key => {
              bookingsKeys.push({
                label: key,
                key: key
              });
            });
          }

          bookingsData.push(el);
        });
        setBookingData(bookingsData);
        setBookingHeader(bookingsKeys);
        filter(data, "deleted", setDeleted);
        filter(data, "pending", setPending);
        filter(data, "no-show", setNoShow);
        filter(data, "completed", setCompleted);
      } catch (error) {
        console.log(error);
      }
    };

    fetcher();
  }, [date, bookingType]);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(BookingContext.Provider, {
    value: {
      bookings,
      date,
      setDate,
      deleted,
      pending,
      noShow,
      completed,
      bookingData,
      bookingHeader,
      month,
      setMonth,
      setBookingType,
      bookingType
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 58,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./context/dashboardFetch.js":
/*!***********************************!*\
  !*** ./context/dashboardFetch.js ***!
  \***********************************/
/*! exports provided: DashBordContext, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashBordContext", function() { return DashBordContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return DashboardFetch; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "E:\\Next.js\\bookings\\context\\dashboardFetch.js";

const DashBordContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])();

const fetcher = (endpoint, startDate, endDate, setData) => {
  fetch(`https://cors-anywhere.herokuapp.com/http://nappetito-stage.herokuapp.com/api/${endpoint}`, {
    method: "POST",
    body: JSON.stringify({
      startDate: startDate,
      endDate: endDate,
      userId: "5ec503cc434dff29cf56633b"
    }),
    headers: {
      "Content-Type": "application/json"
    }
  }).then(res => res.json()).then(result => {
    setData(result);
  }).catch(err => console.log("Error = ", err));
};

const fetcherReviews = async (url, setData) => {
  try {
    const proxyUrl = "https://cors-anywhere.herokuapp.com/";
    const urll = url;
    const res = await fetch(proxyUrl + urll);
    const data = await res.json();
    setData(data);
  } catch (error) {
    console.log(error);
  }
};

function DashboardFetch({
  children
}) {
  const {
    0: startDate,
    1: setStartDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(new Date());
  const {
    0: endDate,
    1: setEndDate
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(new Date());
  const {
    0: reviews,
    1: setReviews
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: bookings,
    1: setBookings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: completed,
    1: setCompleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: deleted,
    1: setDeleted
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: noShow,
    1: setNoShow
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: expReviews,
    1: setExpReviews
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: expBookings,
    1: setExpBookings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: earnings,
    1: setEarnings
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    fetcherReviews(`http://nappetito-stage.herokuapp.com/api/reviewLocalTotalCount/5ec503cc434dff29cf56633b`, setReviews);
    fetcherReviews("http://nappetito-stage.herokuapp.com/api/reviewExperienceTotalCount/5fa3eb9f9412c3fe0513ddc6", setExpReviews);
    fetcher("bookingLocalsTotalCount", startDate, endDate, setBookings);
    fetcher("bookingLocalsCompletedCount", startDate, endDate, setCompleted);
    fetcher("bookingLocalsDeletedCount", startDate, endDate, setDeleted);
    fetcher("bookingLocalsNoShowCount", startDate, endDate, setNoShow);
    fetcher("bookingExperiencesTotalCount", startDate, endDate, setExpBookings);
    fetcher("bookingExperiencesTotalGain", startDate, endDate, setEarnings);
  }, [bookings, reviews, completed, deleted, noShow, startDate, endDate, expReviews, expBookings, earnings]);
  const local = [{
    src: "/images/stars.svg",
    txt: "Reviews",
    total: reviews
  }, {
    src: "/images/bookings.svg",
    txt: "Bookings Total",
    total: bookings
  }, {
    src: "/images/book-comp.svg",
    txt: "Bookings Completed",
    total: completed
  }, {
    src: "/images/book-del.svg",
    txt: "Bookings Deleted",
    total: deleted
  }, {
    src: "/images/book-noShow.svg",
    txt: "Bookings No-Show",
    total: noShow
  }];
  const experience = [{
    src: "/images/stars.svg",
    txt: "Reviews",
    total: expReviews
  }, {
    src: "/images/bookings.svg",
    txt: "Bookings Total",
    total: expBookings
  }, {
    src: "/images/earning.svg",
    txt: "Earnings",
    total: earnings
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(DashBordContext.Provider, {
    value: {
      setStartDate,
      setEndDate,
      local,
      experience
    },
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 113,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/ui */ "./components/ui/index.js");


var _jsxFileName = "E:\\Next.js\\bookings\\pages\\index.js";



function Home() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_2___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: "Create Next App"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_ui__WEBPACK_IMPORTED_MODULE_3__["PageTitle"], {
      text: "Calender"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/***/ }),

/***/ "@date-io/date-fns":
/*!************************************!*\
  !*** external "@date-io/date-fns" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@date-io/date-fns");

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/Box":
/*!****************************************!*\
  !*** external "@material-ui/core/Box" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Box");

/***/ }),

/***/ "@material-ui/core/Button":
/*!*******************************************!*\
  !*** external "@material-ui/core/Button" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "@material-ui/core/CircularProgress":
/*!*****************************************************!*\
  !*** external "@material-ui/core/CircularProgress" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CircularProgress");

/***/ }),

/***/ "@material-ui/core/Dialog":
/*!*******************************************!*\
  !*** external "@material-ui/core/Dialog" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Dialog");

/***/ }),

/***/ "@material-ui/core/DialogActions":
/*!**************************************************!*\
  !*** external "@material-ui/core/DialogActions" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogActions");

/***/ }),

/***/ "@material-ui/core/DialogContent":
/*!**************************************************!*\
  !*** external "@material-ui/core/DialogContent" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogContent");

/***/ }),

/***/ "@material-ui/core/DialogContentText":
/*!******************************************************!*\
  !*** external "@material-ui/core/DialogContentText" ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/DialogContentText");

/***/ }),

/***/ "@material-ui/core/FormControl":
/*!************************************************!*\
  !*** external "@material-ui/core/FormControl" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/FormControl");

/***/ }),

/***/ "@material-ui/core/Grid":
/*!*****************************************!*\
  !*** external "@material-ui/core/Grid" ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Grid");

/***/ }),

/***/ "@material-ui/core/InputBase":
/*!**********************************************!*\
  !*** external "@material-ui/core/InputBase" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/InputBase");

/***/ }),

/***/ "@material-ui/core/NativeSelect":
/*!*************************************************!*\
  !*** external "@material-ui/core/NativeSelect" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/NativeSelect");

/***/ }),

/***/ "@material-ui/core/Slide":
/*!******************************************!*\
  !*** external "@material-ui/core/Slide" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Slide");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "@material-ui/icons":
/*!*************************************!*\
  !*** external "@material-ui/icons" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ "@material-ui/icons/CalendarTodayOutlined":
/*!***********************************************************!*\
  !*** external "@material-ui/icons/CalendarTodayOutlined" ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/CalendarTodayOutlined");

/***/ }),

/***/ "@material-ui/icons/StarBorder":
/*!************************************************!*\
  !*** external "@material-ui/icons/StarBorder" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/StarBorder");

/***/ }),

/***/ "@material-ui/lab/Rating":
/*!******************************************!*\
  !*** external "@material-ui/lab/Rating" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/lab/Rating");

/***/ }),

/***/ "@material-ui/pickers":
/*!***************************************!*\
  !*** external "@material-ui/pickers" ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/pickers");

/***/ }),

/***/ "@material-ui/styles":
/*!**************************************!*\
  !*** external "@material-ui/styles" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/styles");

/***/ }),

/***/ "date-fns":
/*!***************************!*\
  !*** external "date-fns" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("date-fns");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9kYXRlUGlja2VyL2RhdGVQaWNrZXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9kcm9wRG93bi9kcm9wRG93bi5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL3VpL2luZGV4LmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvdWkvbGdCdG4vbGdCdG4uanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9tb2RhbC9tb2RhbC5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL3VpL3BhZ2VUaXRsZS9wYWdlVGl0bGUuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9yYXRpbmdTdGFyL3JhdGluZ1N0YXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy91aS9zcGlubmVyL3NwaW5uZXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29udGV4dC9ib29raW5nRmV0Y2guanMiLCJ3ZWJwYWNrOi8vLy4vY29udGV4dC9kYXNoYm9hcmRGZXRjaC5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAZGF0ZS1pby9kYXRlLWZuc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQm94XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQnV0dG9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQ2lyY3VsYXJQcm9ncmVzc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ0FjdGlvbnNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dDb250ZW50XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nQ29udGVudFRleHRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9Gb3JtQ29udHJvbFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0dyaWRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9JbnB1dEJhc2VcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9OYXRpdmVTZWxlY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9TbGlkZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL3N0eWxlc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9pY29uc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9pY29ucy9DYWxlbmRhclRvZGF5T3V0bGluZWRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvU3RhckJvcmRlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9sYWIvUmF0aW5nXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL3BpY2tlcnNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvc3R5bGVzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZGF0ZS1mbnNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sIm5hbWVzIjpbIkRhdGVQaWNrZXIiLCJ2YWx1ZSIsInVzZUNvbnRleHQiLCJCb29raW5nQ29udGV4dCIsImRhdGUiLCJzZXREYXRlIiwic2V0TW9udGgiLCJtb250aCIsIlJlYWN0IiwidXNlRWZmZWN0IiwiZGF0ZVRleHQiLCJtb250aF9uYW1lIiwiRGF0ZSIsImdldERhdGUiLCJjb25zb2xlIiwibG9nIiwiZHQiLCJtbGlzdCIsImdldE1vbnRoIiwiaGFuZGxlRGF0ZUNoYW5nZSIsImRhdCIsIkRhdGVGbnNVdGlscyIsIkJvb3RzdHJhcElucHV0Iiwid2l0aFN0eWxlcyIsInRoZW1lIiwiaW5wdXQiLCJtaW5XaWR0aCIsImJvcmRlclJhZGl1cyIsInBvc2l0aW9uIiwiYmFja2dyb3VuZENvbG9yIiwicGFsZXR0ZSIsInByaW1hcnkiLCJtYWluIiwiYm9yZGVyIiwiZm9udFNpemUiLCJwYWRkaW5nIiwiY29sb3IiLCJiYWNrZ3JvdW5kIiwiSW5wdXRCYXNlIiwib25TdGFydEVuZCIsInllYXIiLCJDdXN0b21pemVkU2VsZWN0cyIsInVzZVN0YXRlIiwic2V0U3RhcnREYXRlIiwic2V0RW5kRGF0ZSIsIkRhc2hCb3JkQ29udGV4dCIsImRhdGVIYW5kbGVyIiwiZXZlbnQiLCJuZXdEYXRlIiwidGFyZ2V0IiwiZ2V0RnVsbFllYXIiLCJ1c2VTdHlsZXMiLCJtYWtlU3R5bGVzIiwicm9vdCIsIm1hcmdpblRvcCIsImJ0biIsIndpZHRoIiwidGV4dFRyYW5zZm9ybSIsImJvcmRlclRvcExlZnRSYWRpdXMiLCJib3JkZXJCb3R0b21MZWZ0UmFkaXVzIiwiYWN0aXZlIiwiTGdCdG4iLCJzZXRCb29raW5nVHlwZSIsImJvb2tpbmdUeXBlIiwiY2FsZW5kZXIiLCJtYW5hZ2VtZW50IiwiY2xhc3NlcyIsImxvY2FsIiwiZXhwZXJpZW5jZSIsIm1hcmdpbiIsIlRyYW5zaXRpb24iLCJmb3J3YXJkUmVmIiwicHJvcHMiLCJyZWYiLCJTaW1wbGVNb2RhbCIsIm9wZW4iLCJoYW5kbGVDbG9zZSIsInN0YXR1c0hhbmRsZXIiLCJ0aXRsZSIsIlBhZ2VUaXRsZSIsInRleHQiLCJDdXN0b21pemVkUmF0aW5ncyIsInJhdGluZyIsInNpemUiLCJtYXgiLCJyZXZSYXQiLCJkaXNwbGF5IiwibWFyZ2luTGVmdCIsInNwYWNpbmciLCJoZWlnaHQiLCJqdXN0aWZ5Q29udGVudCIsImFsaWduSXRlbXMiLCJTcGlubmVyIiwiY3JlYXRlQ29udGV4dCIsIkJvb2tpbmdGZXRjaCIsImNoaWxkcmVuIiwiYm9va2luZ3MiLCJzZXRCb29raW5ncyIsImNvbXBsZXRlZCIsInNldENvbXBsZXRlZCIsInBlbmRpbmciLCJzZXRQZW5kaW5nIiwibm9TaG93Iiwic2V0Tm9TaG93IiwiZGVsZXRlZCIsInNldERlbGV0ZWQiLCJib29raW5nRGF0YSIsInNldEJvb2tpbmdEYXRhIiwiYm9va2luZ0hlYWRlciIsInNldEJvb2tpbmdIZWFkZXIiLCJmaWx0ZXIiLCJhcnJheSIsInN0YXR1cyIsInNldEZ1bmMiLCJGaWx0ZXJBcnJheSIsImVsIiwiYm9va2luZ3NLZXlzIiwiYm9va2luZ3NEYXRhIiwiZmV0Y2hlciIsInByb3h5VXJsIiwidXJsIiwicmVzIiwiZmV0Y2giLCJkYXRhIiwianNvbiIsIk9iamVjdCIsInZhbHVlcyIsImZvckVhY2giLCJpIiwia2V5cyIsImtleSIsInB1c2giLCJsYWJlbCIsImVycm9yIiwiZW5kcG9pbnQiLCJzdGFydERhdGUiLCJlbmREYXRlIiwic2V0RGF0YSIsIm1ldGhvZCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwidXNlcklkIiwiaGVhZGVycyIsInRoZW4iLCJyZXN1bHQiLCJjYXRjaCIsImVyciIsImZldGNoZXJSZXZpZXdzIiwidXJsbCIsIkRhc2hib2FyZEZldGNoIiwicmV2aWV3cyIsInNldFJldmlld3MiLCJleHBSZXZpZXdzIiwic2V0RXhwUmV2aWV3cyIsImV4cEJvb2tpbmdzIiwic2V0RXhwQm9va2luZ3MiLCJlYXJuaW5ncyIsInNldEVhcm5pbmdzIiwic3JjIiwidHh0IiwidG90YWwiLCJIb21lIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEZBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBRUE7QUFFTyxTQUFTQSxVQUFULEdBQXNCO0FBQzNCLFFBQU1DLEtBQUssR0FBR0Msd0RBQVUsQ0FBQ0Msb0VBQUQsQ0FBeEI7QUFDQSxRQUFNO0FBQUVDLFFBQUY7QUFBUUMsV0FBUjtBQUFpQkMsWUFBakI7QUFBMkJDO0FBQTNCLE1BQXFDTixLQUEzQztBQUVBTyw4Q0FBSyxDQUFDQyxTQUFOLENBQWdCLE1BQU07QUFDcEIsVUFBTUMsUUFBUSxHQUFHQyxVQUFVLENBQUMsSUFBSUMsSUFBSixFQUFELENBQVYsR0FBeUIsR0FBekIsR0FBK0IsSUFBSUEsSUFBSixHQUFXQyxPQUFYLEVBQWhEO0FBQ0FQLFlBQVEsQ0FBQ0ksUUFBRCxDQUFSO0FBQ0FJLFdBQU8sQ0FBQ0MsR0FBUixDQUFZUixLQUFaO0FBQ0QsR0FKRCxFQUlHLEVBSkg7O0FBTUEsUUFBTUksVUFBVSxHQUFJSyxFQUFELElBQVE7QUFDekIsVUFBTUMsS0FBSyxHQUFHLENBQ1osU0FEWSxFQUVaLFVBRlksRUFHWixPQUhZLEVBSVosT0FKWSxFQUtaLEtBTFksRUFNWixNQU5ZLEVBT1osTUFQWSxFQVFaLFFBUlksRUFTWixXQVRZLEVBVVosU0FWWSxFQVdaLFVBWFksRUFZWixVQVpZLENBQWQ7QUFjQSxXQUFPQSxLQUFLLENBQUNELEVBQUUsQ0FBQ0UsUUFBSCxFQUFELENBQVo7QUFDRCxHQWhCRDs7QUFrQkEsUUFBTUMsZ0JBQWdCLEdBQUlDLEdBQUQsSUFBUztBQUNoQ2YsV0FBTyxDQUFDZSxHQUFELENBQVA7QUFDQSxVQUFNVixRQUFRLEdBQUdDLFVBQVUsQ0FBQyxJQUFJQyxJQUFKLENBQVNRLEdBQVQsQ0FBRCxDQUFWLEdBQTRCLEdBQTVCLEdBQWtDQSxHQUFHLENBQUNQLE9BQUosRUFBbkQ7QUFDQVAsWUFBUSxDQUFDSSxRQUFELENBQVI7QUFDRCxHQUpEOztBQU1BLHNCQUNFLHFFQUFDLDRFQUFEO0FBQXlCLFNBQUssRUFBRVcsd0RBQWhDO0FBQUEsMkJBQ0UscUVBQUMsNkRBQUQ7QUFBTSxVQUFJLE1BQVY7QUFBVyxRQUFFLEVBQUUsQ0FBZjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxhQUFmO0FBQUEsK0JBQ0UscUVBQUMsdUVBQUQ7QUFDRSxzQkFBWSxlQUNWO0FBQ0UsaUJBQUssRUFBQyw0QkFEUjtBQUVFLGlCQUFLLEVBQUMsSUFGUjtBQUdFLGtCQUFNLEVBQUMsSUFIVDtBQUlFLG1CQUFPLEVBQUMsV0FKVjtBQUFBLG1DQU1FO0FBQ0UsZ0JBQUUsRUFBQyxhQURMO0FBRUUsMkJBQVUsYUFGWjtBQUdFLHVCQUFTLEVBQUMsNEJBSFo7QUFBQSxzQ0FLRTtBQUNFLGtCQUFFLEVBQUMsWUFETDtBQUVFLDZCQUFVLFlBRlo7QUFHRSxpQkFBQyxFQUFDLDBSQUhKO0FBSUUseUJBQVMsRUFBQyxzQkFKWjtBQUtFLG9CQUFJLEVBQUMsU0FMUDtBQU1FLHNCQUFNLEVBQUMsU0FOVDtBQU9FLGdDQUFhO0FBUGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFMRixlQWNFO0FBQ0Usa0JBQUUsRUFBQyxjQURMO0FBRUUsNkJBQVUsY0FGWjtBQUdFLGtCQUFFLEVBQUMsT0FITDtBQUlFLGtCQUFFLEVBQUMsT0FKTDtBQUtFLGtCQUFFLEVBQUMsT0FMTDtBQU1FLGtCQUFFLEVBQUMsT0FOTDtBQU9FLHlCQUFTLEVBQUMsMkJBUFo7QUFRRSxvQkFBSSxFQUFDO0FBUlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFkRixlQXdCRTtBQUNFLGtCQUFFLEVBQUMsY0FETDtBQUVFLDZCQUFVLGNBRlo7QUFHRSxrQkFBRSxFQUFDLE9BSEw7QUFJRSxrQkFBRSxFQUFDLE9BSkw7QUFLRSxrQkFBRSxFQUFDLE9BTEw7QUFNRSxrQkFBRSxFQUFDLE9BTkw7QUFPRSx5QkFBUyxFQUFDLDJCQVBaO0FBUUUsb0JBQUksRUFBQztBQVJQO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBeEJGLGVBa0NFO0FBQ0Usa0JBQUUsRUFBQyxjQURMO0FBRUUsNkJBQVUsY0FGWjtBQUdFLGtCQUFFLEVBQUMsT0FITDtBQUlFLGtCQUFFLEVBQUMsT0FKTDtBQUtFLGtCQUFFLEVBQUMsT0FMTDtBQU1FLGtCQUFFLEVBQUMsT0FOTDtBQU9FLHlCQUFTLEVBQUMsMkJBUFo7QUFRRSxvQkFBSSxFQUFDO0FBUlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFsQ0YsZUE0Q0U7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLE9BSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNUNGLGVBb0RFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxLQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXBERixlQTRERTtBQUNFLGtCQUFFLEVBQUMsZ0JBREw7QUFFRSw2QkFBVSxnQkFGWjtBQUdFLHFCQUFLLEVBQUMsT0FIUjtBQUlFLHNCQUFNLEVBQUMsT0FKVDtBQUtFLHlCQUFTLEVBQUMsNEJBTFo7QUFNRSxvQkFBSSxFQUFDO0FBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkE1REYsZUFvRUU7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLEtBSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBcEVGLGVBNEVFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxPQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQTVFRixlQW9GRTtBQUNFLGtCQUFFLEVBQUMsZ0JBREw7QUFFRSw2QkFBVSxnQkFGWjtBQUdFLHFCQUFLLEVBQUMsS0FIUjtBQUlFLHNCQUFNLEVBQUMsT0FKVDtBQUtFLHlCQUFTLEVBQUMsNEJBTFo7QUFNRSxvQkFBSSxFQUFDO0FBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFwRkYsZUE0RkU7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLE9BSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNUZGLGVBb0dFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxLQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXBHRixlQTRHRTtBQUNFLGtCQUFFLEVBQUMsZ0JBREw7QUFFRSw2QkFBVSxnQkFGWjtBQUdFLHFCQUFLLEVBQUMsT0FIUjtBQUlFLHNCQUFNLEVBQUMsT0FKVDtBQUtFLHlCQUFTLEVBQUMsNEJBTFo7QUFNRSxvQkFBSSxFQUFDO0FBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkE1R0YsZUFvSEU7QUFDRSxrQkFBRSxFQUFDLGdCQURMO0FBRUUsNkJBQVUsZ0JBRlo7QUFHRSxxQkFBSyxFQUFDLEtBSFI7QUFJRSxzQkFBTSxFQUFDLE9BSlQ7QUFLRSx5QkFBUyxFQUFDLDRCQUxaO0FBTUUsb0JBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBcEhGLGVBNEhFO0FBQ0Usa0JBQUUsRUFBQyxnQkFETDtBQUVFLDZCQUFVLGdCQUZaO0FBR0UscUJBQUssRUFBQyxPQUhSO0FBSUUsc0JBQU0sRUFBQyxPQUpUO0FBS0UseUJBQVMsRUFBQyw0QkFMWjtBQU1FLG9CQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQTVIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZKO0FBK0lFLGdCQUFNLEVBQUMsUUEvSVQ7QUFnSkUsZUFBSyxFQUFFakIsSUFoSlQ7QUFpSkUsa0JBQVEsRUFBRWUsZ0JBakpaO0FBa0pFLGdCQUFNLEVBQUMsYUFsSlQ7QUFtSkUsNkJBQW1CLEVBQUU7QUFDbkIsMEJBQWM7QUFESztBQW5KdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBK0pELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaE5EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLE1BQU1HLGNBQWMsR0FBR0MsMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQzVDQyxPQUFLLEVBQUU7QUFDTEMsWUFBUSxFQUFFLE1BREw7QUFFTEMsZ0JBQVksRUFBRSxDQUZUO0FBR0xDLFlBQVEsRUFBRSxVQUhMO0FBSUxDLG1CQUFlLEVBQUVMLEtBQUssQ0FBQ00sT0FBTixDQUFjQyxPQUFkLENBQXNCQyxJQUpsQztBQUtMQyxVQUFNLEVBQUUsTUFMSDtBQU1MQyxZQUFRLEVBQUUsRUFOTDtBQU9MQyxXQUFPLEVBQUUsb0JBUEo7QUFRTEMsU0FBSyxFQUFFLE1BUkY7QUFTTCxlQUFXO0FBQ1RDLGdCQUFVLEVBQUViLEtBQUssQ0FBQ00sT0FBTixDQUFjQyxPQUFkLENBQXNCQyxJQUR6QjtBQUVUTCxrQkFBWSxFQUFFO0FBRkw7QUFUTjtBQURxQyxDQUFaLENBQUQsQ0FBVixDQWVuQlcsa0VBZm1CLENBQXZCOztBQWlCQSxNQUFNQyxVQUFVLEdBQUcsQ0FBQ25DLElBQUQsRUFBT0csS0FBUCxFQUFjaUMsSUFBZCxLQUF1QjtBQUN4QyxTQUFRLEdBQUVBLElBQUssSUFBR2pDLEtBQU0sSUFBR0gsSUFBSyxFQUFoQztBQUNELENBRkQ7O0FBSU8sU0FBU3FDLGlCQUFULEdBQTZCO0FBQ2xDLFFBQU0sQ0FBQ3JDLElBQUQsRUFBT0MsT0FBUCxJQUFrQkcsNENBQUssQ0FBQ2tDLFFBQU4sQ0FBZSxPQUFmLENBQXhCO0FBRUEsUUFBTTtBQUFFQyxnQkFBRjtBQUFnQkM7QUFBaEIsTUFBK0IxQyx3REFBVSxDQUFDMkMsdUVBQUQsQ0FBL0M7QUFFQXBDLHlEQUFTLENBQUMsTUFBTTtBQUNkSyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaLEVBQXVCWCxJQUF2QjtBQUNELEdBRlEsRUFFTixDQUFDQSxJQUFELENBRk0sQ0FBVDs7QUFJQSxRQUFNMEMsV0FBVyxHQUFJQyxLQUFELElBQVc7QUFDN0IsVUFBTUMsT0FBTyxHQUFHLElBQUlwQyxJQUFKLEVBQWhCO0FBQ0EsVUFBTVgsS0FBSyxHQUFHOEMsS0FBSyxDQUFDRSxNQUFOLENBQWFoRCxLQUEzQjs7QUFDQSxZQUFRQSxLQUFSO0FBQ0UsV0FBSyxPQUFMO0FBQ0UwQyxvQkFBWSxDQUNWSixVQUFVLENBQ1JTLE9BQU8sQ0FBQ25DLE9BQVIsRUFEUSxFQUVSbUMsT0FBTyxDQUFDOUIsUUFBUixLQUFxQixDQUZiLEVBR1I4QixPQUFPLENBQUNFLFdBQVIsRUFIUSxDQURBLENBQVo7QUFPQU4sa0JBQVUsQ0FDUkwsVUFBVSxDQUNSUyxPQUFPLENBQUNuQyxPQUFSLEVBRFEsRUFFUm1DLE9BQU8sQ0FBQzlCLFFBQVIsS0FBcUIsQ0FGYixFQUdSOEIsT0FBTyxDQUFDRSxXQUFSLEVBSFEsQ0FERixDQUFWO0FBT0E7O0FBQ0YsV0FBSyxTQUFMO0FBQ0VQLG9CQUFZLENBQ1ZKLFVBQVUsQ0FBQyxJQUFELEVBQU9TLE9BQU8sQ0FBQzlCLFFBQVIsS0FBcUIsQ0FBNUIsRUFBK0I4QixPQUFPLENBQUNFLFdBQVIsRUFBL0IsQ0FEQSxDQUFaO0FBR0FOLGtCQUFVLENBQ1JMLFVBQVUsQ0FBQyxJQUFELEVBQU9TLE9BQU8sQ0FBQzlCLFFBQVIsS0FBcUIsQ0FBNUIsRUFBK0I4QixPQUFPLENBQUNFLFdBQVIsRUFBL0IsQ0FERixDQUFWO0FBR0E7O0FBQ0YsV0FBSyxPQUFMO0FBQ0VQLG9CQUFZLENBQ1ZKLFVBQVUsQ0FBQyxJQUFELEVBQU9TLE9BQU8sQ0FBQzlCLFFBQVIsS0FBcUIsQ0FBNUIsRUFBK0I4QixPQUFPLENBQUNFLFdBQVIsRUFBL0IsQ0FEQSxDQUFaO0FBR0FOLGtCQUFVLENBQ1JMLFVBQVUsQ0FBQyxJQUFELEVBQU9TLE9BQU8sQ0FBQzlCLFFBQVIsS0FBcUIsQ0FBNUIsRUFBK0I4QixPQUFPLENBQUNFLFdBQVIsRUFBL0IsQ0FERixDQUFWO0FBR0E7O0FBQ0YsV0FBSyxLQUFMO0FBQ0VQLG9CQUFZLENBQ1ZKLFVBQVUsQ0FBQyxJQUFELEVBQU9TLE9BQU8sQ0FBQzlCLFFBQVIsS0FBcUIsQ0FBNUIsRUFBK0I4QixPQUFPLENBQUNFLFdBQVIsRUFBL0IsQ0FEQSxDQUFaO0FBR0FOLGtCQUFVLENBQ1JMLFVBQVUsQ0FBQyxJQUFELEVBQU9TLE9BQU8sQ0FBQzlCLFFBQVIsS0FBcUIsQ0FBNUIsRUFBK0I4QixPQUFPLENBQUNFLFdBQVIsRUFBL0IsQ0FERixDQUFWO0FBR0E7O0FBQ0YsV0FBSyxNQUFMO0FBQ0VQLG9CQUFZLENBQUNKLFVBQVUsQ0FBQyxJQUFELEVBQU8sSUFBUCxFQUFhUyxPQUFPLENBQUNFLFdBQVIsS0FBd0IsQ0FBckMsQ0FBWCxDQUFaO0FBQ0FOLGtCQUFVLENBQUNMLFVBQVUsQ0FBQyxJQUFELEVBQU8sSUFBUCxFQUFhUyxPQUFPLENBQUNFLFdBQVIsS0FBd0IsQ0FBckMsQ0FBWCxDQUFWO0FBQ0E7O0FBQ0Y7QUFDRTtBQTlDSjs7QUFnREE3QyxXQUFPLENBQUMwQyxLQUFLLENBQUNFLE1BQU4sQ0FBYWhELEtBQWQsQ0FBUDtBQUNELEdBcEREOztBQXNEQSxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLG9FQUFEO0FBQUEsNkJBQ0UscUVBQUMscUVBQUQ7QUFDRSxVQUFFLEVBQUMsK0JBREw7QUFFRSxhQUFLLEVBQUVHLElBRlQ7QUFHRSxnQkFBUSxFQUFFMEMsV0FIWjtBQUlFLGFBQUssZUFBRSxxRUFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSlQ7QUFBQSxnQ0FNRTtBQUFRLGVBQUssRUFBRTtBQUFFVixpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsT0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTkYsZUFTRTtBQUFRLGVBQUssRUFBRTtBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsU0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVEYsZUFZRTtBQUFRLGVBQUssRUFBRTtBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsT0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWkYsZUFlRTtBQUFRLGVBQUssRUFBRTtBQUFFQSxpQkFBSyxFQUFFO0FBQVQsV0FBZjtBQUFrQyxlQUFLLEVBQUUsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZkYsZUFrQkU7QUFBUSxlQUFLLEVBQUU7QUFBRUEsaUJBQUssRUFBRTtBQUFULFdBQWY7QUFBa0MsZUFBSyxFQUFFLE1BQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBNEJELEM7Ozs7Ozs7Ozs7OztBQ3hIRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMQTtBQUVBO0FBQ0E7QUFFQTtBQUVBLE1BQU1lLFNBQVMsR0FBR0Msc0VBQVUsQ0FBRTVCLEtBQUQsS0FBWTtBQUN2QzZCLE1BQUksRUFBRTtBQUNKQyxhQUFTLEVBQUU7QUFEUCxHQURpQztBQUl2Q0MsS0FBRyxFQUFFO0FBQ0hDLFNBQUssRUFBRSxNQURKO0FBRUhyQixXQUFPLEVBQUUsVUFGTjtBQUdIc0IsaUJBQWEsRUFBRSxZQUhaO0FBSUhwQixjQUFVLEVBQUUsU0FKVDtBQUtIcUIsdUJBQW1CLEVBQUUsR0FMbEI7QUFNSEMsMEJBQXNCLEVBQUUsR0FOckI7QUFPSHZCLFNBQUssRUFBRSxNQVBKO0FBUUgsZUFBVztBQUNUQyxnQkFBVSxFQUFFO0FBREg7QUFSUixHQUprQztBQWdCdkN1QixRQUFNLEVBQUU7QUFDTkosU0FBSyxFQUFFLE1BREQ7QUFFTnBCLFNBQUssRUFBRSxNQUZEO0FBR05DLGNBQVUsRUFBRWIsS0FBSyxDQUFDTSxPQUFOLENBQWNDLE9BQWQsQ0FBc0JDLElBSDVCO0FBSU53QixTQUFLLEVBQUUsTUFKRDtBQUtOckIsV0FBTyxFQUFFLFVBTEg7QUFNTnNCLGlCQUFhLEVBQUUsWUFOVDtBQU9OQyx1QkFBbUIsRUFBRSxHQVBmO0FBUU5DLDBCQUFzQixFQUFFLEdBUmxCO0FBU04sZUFBVztBQUNUdEIsZ0JBQVUsRUFBRTtBQURIO0FBVEw7QUFoQitCLENBQVosQ0FBRCxDQUE1QjtBQStCTyxNQUFNd0IsS0FBSyxHQUFHLENBQUM7QUFDcEJDLGdCQURvQjtBQUVwQkMsYUFGb0I7QUFHcEJDLFVBSG9CO0FBSXBCQztBQUpvQixDQUFELEtBS2Y7QUFDSixRQUFNQyxPQUFPLEdBQUdmLFNBQVMsRUFBekI7QUFFQSxNQUFJZ0IsS0FBSyxHQUFHLGVBQVo7QUFDQSxNQUFJQyxVQUFVLEdBQUcsb0JBQWpCOztBQUVBLE1BQUlILFVBQUosRUFBZ0I7QUFDZEUsU0FBSyxHQUFHLFFBQVI7QUFDQUMsY0FBVSxHQUFHLGFBQWI7QUFDRDs7QUFFRCxzQkFDRSxxRUFBQyxzREFBRDtBQUFNLGFBQVMsTUFBZjtBQUFnQixRQUFJLE1BQXBCO0FBQXFCLE1BQUUsRUFBRSxDQUF6QjtBQUE0QixhQUFTLEVBQUVGLE9BQU8sQ0FBQ2IsSUFBL0M7QUFBcUQsZ0JBQVksRUFBQyxRQUFsRTtBQUFBLDRCQUNFLHFFQUFDLHNEQUFEO0FBQU0sVUFBSSxNQUFWO0FBQVcsUUFBRSxFQUFFLENBQWY7QUFBQSw2QkFDRSxxRUFBQyx3REFBRDtBQUNFLGVBQU8sRUFBRSxNQUFNUyxjQUFjLENBQUNLLEtBQUQsQ0FEL0I7QUFFRSxpQkFBUyxFQUFFSixXQUFXLEtBQUtJLEtBQWhCLEdBQXdCRCxPQUFPLENBQUNOLE1BQWhDLEdBQXlDTSxPQUFPLENBQUNYLEdBRjlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQVNFLHFFQUFDLHNEQUFEO0FBQU0sVUFBSSxNQUFWO0FBQVcsUUFBRSxFQUFFLENBQWY7QUFBQSw2QkFDRSxxRUFBQyx3REFBRDtBQUNFLGVBQU8sRUFBRSxNQUFNTyxjQUFjLENBQUNNLFVBQUQsQ0FEL0I7QUFFRSxpQkFBUyxFQUFFTCxXQUFXLEtBQUtLLFVBQWhCLEdBQTZCRixPQUFPLENBQUNOLE1BQXJDLEdBQThDTSxPQUFPLENBQUNYLEdBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURixlQWlCRSxxRUFBQyxzREFBRDtBQUFNLFVBQUksTUFBVjtBQUFXLFFBQUUsRUFBRSxDQUFmO0FBQUEsNkJBQ0U7QUFDRSxhQUFLLEVBQUU7QUFDTGMsZ0JBQU0sRUFBRTtBQURILFNBRFQ7QUFBQSxrQkFLR0wsUUFBUSxpQkFBSSxxRUFBQyw0Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBNkJELENBN0NNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0NBRUE7O0FBQ0E7QUFFQSxNQUFNTSxVQUFVLGdCQUFHOUQsNENBQUssQ0FBQytELFVBQU4sQ0FBaUIsU0FBU0QsVUFBVCxDQUFvQkUsS0FBcEIsRUFBMkJDLEdBQTNCLEVBQWdDO0FBQ2xFLHNCQUFPLHFFQUFDLDhEQUFEO0FBQU8sYUFBUyxFQUFDLElBQWpCO0FBQXNCLE9BQUcsRUFBRUE7QUFBM0IsS0FBb0NELEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNELENBRmtCLENBQW5CO0FBSU8sU0FBU0UsV0FBVCxDQUFxQjtBQUFFQyxNQUFGO0FBQVFDLGFBQVI7QUFBcUJDO0FBQXJCLENBQXJCLEVBQTJEO0FBQ2hFLHNCQUNFO0FBQUEsMkJBQ0UscUVBQUMsK0RBQUQ7QUFDRSxVQUFJLEVBQUVGLElBRFI7QUFFRSx5QkFBbUIsRUFBRUwsVUFGdkI7QUFHRSxpQkFBVyxNQUhiO0FBSUUsYUFBTyxFQUFFTSxXQUpYO0FBS0UseUJBQWdCLDBCQUxsQjtBQU1FLDBCQUFpQixnQ0FObkI7QUFBQSw4QkFRRSxxRUFBQyxzRUFBRDtBQUFBLCtCQUNFLHFFQUFDLDBFQUFEO0FBQW1CLFlBQUUsRUFBQyxnQ0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUkYsZUFhRSxxRUFBQyxzRUFBRDtBQUFBLGdDQUNFLHFFQUFDLCtEQUFEO0FBQVEsaUJBQU8sRUFBRUEsV0FBakI7QUFBOEIsZUFBSyxFQUFDLFNBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBSUUscUVBQUMsK0RBQUQ7QUFBUSxpQkFBTyxFQUFFQyxhQUFqQjtBQUFnQyxlQUFLLEVBQUMsU0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBMEJELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hDRDtBQUVBO0FBQ0E7QUFFQSxNQUFNMUIsU0FBUyxHQUFHQyxzRUFBVSxDQUFFNUIsS0FBRCxLQUFZO0FBQ3ZDc0QsT0FBSyxFQUFFO0FBQ0xyQixpQkFBYSxFQUFFO0FBRFY7QUFEZ0MsQ0FBWixDQUFELENBQTVCO0FBTU8sTUFBTXNCLFNBQVMsR0FBRyxDQUFDO0FBQUVDO0FBQUYsQ0FBRCxLQUFjO0FBQ3JDLFFBQU1kLE9BQU8sR0FBR2YsU0FBUyxFQUF6QjtBQUNBLHNCQUNFO0FBQUEsMkJBQ0UscUVBQUMsc0RBQUQ7QUFBTSxlQUFTLE1BQWY7QUFBQSw2QkFDRSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQUEsK0JBQ0UscUVBQUMsNERBQUQ7QUFBWSxtQkFBUyxFQUFFZSxPQUFPLENBQUNZLEtBQS9CO0FBQXNDLGlCQUFPLEVBQUMsSUFBOUM7QUFBQSxvQkFDR0U7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFXRCxDQWJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWFA7QUFDQTtBQUNBO0FBQ0E7QUFFTyxTQUFTQyxpQkFBVCxDQUEyQjtBQUFFQyxRQUFGO0FBQVVDLE1BQVY7QUFBZ0JDLEtBQUcsR0FBRyxDQUF0QjtBQUF5QkM7QUFBekIsQ0FBM0IsRUFBOEQ7QUFDbkUsTUFBSXBGLEtBQUssR0FBRyxJQUFaOztBQUNBLE1BQUlpRixNQUFNLEtBQUssQ0FBWCxJQUFnQixDQUFDRyxNQUFyQixFQUE2QjtBQUMzQnBGLFNBQUssR0FBRyxDQUFSO0FBQ0QsR0FGRCxNQUVPLElBQUlpRixNQUFNLEdBQUcsQ0FBVCxJQUFjLENBQUNHLE1BQW5CLEVBQTJCO0FBQ2hDcEYsU0FBSyxHQUFHLEdBQVI7QUFDRDs7QUFDRCxzQkFDRTtBQUFBLDJCQUNFLHFFQUFDLDREQUFEO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBMEIsUUFBRSxFQUFFLENBQTlCO0FBQWlDLGlCQUFXLEVBQUMsYUFBN0M7QUFBQSw2QkFDRSxxRUFBQyw4REFBRDtBQUNFLGFBQUssRUFBRTtBQUFFbUMsZUFBSyxFQUFFO0FBQVQsU0FEVDtBQUVFLFlBQUksRUFBQyxrQkFGUDtBQUdFLGdCQUFRLE1BSFY7QUFJRSxXQUFHLEVBQUVnRCxHQUpQO0FBS0UsaUJBQVMsRUFBRSxHQUxiO0FBTUUsYUFBSyxFQUFFbkYsS0FBSyxHQUFHQSxLQUFILEdBQVdvRixNQU56QjtBQU9FLFlBQUksRUFBRUYsSUFQUjtBQVFFLGlCQUFTLGVBQUUscUVBQUMsb0VBQUQ7QUFBZ0Isa0JBQVEsRUFBQztBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFnQkQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1QkQ7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNaEMsU0FBUyxHQUFHQywyRUFBVSxDQUFFNUIsS0FBRCxLQUFZO0FBQ3ZDNkIsTUFBSSxFQUFFO0FBQ0ppQyxXQUFPLEVBQUUsTUFETDtBQUVKLGlCQUFhO0FBQ1hDLGdCQUFVLEVBQUUvRCxLQUFLLENBQUNnRSxPQUFOLENBQWMsQ0FBZDtBQURELEtBRlQ7QUFLSmhDLFNBQUssRUFBRSxNQUxIO0FBTUppQyxVQUFNLEVBQUUsT0FOSjtBQU9KQyxrQkFBYyxFQUFFLFFBUFo7QUFRSkMsY0FBVSxFQUFFO0FBUlI7QUFEaUMsQ0FBWixDQUFELENBQTVCO0FBYU8sU0FBU0MsT0FBVCxHQUFtQjtBQUN4QixRQUFNMUIsT0FBTyxHQUFHZixTQUFTLEVBQXpCO0FBRUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUVlLE9BQU8sQ0FBQ2IsSUFBeEI7QUFBQSwyQkFDRSxxRUFBQyx5RUFBRDtBQUFrQixXQUFLLEVBQUM7QUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQUtELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCRDtBQUVPLE1BQU1sRCxjQUFjLGdCQUFHMEYsMkRBQWEsRUFBcEM7QUFFUSxTQUFTQyxZQUFULENBQXNCO0FBQUVDO0FBQUYsQ0FBdEIsRUFBb0M7QUFDakQsUUFBTTtBQUFBLE9BQUNDLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCdkQsc0RBQVEsRUFBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3dELFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCekQsc0RBQVEsRUFBMUM7QUFDQSxRQUFNO0FBQUEsT0FBQzBELE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCM0Qsc0RBQVEsRUFBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQzRELE1BQUQ7QUFBQSxPQUFTQztBQUFULE1BQXNCN0Qsc0RBQVEsRUFBcEM7QUFDQSxRQUFNO0FBQUEsT0FBQzhELE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCL0Qsc0RBQVEsRUFBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3FCLFdBQUQ7QUFBQSxPQUFjRDtBQUFkLE1BQWdDcEIsc0RBQVEsQ0FBQyxlQUFELENBQTlDO0FBRUEsUUFBTTtBQUFBLE9BQUNnRSxXQUFEO0FBQUEsT0FBY0M7QUFBZCxNQUFnQ2pFLHNEQUFRLEVBQTlDO0FBQ0EsUUFBTTtBQUFBLE9BQUNrRSxhQUFEO0FBQUEsT0FBZ0JDO0FBQWhCLE1BQW9DbkUsc0RBQVEsRUFBbEQ7QUFFQSxRQUFNO0FBQUEsT0FBQ3RDLElBQUQ7QUFBQSxPQUFPQztBQUFQLE1BQWtCcUMsc0RBQVEsQ0FBQyxJQUFJOUIsSUFBSixFQUFELENBQWhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNMLEtBQUQ7QUFBQSxPQUFRRDtBQUFSLE1BQW9Cb0Msc0RBQVEsQ0FBQyxFQUFELENBQWxDOztBQUVBLFFBQU1vRSxNQUFNLEdBQUcsQ0FBQ0MsS0FBRCxFQUFRQyxNQUFSLEVBQWdCQyxPQUFoQixLQUE0QjtBQUN6QyxVQUFNQyxXQUFXLEdBQUdILEtBQUssQ0FBQ0QsTUFBTixDQUFjSyxFQUFELElBQVFBLEVBQUUsQ0FBQ0gsTUFBSCxLQUFjQSxNQUFuQyxDQUFwQjtBQUNBQyxXQUFPLENBQUNDLFdBQUQsQ0FBUDtBQUNELEdBSEQ7O0FBS0F6Ryx5REFBUyxDQUFDLE1BQU07QUFDZCxRQUFJMkcsWUFBWSxHQUFHLEVBQW5CO0FBQ0EsUUFBSUMsWUFBWSxHQUFHLEVBQW5COztBQUNBLFVBQU1DLE9BQU8sR0FBRyxZQUFZO0FBQzFCLFVBQUk7QUFDRixjQUFNdEUsT0FBTyxHQUFHLElBQUlwQyxJQUFKLENBQVNSLElBQVQsQ0FBaEI7QUFDQSxjQUFNbUgsUUFBUSxHQUFHLHNDQUFqQjtBQUNBLGNBQU1DLEdBQUcsR0FBSSw0Q0FBMkN6RCxXQUFZLDZCQUE0QmYsT0FBTyxDQUFDRSxXQUFSLEVBQXNCLElBQ3BIRixPQUFPLENBQUM5QixRQUFSLEtBQXFCLENBQ3RCLElBQUc4QixPQUFPLENBQUNuQyxPQUFSLEVBQWtCLE1BRnRCO0FBR0EsY0FBTTRHLEdBQUcsR0FBRyxNQUFNQyxLQUFLLENBQUNILFFBQVEsR0FBR0MsR0FBWixDQUF2QjtBQUNBLGNBQU1HLElBQUksR0FBRyxNQUFNRixHQUFHLENBQUNHLElBQUosRUFBbkI7QUFDQTNCLG1CQUFXLENBQUMwQixJQUFELENBQVg7QUFDQUUsY0FBTSxDQUFDQyxNQUFQLENBQWNILElBQWQsRUFBb0JJLE9BQXBCLENBQTRCLENBQUNaLEVBQUQsRUFBS2EsQ0FBTCxLQUFXO0FBQ3JDLGNBQUlBLENBQUMsS0FBSyxDQUFWLEVBQWE7QUFDWEgsa0JBQU0sQ0FBQ0ksSUFBUCxDQUFZZCxFQUFaLEVBQWdCWSxPQUFoQixDQUF5QkcsR0FBRCxJQUFTO0FBQy9CZCwwQkFBWSxDQUFDZSxJQUFiLENBQWtCO0FBQUVDLHFCQUFLLEVBQUVGLEdBQVQ7QUFBY0EsbUJBQUcsRUFBRUE7QUFBbkIsZUFBbEI7QUFDRCxhQUZEO0FBR0Q7O0FBQ0RiLHNCQUFZLENBQUNjLElBQWIsQ0FBa0JoQixFQUFsQjtBQUNELFNBUEQ7QUFRQVIsc0JBQWMsQ0FBQ1UsWUFBRCxDQUFkO0FBQ0FSLHdCQUFnQixDQUFDTyxZQUFELENBQWhCO0FBQ0FOLGNBQU0sQ0FBQ2EsSUFBRCxFQUFPLFNBQVAsRUFBa0JsQixVQUFsQixDQUFOO0FBQ0FLLGNBQU0sQ0FBQ2EsSUFBRCxFQUFPLFNBQVAsRUFBa0J0QixVQUFsQixDQUFOO0FBQ0FTLGNBQU0sQ0FBQ2EsSUFBRCxFQUFPLFNBQVAsRUFBa0JwQixTQUFsQixDQUFOO0FBQ0FPLGNBQU0sQ0FBQ2EsSUFBRCxFQUFPLFdBQVAsRUFBb0J4QixZQUFwQixDQUFOO0FBQ0QsT0F2QkQsQ0F1QkUsT0FBT2tDLEtBQVAsRUFBYztBQUNkdkgsZUFBTyxDQUFDQyxHQUFSLENBQVlzSCxLQUFaO0FBQ0Q7QUFDRixLQTNCRDs7QUE0QkFmLFdBQU87QUFDUixHQWhDUSxFQWdDTixDQUFDbEgsSUFBRCxFQUFPMkQsV0FBUCxDQWhDTSxDQUFUO0FBaUNBLHNCQUNFLHFFQUFDLGNBQUQsQ0FBZ0IsUUFBaEI7QUFDRSxTQUFLLEVBQUU7QUFDTGlDLGNBREs7QUFFTDVGLFVBRks7QUFHTEMsYUFISztBQUlMbUcsYUFKSztBQUtMSixhQUxLO0FBTUxFLFlBTks7QUFPTEosZUFQSztBQVFMUSxpQkFSSztBQVNMRSxtQkFUSztBQVVMckcsV0FWSztBQVdMRCxjQVhLO0FBWUx3RCxvQkFaSztBQWFMQztBQWJLLEtBRFQ7QUFBQSxjQWlCR2dDO0FBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXFCRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3RUQ7QUFFTyxNQUFNbEQsZUFBZSxnQkFBR2dELDJEQUFhLEVBQXJDOztBQUVQLE1BQU15QixPQUFPLEdBQUcsQ0FBQ2dCLFFBQUQsRUFBV0MsU0FBWCxFQUFzQkMsT0FBdEIsRUFBK0JDLE9BQS9CLEtBQTJDO0FBQ3pEZixPQUFLLENBQ0YsZ0ZBQStFWSxRQUFTLEVBRHRGLEVBRUg7QUFDRUksVUFBTSxFQUFFLE1BRFY7QUFFRUMsUUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNuQk4sZUFBUyxFQUFFQSxTQURRO0FBRW5CQyxhQUFPLEVBQUVBLE9BRlU7QUFHbkJNLFlBQU0sRUFBRTtBQUhXLEtBQWYsQ0FGUjtBQU9FQyxXQUFPLEVBQUU7QUFBRSxzQkFBZ0I7QUFBbEI7QUFQWCxHQUZHLENBQUwsQ0FZR0MsSUFaSCxDQVlTdkIsR0FBRCxJQUFTQSxHQUFHLENBQUNHLElBQUosRUFaakIsRUFhR29CLElBYkgsQ0FhU0MsTUFBRCxJQUFZO0FBQ2hCUixXQUFPLENBQUNRLE1BQUQsQ0FBUDtBQUNELEdBZkgsRUFnQkdDLEtBaEJILENBZ0JVQyxHQUFELElBQVNySSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCb0ksR0FBeEIsQ0FoQmxCO0FBaUJELENBbEJEOztBQW9CQSxNQUFNQyxjQUFjLEdBQUcsT0FBTzVCLEdBQVAsRUFBWWlCLE9BQVosS0FBd0I7QUFDN0MsTUFBSTtBQUNGLFVBQU1sQixRQUFRLEdBQUcsc0NBQWpCO0FBQ0EsVUFBTThCLElBQUksR0FBRzdCLEdBQWI7QUFDQSxVQUFNQyxHQUFHLEdBQUcsTUFBTUMsS0FBSyxDQUFDSCxRQUFRLEdBQUc4QixJQUFaLENBQXZCO0FBQ0EsVUFBTTFCLElBQUksR0FBRyxNQUFNRixHQUFHLENBQUNHLElBQUosRUFBbkI7QUFDQWEsV0FBTyxDQUFDZCxJQUFELENBQVA7QUFDRCxHQU5ELENBTUUsT0FBT1UsS0FBUCxFQUFjO0FBQ2R2SCxXQUFPLENBQUNDLEdBQVIsQ0FBWXNILEtBQVo7QUFDRDtBQUNGLENBVkQ7O0FBWWUsU0FBU2lCLGNBQVQsQ0FBd0I7QUFBRXZEO0FBQUYsQ0FBeEIsRUFBc0M7QUFDbkQsUUFBTTtBQUFBLE9BQUN3QyxTQUFEO0FBQUEsT0FBWTVGO0FBQVosTUFBNEJELHNEQUFRLENBQUMsSUFBSTlCLElBQUosRUFBRCxDQUExQztBQUNBLFFBQU07QUFBQSxPQUFDNEgsT0FBRDtBQUFBLE9BQVU1RjtBQUFWLE1BQXdCRixzREFBUSxDQUFDLElBQUk5QixJQUFKLEVBQUQsQ0FBdEM7QUFFQSxRQUFNO0FBQUEsT0FBQzJJLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCOUcsc0RBQVEsRUFBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3NELFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCdkQsc0RBQVEsRUFBeEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3dELFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCekQsc0RBQVEsRUFBMUM7QUFDQSxRQUFNO0FBQUEsT0FBQzhELE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXdCL0Qsc0RBQVEsRUFBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQzRELE1BQUQ7QUFBQSxPQUFTQztBQUFULE1BQXNCN0Qsc0RBQVEsRUFBcEM7QUFFQSxRQUFNO0FBQUEsT0FBQytHLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCaEgsc0RBQVEsRUFBNUM7QUFDQSxRQUFNO0FBQUEsT0FBQ2lILFdBQUQ7QUFBQSxPQUFjQztBQUFkLE1BQWdDbEgsc0RBQVEsRUFBOUM7QUFDQSxRQUFNO0FBQUEsT0FBQ21ILFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCcEgsc0RBQVEsRUFBeEM7QUFFQWpDLHlEQUFTLENBQUMsTUFBTTtBQUNkMkksa0JBQWMsQ0FDWCx5RkFEVyxFQUVaSSxVQUZZLENBQWQ7QUFLQUosa0JBQWMsQ0FDWiw4RkFEWSxFQUVaTSxhQUZZLENBQWQ7QUFLQXBDLFdBQU8sQ0FBQyx5QkFBRCxFQUE0QmlCLFNBQTVCLEVBQXVDQyxPQUF2QyxFQUFnRHZDLFdBQWhELENBQVA7QUFDQXFCLFdBQU8sQ0FBQyw2QkFBRCxFQUFnQ2lCLFNBQWhDLEVBQTJDQyxPQUEzQyxFQUFvRHJDLFlBQXBELENBQVA7QUFDQW1CLFdBQU8sQ0FBQywyQkFBRCxFQUE4QmlCLFNBQTlCLEVBQXlDQyxPQUF6QyxFQUFrRC9CLFVBQWxELENBQVA7QUFDQWEsV0FBTyxDQUFDLDBCQUFELEVBQTZCaUIsU0FBN0IsRUFBd0NDLE9BQXhDLEVBQWlEakMsU0FBakQsQ0FBUDtBQUVBZSxXQUFPLENBQUMsOEJBQUQsRUFBaUNpQixTQUFqQyxFQUE0Q0MsT0FBNUMsRUFBcURvQixjQUFyRCxDQUFQO0FBQ0F0QyxXQUFPLENBQUMsNkJBQUQsRUFBZ0NpQixTQUFoQyxFQUEyQ0MsT0FBM0MsRUFBb0RzQixXQUFwRCxDQUFQO0FBQ0QsR0FsQlEsRUFrQk4sQ0FDRDlELFFBREMsRUFFRHVELE9BRkMsRUFHRHJELFNBSEMsRUFJRE0sT0FKQyxFQUtERixNQUxDLEVBTURpQyxTQU5DLEVBT0RDLE9BUEMsRUFRRGlCLFVBUkMsRUFTREUsV0FUQyxFQVVERSxRQVZDLENBbEJNLENBQVQ7QUErQkEsUUFBTTFGLEtBQUssR0FBRyxDQUNaO0FBQUU0RixPQUFHLEVBQUUsbUJBQVA7QUFBNEJDLE9BQUcsRUFBRSxTQUFqQztBQUE0Q0MsU0FBSyxFQUFFVjtBQUFuRCxHQURZLEVBRVo7QUFDRVEsT0FBRyxFQUFFLHNCQURQO0FBRUVDLE9BQUcsRUFBRSxnQkFGUDtBQUdFQyxTQUFLLEVBQUVqRTtBQUhULEdBRlksRUFPWjtBQUNFK0QsT0FBRyxFQUFFLHVCQURQO0FBRUVDLE9BQUcsRUFBRSxvQkFGUDtBQUdFQyxTQUFLLEVBQUUvRDtBQUhULEdBUFksRUFZWjtBQUFFNkQsT0FBRyxFQUFFLHNCQUFQO0FBQStCQyxPQUFHLEVBQUUsa0JBQXBDO0FBQXdEQyxTQUFLLEVBQUV6RDtBQUEvRCxHQVpZLEVBYVo7QUFBRXVELE9BQUcsRUFBRSx5QkFBUDtBQUFrQ0MsT0FBRyxFQUFFLGtCQUF2QztBQUEyREMsU0FBSyxFQUFFM0Q7QUFBbEUsR0FiWSxDQUFkO0FBZ0JBLFFBQU1sQyxVQUFVLEdBQUcsQ0FDakI7QUFBRTJGLE9BQUcsRUFBRSxtQkFBUDtBQUE0QkMsT0FBRyxFQUFFLFNBQWpDO0FBQTRDQyxTQUFLLEVBQUVSO0FBQW5ELEdBRGlCLEVBRWpCO0FBQ0VNLE9BQUcsRUFBRSxzQkFEUDtBQUVFQyxPQUFHLEVBQUUsZ0JBRlA7QUFHRUMsU0FBSyxFQUFFTjtBQUhULEdBRmlCLEVBT2pCO0FBQ0VJLE9BQUcsRUFBRSxxQkFEUDtBQUVFQyxPQUFHLEVBQUUsVUFGUDtBQUdFQyxTQUFLLEVBQUVKO0FBSFQsR0FQaUIsQ0FBbkI7QUFjQSxzQkFDRSxxRUFBQyxlQUFELENBQWlCLFFBQWpCO0FBQ0UsU0FBSyxFQUFFO0FBQ0xsSCxrQkFESztBQUVMQyxnQkFGSztBQUdMdUIsV0FISztBQUlMQztBQUpLLEtBRFQ7QUFBQSxjQVFHMkI7QUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFZRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzSEQ7QUFDQTtBQUVBO0FBRWUsU0FBU21FLElBQVQsR0FBZ0I7QUFDN0Isc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxnREFBRDtBQUFBLDhCQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFLRSxxRUFBQyx3REFBRDtBQUFXLFVBQUksRUFBQztBQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQSxrQkFERjtBQVNELEM7Ozs7Ozs7Ozs7O0FDZkQsOEM7Ozs7Ozs7Ozs7O0FDQUEsOEM7Ozs7Ozs7Ozs7O0FDQUEsa0Q7Ozs7Ozs7Ozs7O0FDQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEsK0Q7Ozs7Ozs7Ozs7O0FDQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEsNEQ7Ozs7Ozs7Ozs7O0FDQUEsNEQ7Ozs7Ozs7Ozs7O0FDQUEsZ0U7Ozs7Ozs7Ozs7O0FDQUEsMEQ7Ozs7Ozs7Ozs7O0FDQUEsbUQ7Ozs7Ozs7Ozs7O0FDQUEsd0Q7Ozs7Ozs7Ozs7O0FDQUEsMkQ7Ozs7Ozs7Ozs7O0FDQUEsb0Q7Ozs7Ozs7Ozs7O0FDQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEsK0M7Ozs7Ozs7Ozs7O0FDQUEscUU7Ozs7Ozs7Ozs7O0FDQUEsMEQ7Ozs7Ozs7Ozs7O0FDQUEsb0Q7Ozs7Ozs7Ozs7O0FDQUEsaUQ7Ozs7Ozs7Ozs7O0FDQUEsZ0Q7Ozs7Ozs7Ozs7O0FDQUEscUM7Ozs7Ozs7Ozs7O0FDQUEsc0M7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEsa0QiLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3BhZ2VzL2luZGV4LmpzXCIpO1xuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCBcImRhdGUtZm5zXCI7XHJcblxyXG5pbXBvcnQgR3JpZCBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvR3JpZFwiO1xyXG5pbXBvcnQgRGF0ZUZuc1V0aWxzIGZyb20gXCJAZGF0ZS1pby9kYXRlLWZuc1wiO1xyXG5pbXBvcnQge1xyXG4gIE11aVBpY2tlcnNVdGlsc1Byb3ZpZGVyLFxyXG4gIEtleWJvYXJkRGF0ZVBpY2tlcixcclxufSBmcm9tIFwiQG1hdGVyaWFsLXVpL3BpY2tlcnNcIjtcclxuaW1wb3J0IENhbGVuZGFyVG9kYXlPdXRsaW5lZEljb24gZnJvbSBcIkBtYXRlcmlhbC11aS9pY29ucy9DYWxlbmRhclRvZGF5T3V0bGluZWRcIjtcclxuaW1wb3J0IHsgVHlwb2dyYXBoeSB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5cclxuaW1wb3J0IHsgQm9va2luZ0NvbnRleHQgfSBmcm9tIFwiLi4vLi4vLi4vY29udGV4dC9ib29raW5nRmV0Y2hcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBEYXRlUGlja2VyKCkge1xyXG4gIGNvbnN0IHZhbHVlID0gdXNlQ29udGV4dChCb29raW5nQ29udGV4dCk7XHJcbiAgY29uc3QgeyBkYXRlLCBzZXREYXRlLCBzZXRNb250aCwgbW9udGggfSA9IHZhbHVlO1xyXG5cclxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZGF0ZVRleHQgPSBtb250aF9uYW1lKG5ldyBEYXRlKCkpICsgXCIgXCIgKyBuZXcgRGF0ZSgpLmdldERhdGUoKTtcclxuICAgIHNldE1vbnRoKGRhdGVUZXh0KTtcclxuICAgIGNvbnNvbGUubG9nKG1vbnRoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IG1vbnRoX25hbWUgPSAoZHQpID0+IHtcclxuICAgIGNvbnN0IG1saXN0ID0gW1xyXG4gICAgICBcIkphbnVhcnlcIixcclxuICAgICAgXCJGZWJydWFyeVwiLFxyXG4gICAgICBcIk1hcmNoXCIsXHJcbiAgICAgIFwiQXByaWxcIixcclxuICAgICAgXCJNYXlcIixcclxuICAgICAgXCJKdW5lXCIsXHJcbiAgICAgIFwiSnVseVwiLFxyXG4gICAgICBcIkF1Z3VzdFwiLFxyXG4gICAgICBcIlNlcHRlbWJlclwiLFxyXG4gICAgICBcIk9jdG9iZXJcIixcclxuICAgICAgXCJOb3ZlbWJlclwiLFxyXG4gICAgICBcIkRlY2VtYmVyXCIsXHJcbiAgICBdO1xyXG4gICAgcmV0dXJuIG1saXN0W2R0LmdldE1vbnRoKCldO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURhdGVDaGFuZ2UgPSAoZGF0KSA9PiB7XHJcbiAgICBzZXREYXRlKGRhdCk7XHJcbiAgICBjb25zdCBkYXRlVGV4dCA9IG1vbnRoX25hbWUobmV3IERhdGUoZGF0KSkgKyBcIiBcIiArIGRhdC5nZXREYXRlKCk7XHJcbiAgICBzZXRNb250aChkYXRlVGV4dCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNdWlQaWNrZXJzVXRpbHNQcm92aWRlciB1dGlscz17RGF0ZUZuc1V0aWxzfT5cclxuICAgICAgPEdyaWQgaXRlbSB4cz17Nn0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXRlLXBpY2tlclwiPlxyXG4gICAgICAgICAgPEtleWJvYXJkRGF0ZVBpY2tlclxyXG4gICAgICAgICAgICBrZXlib2FyZEljb249e1xyXG4gICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxyXG4gICAgICAgICAgICAgICAgd2lkdGg9XCI0MFwiXHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0MFwiXHJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDYwIDYwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8Z1xyXG4gICAgICAgICAgICAgICAgICBpZD1cIkdyb3VwXzE0MzY1XCJcclxuICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiR3JvdXAgMTQzNjVcIlxyXG4gICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoLTU0MS4yNSAtMTQ0Ljc1KVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJQYXRoXzE0ODg4XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJQYXRoIDE0ODg4XCJcclxuICAgICAgICAgICAgICAgICAgICBkPVwiTTM0LjExNCwwSDUuMzg2QTUuMzkzLDUuMzkzLDAsMCwwLDAsNS4zODZWMzQuMTE0QTUuMzk0LDUuMzk0LDAsMCwwLDUuMzg2LDM5LjVIMzQuMTE0QTUuMzk0LDUuMzk0LDAsMCwwLDM5LjUsMzQuMTE0VjUuMzg2QTUuMzk0LDUuMzk0LDAsMCwwLDM0LjExNCwwWk0zNy43LDM0LjExNEEzLjYsMy42LDAsMCwxLDM0LjExNCwzNy43SDUuMzg2QTMuNiwzLjYsMCwwLDEsMS44LDM0LjExNFY1LjM4NkEzLjYsMy42LDAsMCwxLDUuMzg2LDEuOEgzNC4xMTRBMy42LDMuNiwwLDAsMSwzNy43LDUuMzg2WlwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU0MS41IDE0NSlcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2Utd2lkdGg9XCIwLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZWxsaXBzZVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiRWxsaXBzZV8zNTUwXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJFbGxpcHNlIDM1NTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN4PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN5PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ4PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ5PVwiMS41MjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSg1NTEuMDQ3IDE1MS4xNylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGVsbGlwc2VcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIkVsbGlwc2VfMzU1MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS1uYW1lPVwiRWxsaXBzZSAzNTUxXCJcclxuICAgICAgICAgICAgICAgICAgICBjeD1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICBjeT1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICByeD1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICByeT1cIjEuNTI0XCJcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoNTU5LjcyNyAxNTEuMTcpXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwiI2U3MjMxMVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxlbGxpcHNlXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJFbGxpcHNlXzM1NTJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIkVsbGlwc2UgMzU1MlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY3g9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY3k9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcng9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcnk9XCIxLjUyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU2OC40MDQgMTUxLjE3KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNlNzIzMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8cmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiUmVjdGFuZ2xlXzI4NjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSAyODY0XCJcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjUuNTAxXCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5M1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU1NC44MjcgMTYwLjQ0MylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODY1XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg2NVwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjQuODkzXCJcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoNTYyLjE3MiAxNjAuNDQzKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNlNzIzMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8cmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiUmVjdGFuZ2xlXzI4NjZcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSAyODY2XCJcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjUuNTAxXCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5M1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU2OS41MTQgMTYwLjQ0MylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODY3XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg2N1wiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjQuODkxXCJcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoNTQ3LjQ4NCAxNjYuOTc2KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNlNzIzMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8cmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiUmVjdGFuZ2xlXzI4NjhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSAyODY4XCJcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjUuNTAxXCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU1NC44MjcgMTY2Ljk3NilcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODY5XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg2OVwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjQuODkxXCJcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoNTYyLjE3MiAxNjYuOTc2KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNlNzIzMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8cmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiUmVjdGFuZ2xlXzI4NzBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSAyODcwXCJcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjUuNTAxXCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU2OS41MTQgMTY2Ljk3NilcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODcxXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg3MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjQuODkxXCJcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoNTQ3LjQ4NCAxNzMuNTA3KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNlNzIzMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8cmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiUmVjdGFuZ2xlXzI4NzJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSAyODcyXCJcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjUuNTAxXCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU1NC44MjcgMTczLjUwNylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZD1cIlJlY3RhbmdsZV8yODczXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLW5hbWU9XCJSZWN0YW5nbGUgMjg3M1wiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCI1LjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjQuODkxXCJcclxuICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoNTYyLjE3MiAxNzMuNTA3KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIiNlNzIzMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8cmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiUmVjdGFuZ2xlXzI4NzRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtbmFtZT1cIlJlY3RhbmdsZSAyODc0XCJcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjUuNTAxXCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCI0Ljg5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtPVwidHJhbnNsYXRlKDU2OS41MTQgMTczLjUwNylcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCIjZTcyMzExXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBtYXJnaW49XCJub3JtYWxcIlxyXG4gICAgICAgICAgICB2YWx1ZT17ZGF0ZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZURhdGVDaGFuZ2V9XHJcbiAgICAgICAgICAgIGZvcm1hdD1cInl5eXktTU0tZGRkXCJcclxuICAgICAgICAgICAgS2V5Ym9hcmRCdXR0b25Qcm9wcz17e1xyXG4gICAgICAgICAgICAgIFwiYXJpYS1sYWJlbFwiOiBcImNoYW5nZSBkYXRlXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICA8L011aVBpY2tlcnNVdGlsc1Byb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgd2l0aFN0eWxlcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIjtcclxuaW1wb3J0IEZvcm1Db250cm9sIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9Gb3JtQ29udHJvbFwiO1xyXG5pbXBvcnQgTmF0aXZlU2VsZWN0IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9OYXRpdmVTZWxlY3RcIjtcclxuaW1wb3J0IElucHV0QmFzZSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvSW5wdXRCYXNlXCI7XHJcblxyXG5pbXBvcnQgeyBEYXNoQm9yZENvbnRleHQgfSBmcm9tIFwiLi4vLi4vLi4vY29udGV4dC9kYXNoYm9hcmRGZXRjaFwiO1xyXG5cclxuY29uc3QgQm9vdHN0cmFwSW5wdXQgPSB3aXRoU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICBpbnB1dDoge1xyXG4gICAgbWluV2lkdGg6IFwiOHJlbVwiLFxyXG4gICAgYm9yZGVyUmFkaXVzOiA0LFxyXG4gICAgcG9zaXRpb246IFwicmVsYXRpdmVcIixcclxuICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5wcmltYXJ5Lm1haW4sXHJcbiAgICBib3JkZXI6IFwibm9uZVwiLFxyXG4gICAgZm9udFNpemU6IDE0LFxyXG4gICAgcGFkZGluZzogXCIxMHB4IDI2cHggMTBweCA1cHhcIixcclxuICAgIGNvbG9yOiBcIiNmZmZcIixcclxuICAgIFwiJjpmb2N1c1wiOiB7XHJcbiAgICAgIGJhY2tncm91bmQ6IHRoZW1lLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gICAgICBib3JkZXJSYWRpdXM6IFwiNHB4XCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pKShJbnB1dEJhc2UpO1xyXG5cclxuY29uc3Qgb25TdGFydEVuZCA9IChkYXRlLCBtb250aCwgeWVhcikgPT4ge1xyXG4gIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RhdGV9YDtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBDdXN0b21pemVkU2VsZWN0cygpIHtcclxuICBjb25zdCBbZGF0ZSwgc2V0RGF0ZV0gPSBSZWFjdC51c2VTdGF0ZShcInRvZGF5XCIpO1xyXG5cclxuICBjb25zdCB7IHNldFN0YXJ0RGF0ZSwgc2V0RW5kRGF0ZSB9ID0gdXNlQ29udGV4dChEYXNoQm9yZENvbnRleHQpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCJEYXRlID0gXCIsIGRhdGUpO1xyXG4gIH0sIFtkYXRlXSk7XHJcblxyXG4gIGNvbnN0IGRhdGVIYW5kbGVyID0gKGV2ZW50KSA9PiB7XHJcbiAgICBjb25zdCBuZXdEYXRlID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IHZhbHVlID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgc3dpdGNoICh2YWx1ZSkge1xyXG4gICAgICBjYXNlIFwidG9kYXlcIjpcclxuICAgICAgICBzZXRTdGFydERhdGUoXHJcbiAgICAgICAgICBvblN0YXJ0RW5kKFxyXG4gICAgICAgICAgICBuZXdEYXRlLmdldERhdGUoKSxcclxuICAgICAgICAgICAgbmV3RGF0ZS5nZXRNb250aCgpICsgMSxcclxuICAgICAgICAgICAgbmV3RGF0ZS5nZXRGdWxsWWVhcigpXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRFbmREYXRlKFxyXG4gICAgICAgICAgb25TdGFydEVuZChcclxuICAgICAgICAgICAgbmV3RGF0ZS5nZXREYXRlKCksXHJcbiAgICAgICAgICAgIG5ld0RhdGUuZ2V0TW9udGgoKSArIDEsXHJcbiAgICAgICAgICAgIG5ld0RhdGUuZ2V0RnVsbFllYXIoKVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJjdXJyZW50XCI6XHJcbiAgICAgICAgc2V0U3RhcnREYXRlKFxyXG4gICAgICAgICAgb25TdGFydEVuZChcIjAxXCIsIG5ld0RhdGUuZ2V0TW9udGgoKSArIDEsIG5ld0RhdGUuZ2V0RnVsbFllYXIoKSlcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldEVuZERhdGUoXHJcbiAgICAgICAgICBvblN0YXJ0RW5kKFwiMzBcIiwgbmV3RGF0ZS5nZXRNb250aCgpICsgMSwgbmV3RGF0ZS5nZXRGdWxsWWVhcigpKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJ0aHJlZVwiOlxyXG4gICAgICAgIHNldFN0YXJ0RGF0ZShcclxuICAgICAgICAgIG9uU3RhcnRFbmQoXCIwMVwiLCBuZXdEYXRlLmdldE1vbnRoKCkgLSAyLCBuZXdEYXRlLmdldEZ1bGxZZWFyKCkpXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRFbmREYXRlKFxyXG4gICAgICAgICAgb25TdGFydEVuZChcIjMwXCIsIG5ld0RhdGUuZ2V0TW9udGgoKSArIDEsIG5ld0RhdGUuZ2V0RnVsbFllYXIoKSlcclxuICAgICAgICApO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlIFwic2l4XCI6XHJcbiAgICAgICAgc2V0U3RhcnREYXRlKFxyXG4gICAgICAgICAgb25TdGFydEVuZChcIjAxXCIsIG5ld0RhdGUuZ2V0TW9udGgoKSAtIDUsIG5ld0RhdGUuZ2V0RnVsbFllYXIoKSlcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldEVuZERhdGUoXHJcbiAgICAgICAgICBvblN0YXJ0RW5kKFwiMzBcIiwgbmV3RGF0ZS5nZXRNb250aCgpICsgMSwgbmV3RGF0ZS5nZXRGdWxsWWVhcigpKVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJ5ZWFyXCI6XHJcbiAgICAgICAgc2V0U3RhcnREYXRlKG9uU3RhcnRFbmQoXCIwMVwiLCBcIjAxXCIsIG5ld0RhdGUuZ2V0RnVsbFllYXIoKSAtIDEpKTtcclxuICAgICAgICBzZXRFbmREYXRlKG9uU3RhcnRFbmQoXCIzMFwiLCBcIjEyXCIsIG5ld0RhdGUuZ2V0RnVsbFllYXIoKSAtIDEpKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICBicmVhaztcclxuICAgIH1cclxuICAgIHNldERhdGUoZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPEZvcm1Db250cm9sPlxyXG4gICAgICAgIDxOYXRpdmVTZWxlY3RcclxuICAgICAgICAgIGlkPVwiZGVtby1jdXN0b21pemVkLXNlbGVjdC1uYXRpdmVcIlxyXG4gICAgICAgICAgdmFsdWU9e2RhdGV9XHJcbiAgICAgICAgICBvbkNoYW5nZT17ZGF0ZUhhbmRsZXJ9XHJcbiAgICAgICAgICBpbnB1dD17PEJvb3RzdHJhcElucHV0IC8+fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxvcHRpb24gc3R5bGU9e3sgY29sb3I6IFwiIzAwMFwiIH19IHZhbHVlPXtcInRvZGF5XCJ9PlxyXG4gICAgICAgICAgICBUb2RheVxyXG4gICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICA8b3B0aW9uIHN0eWxlPXt7IGNvbG9yOiBcIiMwMDBcIiB9fSB2YWx1ZT17XCJjdXJyZW50XCJ9PlxyXG4gICAgICAgICAgICBDdXJyZW50IE1vbnRoXHJcbiAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgIDxvcHRpb24gc3R5bGU9e3sgY29sb3I6IFwiIzAwMFwiIH19IHZhbHVlPXtcInRocmVlXCJ9PlxyXG4gICAgICAgICAgICBMYXN0IFRocmVlIE1vbnRoc1xyXG4gICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICA8b3B0aW9uIHN0eWxlPXt7IGNvbG9yOiBcIiMwMDBcIiB9fSB2YWx1ZT17XCJzaXhcIn0+XHJcbiAgICAgICAgICAgIExhc3QgNiBNb250aHNcclxuICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgPG9wdGlvbiBzdHlsZT17eyBjb2xvcjogXCIjMDAwXCIgfX0gdmFsdWU9e1wieWVhclwifT5cclxuICAgICAgICAgICAgTGFzdCBZZWFyXHJcbiAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICA8L05hdGl2ZVNlbGVjdD5cclxuICAgICAgPC9Gb3JtQ29udHJvbD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIiwiZXhwb3J0IHsgU3Bpbm5lciB9IGZyb20gXCIuL3NwaW5uZXIvc3Bpbm5lclwiO1xyXG5leHBvcnQgeyBQYWdlVGl0bGUgfSBmcm9tIFwiLi9wYWdlVGl0bGUvcGFnZVRpdGxlXCI7XHJcbmV4cG9ydCB7IExnQnRuIH0gZnJvbSBcIi4vbGdCdG4vbGdCdG5cIjtcclxuZXhwb3J0IHsgRGF0ZVBpY2tlciB9IGZyb20gXCIuL2RhdGVQaWNrZXIvZGF0ZVBpY2tlclwiO1xyXG5leHBvcnQgeyBTaW1wbGVNb2RhbCB9IGZyb20gXCIuL21vZGFsL21vZGFsXCI7XHJcbmV4cG9ydCB7IEN1c3RvbWl6ZWRSYXRpbmdzIH0gZnJvbSBcIi4vcmF0aW5nU3Rhci9yYXRpbmdTdGFyXCI7XHJcbmV4cG9ydCB7IEN1c3RvbWl6ZWRTZWxlY3RzIH0gZnJvbSBcIi4vZHJvcERvd24vZHJvcERvd25cIjtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvc3R5bGVzXCI7XHJcbmltcG9ydCB7IEJ1dHRvbiwgR3JpZCB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5cclxuaW1wb3J0IHsgRGF0ZVBpY2tlciB9IGZyb20gXCIuLi9cIjtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gIHJvb3Q6IHtcclxuICAgIG1hcmdpblRvcDogXCIxcmVtXCIsXHJcbiAgfSxcclxuICBidG46IHtcclxuICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgIHBhZGRpbmc6IFwiMC41cmVtIDBcIixcclxuICAgIHRleHRUcmFuc2Zvcm06IFwiY2FwaXRhbGl6ZVwiLFxyXG4gICAgYmFja2dyb3VuZDogXCIjZjZmNmY2XCIsXHJcbiAgICBib3JkZXJUb3BMZWZ0UmFkaXVzOiBcIjBcIixcclxuICAgIGJvcmRlckJvdHRvbUxlZnRSYWRpdXM6IFwiMFwiLFxyXG4gICAgY29sb3I6IFwiIzAwMFwiLFxyXG4gICAgXCImOmhvdmVyXCI6IHtcclxuICAgICAgYmFja2dyb3VuZDogXCIjZjZmNmY2XCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAgYWN0aXZlOiB7XHJcbiAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICBjb2xvcjogXCIjZmZmXCIsXHJcbiAgICBiYWNrZ3JvdW5kOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubWFpbixcclxuICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICAgIHBhZGRpbmc6IFwiMC41cmVtIDBcIixcclxuICAgIHRleHRUcmFuc2Zvcm06IFwiY2FwaXRhbGl6ZVwiLFxyXG4gICAgYm9yZGVyVG9wTGVmdFJhZGl1czogXCIwXCIsXHJcbiAgICBib3JkZXJCb3R0b21MZWZ0UmFkaXVzOiBcIjBcIixcclxuICAgIFwiJjpob3ZlclwiOiB7XHJcbiAgICAgIGJhY2tncm91bmQ6IFwidmFyKC0tcHJpbWFyeS1jb2xvcilcIixcclxuICAgIH0sXHJcbiAgfSxcclxufSkpO1xyXG5cclxuZXhwb3J0IGNvbnN0IExnQnRuID0gKHtcclxuICBzZXRCb29raW5nVHlwZSxcclxuICBib29raW5nVHlwZSxcclxuICBjYWxlbmRlcixcclxuICBtYW5hZ2VtZW50LFxyXG59KSA9PiB7XHJcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG5cclxuICBsZXQgbG9jYWwgPSBcImJvb2tpbmdMb2NhbHNcIjtcclxuICBsZXQgZXhwZXJpZW5jZSA9IFwiYm9va2luZ0V4cGVyaWVuY2VzXCI7XHJcblxyXG4gIGlmIChtYW5hZ2VtZW50KSB7XHJcbiAgICBsb2NhbCA9IFwibG9jYWxzXCI7XHJcbiAgICBleHBlcmllbmNlID0gXCJleHBlcmllbmNlc1wiO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxHcmlkIGNvbnRhaW5lciBpdGVtIHhzPXs2fSBjbGFzc05hbWU9e2NsYXNzZXMucm9vdH0gYWxpZ25Db250ZW50PVwiY2VudGVyXCI+XHJcbiAgICAgIDxHcmlkIGl0ZW0geHM9ezJ9PlxyXG4gICAgICAgIDxCdXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJvb2tpbmdUeXBlKGxvY2FsKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17Ym9va2luZ1R5cGUgPT09IGxvY2FsID8gY2xhc3Nlcy5hY3RpdmUgOiBjbGFzc2VzLmJ0bn1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBMb2NhbHNcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9HcmlkPlxyXG4gICAgICA8R3JpZCBpdGVtIHhzPXsyfT5cclxuICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRCb29raW5nVHlwZShleHBlcmllbmNlKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17Ym9va2luZ1R5cGUgPT09IGV4cGVyaWVuY2UgPyBjbGFzc2VzLmFjdGl2ZSA6IGNsYXNzZXMuYnRufVxyXG4gICAgICAgID5cclxuICAgICAgICAgIEV4cGVyaW5jZVxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICAgIDxHcmlkIGl0ZW0geHM9ezJ9PlxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgIG1hcmdpbjogXCIwLjVyZW0gYXV0b1wiLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7Y2FsZW5kZXIgJiYgPERhdGVQaWNrZXIgLz59XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgIDwvR3JpZD5cclxuICApO1xyXG59O1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0J1dHRvblwiO1xyXG5pbXBvcnQgRGlhbG9nIGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dcIjtcclxuaW1wb3J0IERpYWxvZ0FjdGlvbnMgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ0FjdGlvbnNcIjtcclxuaW1wb3J0IERpYWxvZ0NvbnRlbnQgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ0NvbnRlbnRcIjtcclxuaW1wb3J0IERpYWxvZ0NvbnRlbnRUZXh0IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dDb250ZW50VGV4dFwiO1xyXG4vLyBpbXBvcnQgRGlhbG9nVGl0bGUgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ1RpdGxlXCI7XHJcbmltcG9ydCBTbGlkZSBmcm9tIFwiQG1hdGVyaWFsLXVpL2NvcmUvU2xpZGVcIjtcclxuXHJcbmNvbnN0IFRyYW5zaXRpb24gPSBSZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFRyYW5zaXRpb24ocHJvcHMsIHJlZikge1xyXG4gIHJldHVybiA8U2xpZGUgZGlyZWN0aW9uPVwidXBcIiByZWY9e3JlZn0gey4uLnByb3BzfSAvPjtcclxufSk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gU2ltcGxlTW9kYWwoeyBvcGVuLCBoYW5kbGVDbG9zZSwgc3RhdHVzSGFuZGxlciB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxEaWFsb2dcclxuICAgICAgICBvcGVuPXtvcGVufVxyXG4gICAgICAgIFRyYW5zaXRpb25Db21wb25lbnQ9e1RyYW5zaXRpb259XHJcbiAgICAgICAga2VlcE1vdW50ZWRcclxuICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZX1cclxuICAgICAgICBhcmlhLWxhYmVsbGVkYnk9XCJhbGVydC1kaWFsb2ctc2xpZGUtdGl0bGVcIlxyXG4gICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9XCJhbGVydC1kaWFsb2ctc2xpZGUtZGVzY3JpcHRpb25cIlxyXG4gICAgICA+XHJcbiAgICAgICAgPERpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgICA8RGlhbG9nQ29udGVudFRleHQgaWQ9XCJhbGVydC1kaWFsb2ctc2xpZGUtZGVzY3JpcHRpb25cIj5cclxuICAgICAgICAgICAgQXJlIFlvdSBTdXJlLi4/XHJcbiAgICAgICAgICA8L0RpYWxvZ0NvbnRlbnRUZXh0PlxyXG4gICAgICAgIDwvRGlhbG9nQ29udGVudD5cclxuICAgICAgICA8RGlhbG9nQWN0aW9ucz5cclxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlQ2xvc2V9IGNvbG9yPVwicHJpbWFyeVwiPlxyXG4gICAgICAgICAgICBEaXNhZ3JlZVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3N0YXR1c0hhbmRsZXJ9IGNvbG9yPVwicHJpbWFyeVwiPlxyXG4gICAgICAgICAgICBBZ3JlZVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9EaWFsb2dBY3Rpb25zPlxyXG4gICAgICA8L0RpYWxvZz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IHsgVHlwb2dyYXBoeSwgR3JpZCB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZVwiO1xyXG5pbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9zdHlsZXNcIjtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gIHRpdGxlOiB7XHJcbiAgICB0ZXh0VHJhbnNmb3JtOiBcInVwcGVyY2FzZVwiLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBjb25zdCBQYWdlVGl0bGUgPSAoeyB0ZXh0IH0pID0+IHtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxHcmlkIGNvbnRhaW5lcj5cclxuICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeSBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9IHZhcmlhbnQ9XCJoNVwiPlxyXG4gICAgICAgICAgICB7dGV4dH1cclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFJhdGluZyBmcm9tIFwiQG1hdGVyaWFsLXVpL2xhYi9SYXRpbmdcIjtcclxuaW1wb3J0IFN0YXJCb3JkZXJJY29uIGZyb20gXCJAbWF0ZXJpYWwtdWkvaWNvbnMvU3RhckJvcmRlclwiO1xyXG5pbXBvcnQgQm94IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9Cb3hcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBDdXN0b21pemVkUmF0aW5ncyh7IHJhdGluZywgc2l6ZSwgbWF4ID0gMSwgcmV2UmF0IH0pIHtcclxuICBsZXQgdmFsdWUgPSBudWxsO1xyXG4gIGlmIChyYXRpbmcgPT09IDUgJiYgIXJldlJhdCkge1xyXG4gICAgdmFsdWUgPSAxO1xyXG4gIH0gZWxzZSBpZiAocmF0aW5nIDwgNSAmJiAhcmV2UmF0KSB7XHJcbiAgICB2YWx1ZSA9IDAuNTtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxCb3ggY29tcG9uZW50PVwiZmllbGRzZXRcIiBtYj17M30gYm9yZGVyQ29sb3I9XCJ0cmFuc3BhcmVudFwiPlxyXG4gICAgICAgIDxSYXRpbmdcclxuICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBcInZhcigtLXByaW1hcnktY29sb3IpXCIgfX1cclxuICAgICAgICAgIG5hbWU9XCJjdXN0b21pemVkLWVtcHR5XCJcclxuICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICBtYXg9e21heH1cclxuICAgICAgICAgIHByZWNpc2lvbj17MC41fVxyXG4gICAgICAgICAgdmFsdWU9e3ZhbHVlID8gdmFsdWUgOiByZXZSYXR9XHJcbiAgICAgICAgICBzaXplPXtzaXplfVxyXG4gICAgICAgICAgZW1wdHlJY29uPXs8U3RhckJvcmRlckljb24gZm9udFNpemU9XCJpbmhlcml0XCIgLz59XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9Cb3g+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIjtcclxuaW1wb3J0IENpcmN1bGFyUHJvZ3Jlc3MgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL0NpcmN1bGFyUHJvZ3Jlc3NcIjtcclxuaW1wb3J0IHsgSGVpZ2h0IH0gZnJvbSBcIkBtYXRlcmlhbC11aS9pY29uc1wiO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgcm9vdDoge1xyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBcIiYgPiAqICsgKlwiOiB7XHJcbiAgICAgIG1hcmdpbkxlZnQ6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgICB9LFxyXG4gICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgaGVpZ2h0OiBcIjEwMHZoXCIsXHJcbiAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcclxuICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgfSxcclxufSkpO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIFNwaW5uZXIoKSB7XHJcbiAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMucm9vdH0+XHJcbiAgICAgIDxDaXJjdWxhclByb2dyZXNzIGNvbG9yPVwic2Vjb25kYXJ5XCIgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCBjcmVhdGVDb250ZXh0LCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBCb29raW5nQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJvb2tpbmdGZXRjaCh7IGNoaWxkcmVuIH0pIHtcclxuICBjb25zdCBbYm9va2luZ3MsIHNldEJvb2tpbmdzXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW2NvbXBsZXRlZCwgc2V0Q29tcGxldGVkXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW3BlbmRpbmcsIHNldFBlbmRpbmddID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbbm9TaG93LCBzZXROb1Nob3ddID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbZGVsZXRlZCwgc2V0RGVsZXRlZF0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtib29raW5nVHlwZSwgc2V0Qm9va2luZ1R5cGVdID0gdXNlU3RhdGUoXCJib29raW5nTG9jYWxzXCIpO1xyXG5cclxuICBjb25zdCBbYm9va2luZ0RhdGEsIHNldEJvb2tpbmdEYXRhXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW2Jvb2tpbmdIZWFkZXIsIHNldEJvb2tpbmdIZWFkZXJdID0gdXNlU3RhdGUoKTtcclxuXHJcbiAgY29uc3QgW2RhdGUsIHNldERhdGVdID0gdXNlU3RhdGUobmV3IERhdGUoKSk7XHJcbiAgY29uc3QgW21vbnRoLCBzZXRNb250aF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgZmlsdGVyID0gKGFycmF5LCBzdGF0dXMsIHNldEZ1bmMpID0+IHtcclxuICAgIGNvbnN0IEZpbHRlckFycmF5ID0gYXJyYXkuZmlsdGVyKChlbCkgPT4gZWwuc3RhdHVzID09PSBzdGF0dXMpO1xyXG4gICAgc2V0RnVuYyhGaWx0ZXJBcnJheSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCBib29raW5nc0tleXMgPSBbXTtcclxuICAgIGxldCBib29raW5nc0RhdGEgPSBbXTtcclxuICAgIGNvbnN0IGZldGNoZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgbmV3RGF0ZSA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgICAgIGNvbnN0IHByb3h5VXJsID0gXCJodHRwczovL2NvcnMtYW55d2hlcmUuaGVyb2t1YXBwLmNvbS9cIjtcclxuICAgICAgICBjb25zdCB1cmwgPSBgaHR0cDovL25hcHBldGl0by1zdGFnZS5oZXJva3VhcHAuY29tL2FwaS8ke2Jvb2tpbmdUeXBlfS81ZWM1MDNjYzQzNGRmZjI5Y2Y1NjYzM2IvJHtuZXdEYXRlLmdldEZ1bGxZZWFyKCl9LSR7XHJcbiAgICAgICAgICBuZXdEYXRlLmdldE1vbnRoKCkgKyAxXHJcbiAgICAgICAgfS0ke25ld0RhdGUuZ2V0RGF0ZSgpfS9hbGxgO1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHByb3h5VXJsICsgdXJsKTtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgICBzZXRCb29raW5ncyhkYXRhKTtcclxuICAgICAgICBPYmplY3QudmFsdWVzKGRhdGEpLmZvckVhY2goKGVsLCBpKSA9PiB7XHJcbiAgICAgICAgICBpZiAoaSA9PT0gMCkge1xyXG4gICAgICAgICAgICBPYmplY3Qua2V5cyhlbCkuZm9yRWFjaCgoa2V5KSA9PiB7XHJcbiAgICAgICAgICAgICAgYm9va2luZ3NLZXlzLnB1c2goeyBsYWJlbDoga2V5LCBrZXk6IGtleSB9KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBib29raW5nc0RhdGEucHVzaChlbCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0Qm9va2luZ0RhdGEoYm9va2luZ3NEYXRhKTtcclxuICAgICAgICBzZXRCb29raW5nSGVhZGVyKGJvb2tpbmdzS2V5cyk7XHJcbiAgICAgICAgZmlsdGVyKGRhdGEsIFwiZGVsZXRlZFwiLCBzZXREZWxldGVkKTtcclxuICAgICAgICBmaWx0ZXIoZGF0YSwgXCJwZW5kaW5nXCIsIHNldFBlbmRpbmcpO1xyXG4gICAgICAgIGZpbHRlcihkYXRhLCBcIm5vLXNob3dcIiwgc2V0Tm9TaG93KTtcclxuICAgICAgICBmaWx0ZXIoZGF0YSwgXCJjb21wbGV0ZWRcIiwgc2V0Q29tcGxldGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaGVyKCk7XHJcbiAgfSwgW2RhdGUsIGJvb2tpbmdUeXBlXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxCb29raW5nQ29udGV4dC5Qcm92aWRlclxyXG4gICAgICB2YWx1ZT17e1xyXG4gICAgICAgIGJvb2tpbmdzLFxyXG4gICAgICAgIGRhdGUsXHJcbiAgICAgICAgc2V0RGF0ZSxcclxuICAgICAgICBkZWxldGVkLFxyXG4gICAgICAgIHBlbmRpbmcsXHJcbiAgICAgICAgbm9TaG93LFxyXG4gICAgICAgIGNvbXBsZXRlZCxcclxuICAgICAgICBib29raW5nRGF0YSxcclxuICAgICAgICBib29raW5nSGVhZGVyLFxyXG4gICAgICAgIG1vbnRoLFxyXG4gICAgICAgIHNldE1vbnRoLFxyXG4gICAgICAgIHNldEJvb2tpbmdUeXBlLFxyXG4gICAgICAgIGJvb2tpbmdUeXBlXHJcbiAgICAgIH19XHJcbiAgICA+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvQm9va2luZ0NvbnRleHQuUHJvdmlkZXI+XHJcbiAgKTtcclxufVxyXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCBjcmVhdGVDb250ZXh0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IERhc2hCb3JkQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKTtcclxuXHJcbmNvbnN0IGZldGNoZXIgPSAoZW5kcG9pbnQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgc2V0RGF0YSkgPT4ge1xyXG4gIGZldGNoKFxyXG4gICAgYGh0dHBzOi8vY29ycy1hbnl3aGVyZS5oZXJva3VhcHAuY29tL2h0dHA6Ly9uYXBwZXRpdG8tc3RhZ2UuaGVyb2t1YXBwLmNvbS9hcGkvJHtlbmRwb2ludH1gLFxyXG4gICAge1xyXG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxyXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgc3RhcnREYXRlOiBzdGFydERhdGUsXHJcbiAgICAgICAgZW5kRGF0ZTogZW5kRGF0ZSxcclxuICAgICAgICB1c2VySWQ6IFwiNWVjNTAzY2M0MzRkZmYyOWNmNTY2MzNiXCIsXHJcbiAgICAgIH0pLFxyXG4gICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICB9XHJcbiAgKVxyXG4gICAgLnRoZW4oKHJlcykgPT4gcmVzLmpzb24oKSlcclxuICAgIC50aGVuKChyZXN1bHQpID0+IHtcclxuICAgICAgc2V0RGF0YShyZXN1bHQpO1xyXG4gICAgfSlcclxuICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhcIkVycm9yID0gXCIsIGVycikpO1xyXG59O1xyXG5cclxuY29uc3QgZmV0Y2hlclJldmlld3MgPSBhc3luYyAodXJsLCBzZXREYXRhKSA9PiB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHByb3h5VXJsID0gXCJodHRwczovL2NvcnMtYW55d2hlcmUuaGVyb2t1YXBwLmNvbS9cIjtcclxuICAgIGNvbnN0IHVybGwgPSB1cmw7XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChwcm94eVVybCArIHVybGwpO1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICBzZXREYXRhKGRhdGEpO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGFzaGJvYXJkRmV0Y2goeyBjaGlsZHJlbiB9KSB7XHJcbiAgY29uc3QgW3N0YXJ0RGF0ZSwgc2V0U3RhcnREYXRlXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkpO1xyXG4gIGNvbnN0IFtlbmREYXRlLCBzZXRFbmREYXRlXSA9IHVzZVN0YXRlKG5ldyBEYXRlKCkpO1xyXG5cclxuICBjb25zdCBbcmV2aWV3cywgc2V0UmV2aWV3c10gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtib29raW5ncywgc2V0Qm9va2luZ3NdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbY29tcGxldGVkLCBzZXRDb21wbGV0ZWRdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbZGVsZXRlZCwgc2V0RGVsZXRlZF0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtub1Nob3csIHNldE5vU2hvd10gPSB1c2VTdGF0ZSgpO1xyXG5cclxuICBjb25zdCBbZXhwUmV2aWV3cywgc2V0RXhwUmV2aWV3c10gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtleHBCb29raW5ncywgc2V0RXhwQm9va2luZ3NdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbZWFybmluZ3MsIHNldEVhcm5pbmdzXSA9IHVzZVN0YXRlKCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaGVyUmV2aWV3cyhcclxuICAgICAgYGh0dHA6Ly9uYXBwZXRpdG8tc3RhZ2UuaGVyb2t1YXBwLmNvbS9hcGkvcmV2aWV3TG9jYWxUb3RhbENvdW50LzVlYzUwM2NjNDM0ZGZmMjljZjU2NjMzYmAsXHJcbiAgICAgIHNldFJldmlld3NcclxuICAgICk7XHJcblxyXG4gICAgZmV0Y2hlclJldmlld3MoXHJcbiAgICAgIFwiaHR0cDovL25hcHBldGl0by1zdGFnZS5oZXJva3VhcHAuY29tL2FwaS9yZXZpZXdFeHBlcmllbmNlVG90YWxDb3VudC81ZmEzZWI5Zjk0MTJjM2ZlMDUxM2RkYzZcIixcclxuICAgICAgc2V0RXhwUmV2aWV3c1xyXG4gICAgKTtcclxuXHJcbiAgICBmZXRjaGVyKFwiYm9va2luZ0xvY2Fsc1RvdGFsQ291bnRcIiwgc3RhcnREYXRlLCBlbmREYXRlLCBzZXRCb29raW5ncyk7XHJcbiAgICBmZXRjaGVyKFwiYm9va2luZ0xvY2Fsc0NvbXBsZXRlZENvdW50XCIsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgc2V0Q29tcGxldGVkKTtcclxuICAgIGZldGNoZXIoXCJib29raW5nTG9jYWxzRGVsZXRlZENvdW50XCIsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgc2V0RGVsZXRlZCk7XHJcbiAgICBmZXRjaGVyKFwiYm9va2luZ0xvY2Fsc05vU2hvd0NvdW50XCIsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSwgc2V0Tm9TaG93KTtcclxuXHJcbiAgICBmZXRjaGVyKFwiYm9va2luZ0V4cGVyaWVuY2VzVG90YWxDb3VudFwiLCBzdGFydERhdGUsIGVuZERhdGUsIHNldEV4cEJvb2tpbmdzKTtcclxuICAgIGZldGNoZXIoXCJib29raW5nRXhwZXJpZW5jZXNUb3RhbEdhaW5cIiwgc3RhcnREYXRlLCBlbmREYXRlLCBzZXRFYXJuaW5ncyk7XHJcbiAgfSwgW1xyXG4gICAgYm9va2luZ3MsXHJcbiAgICByZXZpZXdzLFxyXG4gICAgY29tcGxldGVkLFxyXG4gICAgZGVsZXRlZCxcclxuICAgIG5vU2hvdyxcclxuICAgIHN0YXJ0RGF0ZSxcclxuICAgIGVuZERhdGUsXHJcbiAgICBleHBSZXZpZXdzLFxyXG4gICAgZXhwQm9va2luZ3MsXHJcbiAgICBlYXJuaW5ncyxcclxuICBdKTtcclxuXHJcbiAgY29uc3QgbG9jYWwgPSBbXHJcbiAgICB7IHNyYzogXCIvaW1hZ2VzL3N0YXJzLnN2Z1wiLCB0eHQ6IFwiUmV2aWV3c1wiLCB0b3RhbDogcmV2aWV3cyB9LFxyXG4gICAge1xyXG4gICAgICBzcmM6IFwiL2ltYWdlcy9ib29raW5ncy5zdmdcIixcclxuICAgICAgdHh0OiBcIkJvb2tpbmdzIFRvdGFsXCIsXHJcbiAgICAgIHRvdGFsOiBib29raW5ncyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHNyYzogXCIvaW1hZ2VzL2Jvb2stY29tcC5zdmdcIixcclxuICAgICAgdHh0OiBcIkJvb2tpbmdzIENvbXBsZXRlZFwiLFxyXG4gICAgICB0b3RhbDogY29tcGxldGVkLFxyXG4gICAgfSxcclxuICAgIHsgc3JjOiBcIi9pbWFnZXMvYm9vay1kZWwuc3ZnXCIsIHR4dDogXCJCb29raW5ncyBEZWxldGVkXCIsIHRvdGFsOiBkZWxldGVkIH0sXHJcbiAgICB7IHNyYzogXCIvaW1hZ2VzL2Jvb2stbm9TaG93LnN2Z1wiLCB0eHQ6IFwiQm9va2luZ3MgTm8tU2hvd1wiLCB0b3RhbDogbm9TaG93IH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZXhwZXJpZW5jZSA9IFtcclxuICAgIHsgc3JjOiBcIi9pbWFnZXMvc3RhcnMuc3ZnXCIsIHR4dDogXCJSZXZpZXdzXCIsIHRvdGFsOiBleHBSZXZpZXdzIH0sXHJcbiAgICB7XHJcbiAgICAgIHNyYzogXCIvaW1hZ2VzL2Jvb2tpbmdzLnN2Z1wiLFxyXG4gICAgICB0eHQ6IFwiQm9va2luZ3MgVG90YWxcIixcclxuICAgICAgdG90YWw6IGV4cEJvb2tpbmdzLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgc3JjOiBcIi9pbWFnZXMvZWFybmluZy5zdmdcIixcclxuICAgICAgdHh0OiBcIkVhcm5pbmdzXCIsXHJcbiAgICAgIHRvdGFsOiBlYXJuaW5ncyxcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxEYXNoQm9yZENvbnRleHQuUHJvdmlkZXJcclxuICAgICAgdmFsdWU9e3tcclxuICAgICAgICBzZXRTdGFydERhdGUsXHJcbiAgICAgICAgc2V0RW5kRGF0ZSxcclxuICAgICAgICBsb2NhbCxcclxuICAgICAgICBleHBlcmllbmNlLFxyXG4gICAgICB9fVxyXG4gICAgPlxyXG4gICAgICB7Y2hpbGRyZW59XHJcbiAgICA8L0Rhc2hCb3JkQ29udGV4dC5Qcm92aWRlcj5cclxuICApO1xyXG59XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcblxuaW1wb3J0IHsgUGFnZVRpdGxlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvdWlcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT5DcmVhdGUgTmV4dCBBcHA8L3RpdGxlPlxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICA8L0hlYWQ+XG4gICAgICA8UGFnZVRpdGxlIHRleHQ9XCJDYWxlbmRlclwiIC8+XG4gICAgPC8+XG4gICk7XG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAZGF0ZS1pby9kYXRlLWZuc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9Cb3hcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQnV0dG9uXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0NpcmN1bGFyUHJvZ3Jlc3NcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0RpYWxvZ0FjdGlvbnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvRGlhbG9nQ29udGVudFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9EaWFsb2dDb250ZW50VGV4dFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9Gb3JtQ29udHJvbFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9HcmlkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0lucHV0QmFzZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9OYXRpdmVTZWxlY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvU2xpZGVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29uc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQ2FsZW5kYXJUb2RheU91dGxpbmVkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9TdGFyQm9yZGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9sYWIvUmF0aW5nXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9waWNrZXJzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZGF0ZS1mbnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9oZWFkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9