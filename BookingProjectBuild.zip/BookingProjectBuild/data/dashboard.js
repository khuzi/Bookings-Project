export const dashboardLinks = [
  {
    href: "/",
    text: "Calender",
  },
  {
    href: "/bookings",
    text: "Bookings",
  },
  {
    href: "/management",
    text: "Managemant",
  },
  {
    href: "/dashboard",
    text: "Dashboard",
  },
];
