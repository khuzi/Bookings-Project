export const tableHead = [
  { col: 1, text: "" },
  { col: 1, text: "TAV" },
  { col: 2, text: "" },
  { col: 1, text: "NOMINATIVO" },
  { col: 6, text: "" },
  { col: 1, text: "AZIONI" },
];
