export { ManageCard } from "./manageCard/manageCard";
export { ManageDetails } from "./manageDetails/manageDetails";
